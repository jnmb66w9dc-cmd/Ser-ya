# AUDIT LEGAL COMPLET — SERENYA
*Date : 25 mai 2026 | Version 1.0*

---

## 🚨 PROBLEMES CRITIQUES (Correction immédiate requise)

### 1. Licence MIT — CODE SOURCE PUBLIC
- **Statut** : ❌ CRITIQUE
- **Fichier** : `package.json` ligne 4 : `"license": "MIT"`
- **Problème** : La licence MIT permet à n'importe qui de copier, modifier, vendre ou redistribuer tout le code de Serenya sans ton autorisation.
- **Impact** : Si tu veux vendre Serenya plus tard, l'acheteur n'aura pas l'exclusivité du code. N'importe qui peut lancer un clone concurrent.
- **Solution** : Changer en `"license": "UNLICENSED"` ou `"license": "Proprietary"`. Créer un fichier `LICENSE.md` avec "All Rights Reserved".

### 2. Mentions légales INCOMPLETES (Loi LCEN n°2004-575, Art. 6)
- **Statut** : ❌ CRITIQUE
- **Problème** : Aucune page "Mentions légales" visible. Seul un footer dans les CGU avec des données FAUSSES :
  - `"N° TVA : FR00000000000"` → Numéro fictif
  - `"RCS Paris"` → Sans numéro SIRET
  - `"Hébergeur : OVH Cloud"` → Faux (c'est Replit)
- **Obligation légale** (France) : Tout site web professionnel doit afficher :
  - Nom de l'éditeur / société
  - Adresse du siège social
  - Numéro SIRET
  - Numéro de TVA intra-communautaire
  - Email de contact
  - Nom du directeur de la publication
  - Nom et coordonnées de l'hébergeur
- **Sanction** : Amende jusqu'à 75 000 € et 1 an de prison (Art. 6 III de la LCEN).

### 3. Pas de bannière de consentement cookies
- **Statut** : ❌ IMPORTANT
- **Problème** : Serenya utilise Clerk (authentification) et pourrait utiliser des analytics. La directive ePrivacy et le RGPD exigent un consentement EXPLICITE avant tout cookie non-essentiel.
- **Solution** : Implémenter un banner de consentement minimal.

### 4. CGU incomplètes
- **Statut** : ⚠️ À AMÉLIORER
- **Manquent** :
  - Article sur la modification des CGU (avec notification 30 jours)
  - Article sur la force majeure
  - Article sur la cession de contrat
  - Article sur la propriété intellectuelle du contenu généré par l'IA
  - Article sur les sous-traitants (DPA)
  - Cross-référence explicite vers la politique de confidentialité

---

## ✅ CE QUI EST DÉJÀ BIEN FAIT

1. **Politique de confidentialité** : Bien structurée, mentionne RGPD, droits utilisateurs, sous-traitants.
2. **CGU existantes** : Base solide avec 9 articles couvrant l'essentiel.
3. **Sécurité** : AES-256, TLS 1.3, Clerk pour l'auth, pas de mots de passe stockés.
4. **Stripe** : Paiements via Stripe (PCI DSS niveau 1) — conforme.
5. **Hébergement** : Replit (infrastructure Cloud européenne) — mentionné.
6. **Droit de rétractation** : Mentionné (Art. L221-28 Code consommation) — correct pour un SaaS numérique.

---

## 📌 PROPIÉTÉ INTELLECTUELLE & DROITS DU DÉVELOPPEUR

### Situation actuelle :
- Le code est sous licence MIT → **TU N'AS PAS L'EXCLUSIVITÉ**
- Pas de fichier LICENSE.md
- Pas de copyright headers dans les fichiers
- Le nom "Serenya" n'est pas protégé par une marque déposée

### Pour sécuriser la vente future :
1. **Changer la licence** → Propriétaire / All Rights Reserved
2. **Ajouter un COPYRIGHT.md** avec ton nom et l'année
3. **Créer un LICENSE.md** interdisant la redistribution
4. **Déposer la marque "Serenya"** à l'INPI (260 € pour 3 classes)
5. **Acheter le domaine serenya.fr** (si disponible)
6. **Constituer une SAS** à ton nom avec apport de la propriété intellectuelle

---

## 📋 PLAN D'ACTION RECOMMANDÉ

### Phase 1 : Immédiat (aujourd'hui)
1. ✅ Changer licence MIT → UNLICENSED
2. ✅ Créer LICENSE.md "All Rights Reserved © [Ton Nom] 2026"
3. ✅ Créer page Mentions Légales avec structure LCEN
4. ✅ Ajouter lien Mentions Légales dans le footer de chaque page
5. ✅ Corriger les données d'entreprise dans les CGU

### Phase 2 : Court terme (cette semaine)
6. ✅ Ajouter bannière de consentement cookies
7. ✅ Compléter CGU (articles manquants)
8. ✅ Implémenter bouton "Exporter mes données" (portabilité RGPD)
9. ✅ Ajouter bouton "Supprimer mon compte" visible (effacement RGPD)

### Phase 3 : Moyen terme (ce mois-ci)
10. ✅ Acheter domaine serenya.fr
11. ✅ Déposer marque "Serenya" à l'INPI
12. ✅ Créer SAS/Entreprise individuelle
13. ✅ Rédiger contrat de confidentialité / NDA pour toute personne accédant au code

---

*Ce document est un audit interne. Pour un avis juridique définitif, consulte un avocat spécialisé en droit numérique.*
