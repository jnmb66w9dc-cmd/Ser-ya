import { getUncachableStripeClient } from '../../artifacts/api-server/src/stripeClient';

async function createProducts() {
  try {
    const stripe = await getUncachableStripeClient();
    console.log('Creating Serenya plans in Stripe...');

    // ── Pro Plan ──
    const existingPro = await stripe.products.search({ query: "name:'Serenya Pro' AND active:'true'" });
    let proProduct;
    if (existingPro.data.length > 0) {
      console.log('Pro plan already exists:', existingPro.data[0].id);
      proProduct = existingPro.data[0];
    } else {
      proProduct = await stripe.products.create({
        name: 'Serenya Pro',
        description: 'Automatisations illimitées, support prioritaire, historique complet',
        metadata: { plan: 'pro', features: 'automations_unlimited,priority_support,history' },
      });
      console.log('Created Pro product:', proProduct.id);

      await stripe.prices.create({
        product: proProduct.id,
        unit_amount: 900,
        currency: 'eur',
        recurring: { interval: 'month' },
        nickname: 'Pro Mensuel',
      });
      await stripe.prices.create({
        product: proProduct.id,
        unit_amount: 8640,
        currency: 'eur',
        recurring: { interval: 'year' },
        nickname: 'Pro Annuel (-20%)',
      });
    }

    // ── Business Plan ──
    const existingBiz = await stripe.products.search({ query: "name:'Serenya Business' AND active:'true'" });
    if (existingBiz.data.length > 0) {
      console.log('Business plan already exists:', existingBiz.data[0].id);
    } else {
      const bizProduct = await stripe.products.create({
        name: 'Serenya Business',
        description: 'Tout Pro + multi-utilisateurs, API access, gestionnaire dédié',
        metadata: { plan: 'business', features: 'all_pro,multi_user,api_access,dedicated_manager' },
      });
      console.log('Created Business product:', bizProduct.id);

      await stripe.prices.create({
        product: bizProduct.id,
        unit_amount: 2900,
        currency: 'eur',
        recurring: { interval: 'month' },
        nickname: 'Business Mensuel',
      });
      await stripe.prices.create({
        product: bizProduct.id,
        unit_amount: 27840,
        currency: 'eur',
        recurring: { interval: 'year' },
        nickname: 'Business Annuel (-20%)',
      });
    }

    console.log('✓ Produits Stripe créés. Les webhooks synchroniseront automatiquement la DB.');
  } catch (err: any) {
    console.error('Erreur:', err.message);
    process.exit(1);
  }
}

createProducts();
