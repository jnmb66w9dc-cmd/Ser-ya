# COPYRIGHT & PROPRIETE INTELLECTUELLE

## SERENYA — Assistant administratif de changement d'adresse

**Copyright © 2026 [Proprietaire — a definir par le createur]**

---

## 1. PROPRIETE DU CODE SOURCE

L'intégralité du code source, des fichiers de configuration, des bases de données,
des algorithmes, des interfaces utilisateur, de la documentation technique et des
ressources graphiques associées au projet "Serenya" est la propriété exclusive
de son créateur et propriétaire légal.

**Fichiers couverts** :
- Tous les fichiers TypeScript/JavaScript du frontend et du backend
- Les fichiers de configuration (package.json, tsconfig, etc.)
- Les schémas de base de données et migrations
- Les assets graphiques (logos, icônes, illustrations)
- La documentation technique et utilisateur
- Les prompts IA et configurations système

## 2. LICENCE

Ce logiciel est **PROPRIETAIRE** et **NON OPEN SOURCE**.

Aucun droit n'est accordé sans autorisation écrite expresse du propriétaire.
Voir le fichier `LICENSE.md` pour les conditions d'utilisation complètes.

## 3. MARQUES

Le nom "Serenya", le logo, et l'identité visuelle associée sont des marques
deposées ou en cours de dépôt. Toute utilisation non autorisée est interdite.

## 4. DROITS DU PROPRIETAIRE

Le propriétaire conserve l'entièreté des droits sur :
- Le code source complet
- Les bases de données et leur contenu (hors données utilisateurs)
- L'architecture technique
- Les algorithmes et modèles de traitement
- La marque et l'identité commerciale

## 5. VENTE FUTURE

En cas de cession ou de vente du projet Serenya :
- Le propriétaire actuel peut transférer l'intégralité des droits à un acquéreur
- L'acquéreur deviendra propriétaire exclusif du code, de la marque, et des données
- Une clause de non-concurrence peut être ajoutée au contrat de vente
- Les utilisateurs existants restent soumis aux CGU en vigueur

## 6. PROTECTION JURIDIQUE

Toute violation des droits de propriété intellectuelle fera l'objet de poursuites
judiciaires pour contrefaçon, conformément aux articles L.335-2 et suivants du
Code de la propriété intellectuelle français.

---

Pour toute demande d'autorisation ou de licence : contact@serenya.replit.app
