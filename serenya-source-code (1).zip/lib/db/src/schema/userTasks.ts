import { pgTable, serial, text, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { automationsTable } from "./automations";

export const userTasksTable = pgTable("user_tasks", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  category: text("category").notNull().default("document"), // document, email, online, call, confirm, download
  status: text("status").notNull().default("pending"), // pending, in_progress, completed, skipped
  priority: text("priority").notNull().default("medium"), // low, medium, high
  orgName: text("org_name"),
  automationId: integer("automation_id").references(() => automationsTable.id),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertUserTaskSchema = createInsertSchema(userTasksTable).omit({ id: true, createdAt: true, completedAt: true });
export type InsertUserTask = z.infer<typeof insertUserTaskSchema>;
export type UserTask = typeof userTasksTable.$inferSelect;
