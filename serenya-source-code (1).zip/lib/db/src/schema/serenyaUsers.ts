import { pgTable, text, timestamp } from "drizzle-orm/pg-core";

export const serenyaUsersTable = pgTable("serenya_users", {
  id: text("id").primaryKey(),
  email: text("email"),
  stripeCustomerId: text("stripe_customer_id"),
  stripePlan: text("stripe_plan").default("free"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export type SerenyaUser = typeof serenyaUsersTable.$inferSelect;
