import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { servicesTable } from "./services";

export const userServicesTable = pgTable("user_services", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  serviceId: integer("service_id").notNull().references(() => servicesTable.id),
  status: text("status").notNull().default("connected"),
  connectedAt: timestamp("connected_at").notNull().defaultNow(),
  lastUpdatedAt: timestamp("last_updated_at"),
});

export const insertUserServiceSchema = createInsertSchema(userServicesTable).omit({ id: true, connectedAt: true, lastUpdatedAt: true });
export type InsertUserService = z.infer<typeof insertUserServiceSchema>;
export type UserService = typeof userServicesTable.$inferSelect;
