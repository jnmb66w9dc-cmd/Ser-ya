import { pgTable, serial, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { automationsTable } from "./automations";

export const shareLinksTable = pgTable("share_links", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  automationId: integer("automation_id").notNull().references(() => automationsTable.id),
  token: text("token").notNull().unique(),
  firstName: text("first_name"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertShareLinkSchema = createInsertSchema(shareLinksTable).omit({ id: true, createdAt: true });
export type InsertShareLink = z.infer<typeof insertShareLinkSchema>;
export type ShareLink = typeof shareLinksTable.$inferSelect;
