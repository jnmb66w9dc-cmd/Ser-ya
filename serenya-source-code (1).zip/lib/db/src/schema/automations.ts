import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { addressesTable } from "./addresses";

export const automationsTable = pgTable("automations", {
  id: serial("id").primaryKey(),
  userId: text("user_id").notNull(),
  addressId: integer("address_id").notNull().references(() => addressesTable.id),
  status: text("status").notNull().default("queued"),
  totalServices: integer("total_services").notNull().default(0),
  completedServices: integer("completed_services").notNull().default(0),
  failedServices: integer("failed_services").notNull().default(0),
  progressPercent: integer("progress_percent").notNull().default(0),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertAutomationSchema = createInsertSchema(automationsTable).omit({ id: true, createdAt: true, completedAt: true, progressPercent: true });
export type InsertAutomation = z.infer<typeof insertAutomationSchema>;
export type Automation = typeof automationsTable.$inferSelect;
