import { pgTable, serial, text, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { automationsTable } from "./automations";
import { userServicesTable } from "./userServices";

export const automationTasksTable = pgTable("automation_tasks", {
  id: serial("id").primaryKey(),
  automationId: integer("automation_id").notNull().references(() => automationsTable.id),
  userServiceId: integer("user_service_id").notNull().references(() => userServicesTable.id),
  status: text("status").notNull().default("queued"),
  errorMessage: text("error_message"),
  stepData: jsonb("step_data"), // { steps[], documents[], url, estimatedTime, difficulty }
  trackingStatus: text("tracking_status").default("prepared"), // prepared | submitted | acknowledged | processing | completed | failed
  trackingSteps: jsonb("tracking_steps"), // [{ status, label, timestamp, description }]
  createdAt: timestamp("created_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
});

export const insertAutomationTaskSchema = createInsertSchema(automationTasksTable).omit({ id: true, createdAt: true, completedAt: true });
export type InsertAutomationTask = z.infer<typeof insertAutomationTaskSchema>;
export type AutomationTask = typeof automationTasksTable.$inferSelect;
