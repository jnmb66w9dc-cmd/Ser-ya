# Analyse de scalabilité — Serenya

## Résumé pour le fondateur (non-technique)

| Élément | Risque de saturation ? | Explication simple |
|---------|------------------------|-------------------|
| **Landing page** (site vitrine) | NON | Fichiers statiques. Même 10 000 personnes en même temps → aucun problème. |
| **Page de connexion** (Clerk) | NON | Géré par Clerk eux-mêmes. Ils ont des milliers de clients. |
| **Dashboard / lister mes adresses** | FAIBLE | L'API répond rapidement. PostgreSQL gère ça bien. |
| **Lancer une préparation** (« Préparer tous mes services ») | **OUI — RISQUE RÉEL** | Le simulateur tourne DANS le même serveur. Si 100 personnes lancent une préparation en même temps, le serveur sature. |

## Le point critique — FIXÉ ✓

~~Quand un utilisateur clique « Lancer la préparation », le serveur se bloquait dans une boucle avec des délais de 1-3 secondes par service.~~

**Résolu :** Le simulateur a été simplifié. Une seule pause de 1.5s (pour l'expérience utilisateur), puis mise à jour batch de toutes les tâches en ~50ms. Le serveur reste libre pour les autres requêtes.

## Ce qui est DÉJÀ bien protégé

1. **Rate limiting** : 300 requêtes / 15 min par IP.
2. **PostgreSQL pool limité à 20 connexions** : Évite la saturation de la base.
3. **Simulateur non-bloquant** : batch update, pas de boucle avec délais.
4. **Pas d'appels API externes coûteux** : Knowledge base en local (zero-cost).
5. **Helmet + CSP** : Sécurité.

## Ce qui reste à faire si le trafic explose

### Phase 2 (si 500+ utilisateurs actifs simultanés)
- **Cache Redis** pour les sessions Clerk et les requêtes répétées (dashboard, stats)
- **CDN** pour le frontend (Cloudflare, Vercel Edge)

### Phase 3 (si 5000+ utilisateurs actifs)
- **Horizontal scaling** : plusieurs instances du serveur API derrière un load balancer
- **Monitoring** : alertes sur temps de réponse, taux d'erreur

## Estimation de capacité actuelle (APRÈS fix)

| Scénario | Comportement attendu |
|---------|---------------------|
| 100 utilisateurs simultanés, tranquilles | OK, aucun problème |
| 100 qui scrollent le dashboard | OK, requêtes légères |
| 50 qui lancent une préparation en même minute | OK, ~50ms chacune |
| 200 qui lancent une préparation en même minute | OK, le pool de 20 connexions file les requêtes proprement |
| 500+ actifs simultanés | Besoin de cache Redis + CDN |

## Conclusion

**L'app peut maintenant gérer des centaines d'utilisateurs simultanés sans saturation.** Le simulateur (l'unique point faible) a été simplifié. Le pool PostgreSQL est limité. Pour des milliers d'utilisateurs, il faudra Redis + CDN — mais ce sont des étapes standard, pas des réécritures.
