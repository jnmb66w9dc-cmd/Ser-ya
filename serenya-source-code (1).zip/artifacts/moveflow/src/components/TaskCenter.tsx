import { useState, useEffect, useCallback, useMemo } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import {
  CheckCircle2, Circle, Clock, AlertTriangle, ChevronRight,
  FileText, Mail, ExternalLink, Phone, FileCheck, Download,
  X, Trash2, RotateCcw, Sparkles, ListChecks, Shield,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useUserTasks, type ApiUserTask, type TaskCategory, type TaskStatus, type TaskPriority } from "@/hooks/use-user-tasks";

/* ══════════════════════════════════════════════
   Types (UI-facing, kept for compatibility)
   ══════════════════════════════════════════════ */

export type TaskKind = TaskCategory;

export interface AdminTask {
  id: string | number;
  serviceName: string;
  label: string;
  kind: TaskKind;
  done: boolean;
  createdAt: string;
  completedAt?: string;
  note?: string;
  link?: string;
  priority?: "low" | "normal" | "high";
}

/* ══════════════════════════════════════════════
   Icons per kind
   ══════════════════════════════════════════════ */

const KIND_CONFIG: Record<TaskKind, { icon: typeof FileText; label: string; color: string; bg: string }> = {
  document:  { icon: FileCheck,  label: "Document",  color: "text-amber-400",  bg: "bg-amber-500/10" },
  email:       { icon: Mail,       label: "Email",     color: "text-blue-400",   bg: "bg-blue-500/10" },
  online:      { icon: ExternalLink, label: "En ligne",  color: "text-violet-400", bg: "bg-violet-500/10" },
  call:        { icon: Phone,      label: "Appel",     color: "text-rose-400",   bg: "bg-rose-500/10" },
  confirm:     { icon: CheckCircle2, label: "Confirmer", color: "text-emerald-400", bg: "bg-emerald-500/10" },
  download:    { icon: Download,   label: "Télécharger", color: "text-cyan-400",   bg: "bg-cyan-500/10" },
};

/* ══════════════════════════════════════════════
   Mapping helpers: API ↔ UI
   ══════════════════════════════════════════════ */

function apiToAdmin(t: ApiUserTask): AdminTask {
  const pri: "low" | "normal" | "high" = t.priority === "low" ? "low" : t.priority === "high" ? "high" : "normal";
  return {
    id: t.id,
    serviceName: t.orgName || "Serenya",
    label: t.title,
    kind: t.category,
    done: t.status === "completed",
    createdAt: t.createdAt,
    completedAt: t.completedAt ?? undefined,
    note: t.description ?? undefined,
    priority: pri,
  };
}

/* ══════════════════════════════════════════════
   Auto-generate tasks from OrgProfile data
   ══════════════════════════════════════════════ */

export function generateTasksFromProfile(
  serviceName: string,
  required: string[],
  checklistItems: { label: string; done: boolean }[] | undefined,
  mode: "prefill" | "redirect" | "prepared" | "manual",
  emailTemplate?: string,
  existingTasks: AdminTask[] = [],
): AdminTask[] {
  const now = new Date().toISOString();
  const existingIds = new Set(existingTasks.map(t => t.id));
  const newTasks: AdminTask[] = [];

  function add(label: string, kind: TaskKind, note?: string, link?: string, priority?: AdminTask["priority"]) {
    const id = `${serviceName}::${label}`;
    if (!existingIds.has(id)) {
      newTasks.push({ id, serviceName, label, kind, done: false, createdAt: now, note, link, priority });
    }
  }

  // Generate from required actions
  required.forEach(req => {
    const lower = req.toLowerCase();
    if (lower.includes("connectez-vous") || lower.includes("accédez") || lower.includes("naviguez")) {
      add(req, "online", undefined, undefined, "high");
    } else if (lower.includes("email") || lower.includes("envoyez") || lower.includes("envoyer")) {
      add(req, "email", undefined, undefined, "high");
    } else if (lower.includes("téléchargez") || lower.includes("document") || lower.includes("formulaire")) {
      add(req, "document", undefined, undefined, "normal");
    } else if (lower.includes("justificatif")) {
      add(req, "document", "Document administratif nécessaire", undefined, "high");
    } else if (lower.includes("validez") || lower.includes("confirmez") || lower.includes("vérifiez")) {
      add(req, "confirm", undefined, undefined, "high");
    } else {
      add(req, "confirm", undefined, undefined, "normal");
    }
  });

  // Generate from checklist items
  checklistItems?.forEach(item => {
    const lower = item.label.toLowerCase();
    const id = `${serviceName}::${item.label}`;
    if (!existingIds.has(id)) {
      let kind: TaskKind = "confirm";
      if (lower.includes("télécharger") || lower.includes("document") || lower.includes("formulaire") || lower.includes("justificatif")) {
        kind = "document";
      } else if (lower.includes("email") || lower.includes("envoyer") || lower.includes("courrier")) {
        kind = "email";
      } else if (lower.includes("connecter") || lower.includes("site") || lower.includes("espace")) {
        kind = "online";
      } else if (lower.includes("appeler") || lower.includes("téléphone")) {
        kind = "call";
      }
      newTasks.push({
        id, serviceName, label: item.label, kind,
        done: item.done, createdAt: now, priority: "normal",
      });
    }
  });

  // Mode-specific tasks
  if (mode === "prepared" && emailTemplate) {
    add("Envoyer l'email préparé", "email", "Email copié dans le presse-papiers prêt à coller", undefined, "high");
  }
  if (mode === "prefill") {
    add("Vérifier et confirmer les données pré-remplies", "confirm", "Les champs sont déjà remplis — validez simplement", undefined, "high");
  }

  return newTasks;
}

/* ══════════════════════════════════════════════
   Task Item UI
   ══════════════════════════════════════════════ */

function TaskRow({ task, onToggle, onDelete }: {
  task: AdminTask;
  onToggle: () => void;
  onDelete: () => void;
}) {
  const cfg = KIND_CONFIG[task.kind];
  const Icon = cfg.icon;
  const [showDel, setShowDel] = useState(false);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 6 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      className={cn(
        "group flex items-start gap-3 p-3.5 rounded-xl border transition-all duration-200",
        task.done
          ? "bg-muted/20 border-border/20"
          : task.priority === "high"
          ? "bg-amber-500/[0.03] border-amber-500/15 hover:border-amber-500/30"
          : "bg-card border-border/40 hover:border-primary/20"
      )}
      onMouseEnter={() => setShowDel(true)}
      onMouseLeave={() => setShowDel(false)}
    >
      {/* Checkbox */}
      <button
        onClick={onToggle}
        className={cn(
          "mt-0.5 w-5 h-5 rounded-md border-2 flex items-center justify-center flex-shrink-0 transition-all duration-200",
          task.done
            ? "border-emerald-500 bg-emerald-500"
            : "border-border/60 hover:border-primary/50"
        )}
      >
        {task.done && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
      </button>

      {/* Content */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-0.5">
          <span className={cn("text-[10px] font-medium uppercase tracking-wider", cfg.color)}>
            {cfg.label}
          </span>
          {task.priority === "high" && !task.done && (
            <Badge variant="outline" className="text-[10px] h-4 px-1.5 border-amber-500/20 text-amber-400 bg-amber-500/10">
              Important
            </Badge>
          )}
          <span className="ml-auto text-[10px] text-muted-foreground/40 tabular-nums">
            {task.serviceName}
          </span>
        </div>
        <p className={cn("text-sm leading-snug", task.done ? "text-muted-foreground/40 line-through" : "text-foreground/85")}>
          {task.label}
        </p>
        {task.note && (
          <p className="text-xs text-muted-foreground/60 mt-1 leading-relaxed">{task.note}</p>
        )}
      </div>

      {/* Actions */}
      <div className="flex items-center gap-1 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity">
        <button
          onClick={onDelete}
          className="w-7 h-7 rounded-lg hover:bg-destructive/10 flex items-center justify-center text-muted-foreground/40 hover:text-destructive transition-colors"
          title="Supprimer"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>
    </motion.div>
  );
}

/* ══════════════════════════════════════════════
   Progress Ring
   ══════════════════════════════════════════════ */

function ProgressSummary({ total, done }: { total: number; done: number }) {
  const pct = total === 0 ? 0 : Math.round((done / total) * 100);
  return (
    <div className="flex items-center gap-4 p-4 rounded-xl bg-muted/20 border border-border/30">
      <div className="relative w-14 h-14 flex-shrink-0">
        <svg className="w-14 h-14 -rotate-90" viewBox="0 0 36 36">
          <circle cx="18" cy="18" r="15.9" fill="none" stroke="currentColor" strokeWidth="3" className="text-muted/30" />
          <circle cx="18" cy="18" r="15.9" fill="none" stroke="currentColor" strokeWidth="3"
            className="text-emerald-400 transition-all duration-700"
            strokeDasharray={`${pct} ${100 - pct}`} strokeLinecap="round"
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="text-xs font-bold tabular-nums">{pct}%</span>
        </div>
      </div>
      <div>
        <p className="text-sm font-semibold">{done}/{total} tâches complétées</p>
        <p className="text-xs text-muted-foreground mt-0.5">
          {done === total
            ? "Toutes vos démarches sont en ordre ✓"
            : pct >= 50
            ? "Vous avancez bien — continuez !"
            : "Commencez par les tâches marquées Important"}
        </p>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   Main TaskCenter Component (API-backed)
   ══════════════════════════════════════════════ */

interface TaskCenterProps {
  initialTasks?: AdminTask[];
  className?: string;
}

export default function TaskCenter({ className }: TaskCenterProps) {
  const { tasks: apiTasks, isLoading, updateStatus, remove } = useUserTasks();
  const [filter, setFilter] = useState<"all" | "pending" | "done">("all");
  const [kindFilter, setKindFilter] = useState<TaskKind | "all">("all");
  const { toast } = useToast();

  const tasks = useMemo(() => apiTasks.map(apiToAdmin), [apiTasks]);

  const toggle = useCallback((id: string | number) => {
    const apiTask = apiTasks.find(t => t.id === id);
    if (!apiTask) return;
    const nextStatus: TaskStatus = apiTask.status === "completed" ? "pending" : "completed";
    updateStatus.mutate(
      { id: apiTask.id, status: nextStatus },
      {
        onSuccess: () => {
          if (nextStatus === "completed") {
            toast({ title: "Tâche terminée ✓", description: `"${apiTask.title}"` });
          }
        },
      }
    );
  }, [apiTasks, updateStatus, toast]);

  const handleDelete = useCallback((id: string | number) => {
    const numId = typeof id === "number" ? id : parseInt(String(id), 10);
    if (Number.isNaN(numId)) return;
    remove.mutate(numId);
  }, [remove]);

  const resetAll = useCallback(() => {
    if (window.confirm("Réinitialiser toutes les tâches ? Cette action ne peut pas être annulée.")) {
      // Remove all pending tasks one by one
      apiTasks.forEach(t => remove.mutate(t.id));
      toast({ title: "Tâches réinitialisées" });
    }
  }, [apiTasks, remove, toast]);

  const filtered = useMemo(() => {
    let out = tasks;
    if (filter === "pending") out = out.filter(t => !t.done);
    if (filter === "done") out = out.filter(t => t.done);
    if (kindFilter !== "all") out = out.filter(t => t.kind === kindFilter);
    return out.sort((a, b) => {
      if (a.done !== b.done) return a.done ? 1 : -1;
      if (a.priority === "high" && b.priority !== "high") return -1;
      if (b.priority === "high" && a.priority !== "high") return 1;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }, [tasks, filter, kindFilter]);

  const total = tasks.length;
  const done = tasks.filter(t => t.done).length;
  const pendingHigh = tasks.filter(t => !t.done && t.priority === "high").length;

  if (isLoading) {
    return (
      <div className={cn("space-y-4", className)}>
        <div className="h-20 rounded-xl bg-muted/30 animate-pulse" />
        <div className="h-12 rounded-xl bg-muted/20 animate-pulse" />
        <div className="h-12 rounded-xl bg-muted/20 animate-pulse" />
      </div>
    );
  }

  return (
    <div className={cn("space-y-4", className)}>
      {/* Progress */}
      {total > 0 && <ProgressSummary total={total} done={done} />}

      {/* Filters */}
      <div className="flex flex-wrap items-center gap-2">
        {(["all", "pending", "done"] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={cn(
              "px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
              filter === f
                ? f === "done" ? "bg-emerald-500/10 text-emerald-400" : f === "pending" ? "bg-amber-500/10 text-amber-400" : "bg-primary/10 text-primary"
                : "text-muted-foreground hover:bg-muted"
            )}
          >
            {f === "all" ? "Toutes" : f === "pending" ? "En cours" : "Terminées"}
            {f === "all" && total > 0 && ` (${total})`}
            {f === "pending" && tasks.filter(t => !t.done).length > 0 && ` (${tasks.filter(t => !t.done).length})`}
            {f === "done" && done > 0 && ` (${done})`}
          </button>
        ))}
        <div className="w-px h-4 bg-border/40 mx-1" />
        {(["all", "document", "email", "online", "confirm"] as const).map(k => {
          const count = k === "all" ? tasks.length : tasks.filter(t => t.kind === k).length;
          if (count === 0) return null;
          return (
            <button
              key={k}
              onClick={() => setKindFilter(k === kindFilter ? "all" : k)}
              className={cn(
                "px-2.5 py-1 rounded-md text-[10px] font-medium uppercase tracking-wider transition-colors",
                kindFilter === k
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground/50 hover:bg-muted"
              )}
            >
              {k === "all" ? "Tout" : KIND_CONFIG[k as TaskKind].label}
            </button>
          );
        })}
        {total > 0 && (
          <button
            onClick={resetAll}
            className="ml-auto flex items-center gap-1 text-xs text-muted-foreground/40 hover:text-destructive transition-colors"
          >
            <RotateCcw className="w-3 h-3" /> Réinitialiser
          </button>
        )}
      </div>

      {/* Task list */}
      <div className="space-y-2">
        <AnimatePresence mode="popLayout">
          {filtered.map(task => (
            <TaskRow
              key={String(task.id)}
              task={task}
              onToggle={() => toggle(task.id)}
              onDelete={() => handleDelete(task.id)}
            />
          ))}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="text-center py-12 rounded-2xl border border-dashed border-border/40 bg-muted/10">
            <ListChecks className="w-10 h-10 text-muted-foreground/20 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">
              {filter === "done" ? "Aucune tâche terminée pour l'instant." : "Aucune tâche en cours."}
            </p>
            <p className="text-xs text-muted-foreground/50 mt-1 max-w-xs mx-auto">
              Lancez une préparation ou consultez les détails d'une démarche pour générer des tâches.
            </p>
          </div>
        )}
      </div>

      {/* Trust footer */}
      {total > 0 && (
        <div className="flex items-center gap-2 pt-2 text-[10px] text-muted-foreground/30">
          <Shield className="w-3 h-3" />
          Vos tâches sont synchronisées en toute sécurité. Serenya chiffre vos données en transit.
        </div>
      )}
    </div>
  );
}

/* ══════════════════════════════════════════════
   Compact widget for dashboard / sidebar
   ══════════════════════════════════════════════ */

export function TaskHubWidget({ onOpen }: { onOpen: () => void }) {
  const { tasks: apiTasks, isLoading } = useUserTasks();
  const tasks = useMemo(() => apiTasks.map(apiToAdmin), [apiTasks]);
  const pending = tasks.filter(t => !t.done).length;
  const high = tasks.filter(t => !t.done && t.priority === "high").length;

  return (
    <Card className="p-4 cursor-pointer hover:border-primary/20 transition-all" onClick={onOpen}>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <ListChecks className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-sm">Tâches administratives</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {isLoading ? "Chargement..." : pending === 0
              ? "Toutes vos démarches sont à jour ✓"
              : `${pending} tâche${pending > 1 ? "s" : ""} en cours — cliquez pour gérer`}
          </p>
        </div>
        {high > 0 && (
          <Badge variant="outline" className="text-amber-400 border-amber-500/20 bg-amber-500/10 text-xs">
            <AlertTriangle className="w-3 h-3 mr-1" /> {high}
          </Badge>
        )}
        {pending === 0 && tasks.length > 0 && !isLoading && (
          <CheckCircle2 className="w-5 h-5 text-emerald-400" />
        )}
        <ChevronRight className="w-4 h-4 text-muted-foreground/30" />
      </div>
    </Card>
  );
}

/* ══════════════════════════════════════════════
   Legacy helpers kept for backward compat with dashboard & automations pages.
   saveTasks now creates tasks via API; loadTasks is a no-op (data comes from API hook).
   ══════════════════════════════════════════════ */

export function loadTasks(): AdminTask[] { return []; }

export async function saveTasks(tasks: AdminTask[]) {
  // Send each new task to the API. This is fire-and-forget; the API hook will refresh.
  for (const t of tasks) {
    const numId = typeof t.id === "number" ? t.id : parseInt(String(t.id), 10);
    if (!Number.isNaN(numId)) continue; // Skip if already has a numeric DB id
    try {
      await fetch("/api/user-tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: t.label,
          description: t.note || null,
          category: t.kind,
          priority: t.priority === "high" ? "high" : t.priority === "low" ? "low" : "medium",
          orgName: t.serviceName,
        }),
      });
    } catch { /* ignore */ }
  }
}
