import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import {
  FileText, Download, CheckCircle2, Clock, ArrowRight,
  X, Printer, Copy, CheckCheck, Shield, AlertTriangle,
  ChevronRight, Sparkles, ListChecks, Mail, ExternalLink,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import jsPDF from "jspdf";

/* ══════════════════════════════════════════════
   Types — mirrors OrgProfile from automations.tsx
══════════════════════════════════════════════ */

export interface DocProfile {
  serviceName: string;
  mode: "prefill" | "redirect" | "prepared" | "manual";
  status: "completed" | "failed" | "pending" | "in_progress";
  processingTime: string;
  prepared: string[];
  required: string[];
  nextSteps: string[];
  orgNote: string;
  prefillData?: { label: string; value: string; masked?: boolean }[];
  checklistItems?: { label: string; done: boolean }[];
  emailTemplate?: string;
  addressLabel: string;
  completedAt?: string;
}

/* ══════════════════════════════════════════════
   Sub-components
══════════════════════════════════════════════ */

function StatusBadge({ status }: { status: DocProfile["status"] }) {
  const cfg = {
    completed:   { label: "Terminé",      cls: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20", icon: CheckCircle2 },
    failed:      { label: "Action requise", cls: "bg-amber-500/10 text-amber-400 border-amber-500/20", icon: AlertTriangle },
    in_progress: { label: "En cours",       cls: "bg-blue-500/10 text-blue-400 border-blue-500/20",    icon: Clock },
    pending:     { label: "En attente",     cls: "bg-muted/50 text-muted-foreground border-border/40", icon: Clock },
  }[status];
  const Icon = cfg.icon;
  return (
    <span className={cn("inline-flex items-center gap-1 px-2 py-0.5 rounded-full border text-xs font-medium", cfg.cls)}>
      <Icon className="w-3 h-3" /> {cfg.label}
    </span>
  );
}

function ModeBadge({ mode }: { mode: DocProfile["mode"] }) {
  const labels = { prefill: "Pré-remplissage", redirect: "Redirection", prepared: "Email préparé", manual: "Démarche guidée" };
  const colors = { prefill: "text-blue-400", redirect: "text-violet-400", prepared: "text-amber-400", manual: "text-emerald-400" };
  return <span className={cn("text-xs font-medium", colors[mode])}>{labels[mode]}</span>;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();
  return (
    <button
      onClick={() => {
        navigator.clipboard.writeText(text).then(() => {
          setCopied(true);
          setTimeout(() => setCopied(false), 2500);
          toast({ title: "Copié dans le presse-papiers", description: "Vous pouvez maintenant coller dans votre messagerie." });
        });
      }}
      className="flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 font-medium transition-colors"
    >
      {copied ? <CheckCheck className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? "Copié !" : "Copier l'email"}
    </button>
  );
}

/* ══════════════════════════════════════════════
   Printable Fiche — used for both inline preview
   and print-to-PDF
══════════════════════════════════════════════ */

function ServiceFiche({ doc }: { doc: DocProfile }) {
  return (
    <div className="space-y-5 p-6 bg-background rounded-xl border border-border/50">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-lg font-bold">{doc.serviceName}</h3>
          <div className="flex items-center gap-2 mt-1">
            <ModeBadge mode={doc.mode} />
            <span className="text-xs text-muted-foreground">· Délai : {doc.processingTime}</span>
          </div>
        </div>
        <StatusBadge status={doc.status} />
      </div>

      {/* Address context */}
      <div className="rounded-lg bg-muted/30 border border-border/30 p-3">
        <p className="text-xs text-muted-foreground mb-1">Nouvelle adresse</p>
        <p className="text-sm font-medium">{doc.addressLabel}</p>
      </div>

      {/* Prepared by Serenya */}
      <div>
        <p className="text-xs font-semibold text-emerald-400 mb-2.5 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" /> Préparé par Serenya
        </p>
        <ul className="space-y-2">
          {doc.prepared.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
              {item}
            </li>
          ))}
        </ul>
      </div>

      {/* Required from user */}
      {doc.status !== "completed" && doc.required.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-amber-400 mb-2.5 flex items-center gap-1.5">
            <AlertTriangle className="w-3.5 h-3.5" /> Votre action requise
          </p>
          <ul className="space-y-2">
            {doc.required.map((item, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-foreground/80">
                <span className="w-5 h-5 rounded-full border border-amber-400/40 flex items-center justify-center flex-shrink-0 text-[10px] font-bold text-amber-400/80 mt-0.5">
                  {i + 1}
                </span>
                {item}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Prefill data */}
      {doc.prefillData && doc.prefillData.length > 0 && (
        <div className="rounded-lg border border-border/40 overflow-hidden">
          <div className="px-4 py-2 bg-muted/40 border-b border-border/30">
            <p className="text-xs font-medium text-muted-foreground">Données pré-remplies</p>
          </div>
          <div className="px-4 py-3 space-y-2">
            {doc.prefillData.map(d => (
              <div key={d.label} className="flex justify-between gap-3 text-sm">
                <span className="text-muted-foreground">{d.label}</span>
                <span className={cn("font-medium", d.masked ? "text-muted-foreground/40 font-mono" : "text-foreground")}>
                  {d.masked ? "••••••••" : d.value}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Checklist */}
      {doc.checklistItems && doc.checklistItems.length > 0 && (
        <div>
          <p className="text-xs font-semibold text-muted-foreground mb-2.5 flex items-center gap-1.5">
            <ListChecks className="w-3.5 h-3.5" /> Checklist
          </p>
          <ul className="space-y-2">
            {doc.checklistItems.map((item, i) => (
              <li key={i} className="flex items-start gap-2 text-sm">
                <div className={cn(
                  "w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5",
                  item.done ? "border-emerald-500 bg-emerald-500" : "border-border/50"
                )}>
                  {item.done && <CheckCircle2 className="w-3 h-3 text-white" />}
                </div>
                <span className={item.done ? "line-through text-muted-foreground/50" : "text-foreground/80"}>{item.label}</span>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Email template */}
      {doc.emailTemplate && (
        <div className="rounded-lg border border-border/40 overflow-hidden">
          <div className="flex items-center justify-between px-4 py-2 bg-muted/40 border-b border-border/30">
            <span className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5" /> Email préparé
            </span>
            <CopyButton text={doc.emailTemplate} />
          </div>
          <pre className="p-4 text-xs text-muted-foreground whitespace-pre-wrap font-mono leading-relaxed bg-muted/10">
            {doc.emailTemplate}
          </pre>
        </div>
      )}

      {/* Next steps */}
      <div>
        <p className="text-xs font-semibold text-muted-foreground mb-2.5 flex items-center gap-1.5">
          <ArrowRight className="w-3.5 h-3.5" /> Prochaines étapes
        </p>
        <ul className="space-y-2">
          {doc.nextSteps.map((step, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
              <span className="text-primary/60 flex-shrink-0">{i + 1}.</span>
              {step}
            </li>
          ))}
        </ul>
      </div>

      {/* Note */}
      <div className="rounded-lg bg-muted/20 border border-border/30 p-3 flex items-start gap-2.5">
        <Shield className="w-4 h-4 text-muted-foreground/40 flex-shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">{doc.orgNote}</p>
      </div>

      {/* Footer */}
      <div className="text-center pt-2 border-t border-border/20">
        <p className="text-[10px] text-muted-foreground/30">Document généré par Serenya · {new Date().toLocaleDateString("fr-FR")}</p>
        <p className="text-[10px] text-muted-foreground/25 mt-0.5">Aucune donnée sensible n&apos;est stockée sans consentement.</p>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   Document Card (list view)
══════════════════════════════════════════════ */

function DocumentCard({ doc, onOpen }: { doc: DocProfile; onOpen: () => void }) {
  const isActionRequired = doc.status === "failed" || doc.status === "pending";
  const completedCount = doc.checklistItems?.filter(i => i.done).length ?? 0;
  const totalChecklist = doc.checklistItems?.length ?? 0;

  return (
    <Card
      onClick={onOpen}
      className={cn(
        "p-4 cursor-pointer transition-all duration-200 hover:shadow-md hover:border-primary/20 group",
        isActionRequired ? "border-amber-500/20 bg-amber-500/[0.02]" : ""
      )}
    >
      <div className="flex items-start gap-3">
        <div className={cn(
          "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",
          doc.mode === "prefill" ? "bg-blue-500/10" :
          doc.mode === "redirect" ? "bg-violet-500/10" :
          doc.mode === "prepared" ? "bg-amber-500/10" : "bg-emerald-500/10"
        )}>
          <FileText className={cn("w-5 h-5",
            doc.mode === "prefill" ? "text-blue-400" :
            doc.mode === "redirect" ? "text-violet-400" :
            doc.mode === "prepared" ? "text-amber-400" : "text-emerald-400"
          )} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-0.5">
            <h3 className="font-semibold text-sm">{doc.serviceName}</h3>
            <StatusBadge status={doc.status} />
          </div>
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <ModeBadge mode={doc.mode} />
            <span>·</span>
            <span>{doc.processingTime}</span>
            {totalChecklist > 0 && (
              <>
                <span>·</span>
                <span className={completedCount === totalChecklist ? "text-emerald-400" : ""}>
                  {completedCount}/{totalChecklist} étapes
                </span>
              </>
            )}
          </div>
          <p className="text-xs text-muted-foreground/70 mt-1.5 line-clamp-2">{doc.orgNote}</p>
        </div>
        <ChevronRight className="w-4 h-4 text-muted-foreground/30 flex-shrink-0 mt-2 group-hover:text-primary/60 transition-colors" />
      </div>
    </Card>
  );
}

/* ══════════════════════════════════════════════
   Detail Drawer
══════════════════════════════════════════════ */

function DetailDrawer({ doc, onClose }: { doc: DocProfile; onClose: () => void }) {
  const { toast } = useToast();

  async function handleExportPDF() {
    try {
      const pdf = new jsPDF({ unit: "mm", format: "a4" });
      const pageW = 210;
      const margin = 16;
      const maxW = pageW - margin * 2;
      let y = 14;

      // Header
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(18);
      pdf.setTextColor(26, 26, 46);
      pdf.text(doc.serviceName, margin, y);
      y += 7;

      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(10);
      pdf.setTextColor(100, 100, 100);
      const modeLabel = doc.mode === "prefill" ? "Pré-remplissage" : doc.mode === "redirect" ? "Redirection sécurisée" : doc.mode === "prepared" ? "Email préparé" : "Démarche guidée";
      pdf.text(`${modeLabel}  ·  Délai : ${doc.processingTime}`, margin, y);
      y += 8;

      // Address box
      pdf.setFillColor(248, 250, 252);
      pdf.setDrawColor(226, 232, 240);
      pdf.roundedRect(margin, y - 3, maxW, 14, 2, 2, "FD");
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(8);
      pdf.setTextColor(100, 116, 139);
      pdf.text("Nouvelle adresse", margin + 3, y + 1);
      pdf.setFont("helvetica", "bold");
      pdf.setFontSize(10);
      pdf.setTextColor(26, 26, 46);
      const addrLines = pdf.splitTextToSize(doc.addressLabel, maxW - 6);
      pdf.text(addrLines, margin + 3, y + 6);
      y += 16 + addrLines.length * 3;

      // Prepared section
      y = addSection(pdf, "Préparé par Serenya", doc.prepared, y, "#059669", margin, maxW);

      // Required actions section
      if (doc.required.length > 0) {
        y = addSection(pdf, "Votre action requise", doc.required.map((r, i) => `${i + 1}. ${r}`), y, "#d97706", margin, maxW);
      }

      // Prefill data
      if (doc.prefillData && doc.prefillData.length > 0) {
        pdf.setFillColor(248, 250, 252);
        pdf.setDrawColor(226, 232, 240);
        const boxH = 6 + doc.prefillData.length * 6;
        pdf.roundedRect(margin, y - 3, maxW, boxH, 2, 2, "FD");
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(8);
        pdf.setTextColor(100, 116, 139);
        pdf.text("Données pré-remplies", margin + 3, y + 1);
        y += 5;
        for (const d of doc.prefillData) {
          pdf.setFont("helvetica", "normal");
          pdf.setFontSize(9);
          pdf.setTextColor(100, 116, 139);
          pdf.text(d.label, margin + 3, y);
          pdf.setFont("helvetica", "bold");
          pdf.setTextColor(26, 26, 46);
          const val = d.masked ? "••••••••" : d.value;
          pdf.text(val, margin + maxW - 3 - pdf.getTextWidth(val), y);
          y += 5.5;
        }
        y += 4;
      }

      // Email template
      if (doc.emailTemplate) {
        if (y > 250) { pdf.addPage(); y = 14; }
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(10);
        pdf.setTextColor(5, 150, 105);
        pdf.text("Email préparé", margin, y);
        y += 5;
        pdf.setFont("helvetica", "normal");
        pdf.setFontSize(8);
        pdf.setTextColor(60, 60, 60);
        const emailLines = pdf.splitTextToSize(doc.emailTemplate, maxW - 6);
        for (const line of emailLines) {
          if (y > 270) { pdf.addPage(); y = 14; }
          pdf.text(line, margin, y);
          y += 3.5;
        }
        y += 4;
      }

      // Next steps
      y = addSection(pdf, "Prochaines étapes", doc.nextSteps.map((s, i) => `${i + 1}. ${s}`), y, "#059669", margin, maxW);

      // Footer
      pdf.setFont("helvetica", "normal");
      pdf.setFontSize(7);
      pdf.setTextColor(148, 163, 184);
      const dateStr = new Date().toLocaleDateString("fr-FR");
      pdf.text(`Document généré par Serenya · ${dateStr}`, margin, 285);
      pdf.text("Aucune donnée sensible n'est stockée sans consentement.", margin, 289);

      pdf.save(`Fiche_${doc.serviceName.replace(/\s+/g, "_")}_Serenya.pdf`);
      toast({ title: "PDF téléchargé", description: `Fiche ${doc.serviceName} enregistrée.` });
    } catch (e: any) {
      toast({ title: "Erreur PDF", description: e?.message || "Impossible de générer le PDF.", variant: "destructive" });
    }
  }

  function addSection(
    pdf: jsPDF,
    title: string,
    items: string[],
    startY: number,
    color: string,
    margin: number,
    maxW: number,
  ): number {
    let y = startY;
    if (y > 260) { pdf.addPage(); y = 14; }
    pdf.setFont("helvetica", "bold");
    pdf.setFontSize(9);
    pdf.setTextColor(color === "#059669" ? 5 : 217, color === "#059669" ? 150 : 119, color === "#059669" ? 105 : 6);
    pdf.text(title.toUpperCase(), margin, y);
    y += 5;
    pdf.setFont("helvetica", "normal");
    pdf.setFontSize(9.5);
    pdf.setTextColor(26, 26, 46);
    for (const item of items) {
      const lines = pdf.splitTextToSize(`• ${item}`, maxW - 4);
      for (const line of lines) {
        if (y > 275) { pdf.addPage(); y = 14; }
        pdf.text(line, margin + 2, y);
        y += 4;
      }
      y += 1;
    }
    return y + 2;
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-40 bg-black/55 backdrop-blur-[3px]"
        onClick={onClose}
      />
      <motion.div
        initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 260 }}
        className="fixed right-0 top-0 bottom-0 z-50 w-full sm:w-[520px] bg-background border-l border-border/50 shadow-2xl flex flex-col"
      >
        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border/40 flex-shrink-0">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
            <FileText className="w-5 h-5 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-base">Fiche administrative</h2>
            <p className="text-xs text-muted-foreground">{doc.serviceName}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Actions bar */}
        <div className="px-5 py-3 border-b border-border/30 flex items-center gap-2 flex-shrink-0 bg-muted/10">
          <Button size="sm" variant="outline" className="gap-1.5 text-xs h-9" onClick={handleExportPDF}>
            <Printer className="w-3.5 h-3.5" /> Télécharger PDF
          </Button>
          {doc.emailTemplate && (
            <CopyButton text={doc.emailTemplate} />
          )}
          <div className="ml-auto flex items-center gap-1.5 text-xs text-muted-foreground/40">
            <Shield className="w-3 h-3" /> RGPD
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-5">
          <ServiceFiche doc={doc} />
        </div>
      </motion.div>
    </>
  );
}

/* ══════════════════════════════════════════════
   Main Document Center
══════════════════════════════════════════════ */

interface DocumentCenterProps {
  docs: DocProfile[];
  className?: string;
}

export default function DocumentCenter({ docs, className }: DocumentCenterProps) {
  const [selectedDoc, setSelectedDoc] = useState<DocProfile | null>(null);
  const [filter, setFilter] = useState<"all" | "action" | "completed">("all");

  const filtered = useMemo(() => {
    if (filter === "action") return docs.filter(d => d.status === "failed" || d.status === "pending");
    if (filter === "completed") return docs.filter(d => d.status === "completed");
    return docs;
  }, [docs, filter]);

  const actionCount = docs.filter(d => d.status === "failed" || d.status === "pending").length;
  const completedCount = docs.filter(d => d.status === "completed").length;

  return (
    <div className={cn("space-y-4", className)}>
      {/* Stats */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setFilter("all")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
            filter === "all" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted"
          )}
        >
          Tous ({docs.length})
        </button>
        <button
          onClick={() => setFilter("action")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-medium transition-colors flex items-center gap-1.5",
            filter === "action" ? "bg-amber-500/10 text-amber-400" : "text-muted-foreground hover:bg-muted"
          )}
        >
          {actionCount > 0 && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}
          Action requise ({actionCount})
        </button>
        <button
          onClick={() => setFilter("completed")}
          className={cn(
            "px-3 py-1.5 rounded-lg text-xs font-medium transition-colors",
            filter === "completed" ? "bg-emerald-500/10 text-emerald-400" : "text-muted-foreground hover:bg-muted"
          )}
        >
          Terminés ({completedCount})
        </button>
      </div>

      {/* Document list */}
      <div className="space-y-3">
        <AnimatePresence mode="popLayout">
          {filtered.map(doc => (
            <motion.div
              key={`${doc.serviceName}-${doc.addressLabel}`}
              layout
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96 }}
              transition={{ duration: 0.2 }}
            >
              <DocumentCard doc={doc} onOpen={() => setSelectedDoc(doc)} />
            </motion.div>
          ))}
        </AnimatePresence>

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <FileText className="w-10 h-10 text-muted-foreground/20 mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">Aucun document dans cette catégorie.</p>
            <p className="text-xs text-muted-foreground/50 mt-1">Lancez une préparation pour générer des fiches.</p>
          </div>
        )}
      </div>

      {/* Detail drawer */}
      <AnimatePresence>
        {selectedDoc && (
          <DetailDrawer doc={selectedDoc} onClose={() => setSelectedDoc(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ══════════════════════════════════════════════
   Compact dashboard widget
══════════════════════════════════════════════ */

export function DocumentHubWidget({ docs, onOpen }: { docs: DocProfile[]; onOpen: () => void }) {
  const actionCount = docs.filter(d => d.status === "failed" || d.status === "pending").length;
  const completedCount = docs.filter(d => d.status === "completed").length;
  const inProgress = docs.filter(d => d.status === "in_progress").length;

  return (
    <Card className="p-4 cursor-pointer hover:border-primary/20 transition-all" onClick={onOpen}>
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
          <FileText className="w-5 h-5 text-primary" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-sm">Documents préparés</h3>
          <p className="text-xs text-muted-foreground mt-0.5">
            {docs.length === 0 ? "Aucun document encore" :
             `${docs.length} fiche${docs.length > 1 ? "s" : ""} · ${completedCount} terminée${completedCount > 1 ? "s" : ""}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          {actionCount > 0 && (
            <Badge variant="outline" className="text-amber-400 border-amber-500/20 bg-amber-500/10 text-xs">
              <AlertTriangle className="w-3 h-3 mr-1" /> {actionCount}
            </Badge>
          )}
          {inProgress > 0 && (
            <Badge variant="outline" className="text-blue-400 border-blue-500/20 bg-blue-500/10 text-xs">
              <Clock className="w-3 h-3 mr-1" /> {inProgress}
            </Badge>
          )}
          <ChevronRight className="w-4 h-4 text-muted-foreground/30" />
        </div>
      </div>
    </Card>
  );
}
