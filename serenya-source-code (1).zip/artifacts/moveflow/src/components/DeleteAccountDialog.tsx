import { useState } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { Trash2, AlertTriangle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";

export default function DeleteAccountDialog() {
  const [open, setOpen] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  async function handleDelete() {
    setLoading(true);
    try {
      const res = await fetch("/api/user", { method: "DELETE", credentials: "include" });
      if (res.ok) {
        toast({ variant: "destructive", title: "Compte supprimé", description: "Vos données ont été effacées. Déconnexion en cours..." });
        setTimeout(() => {
          window.location.href = "/";
        }, 2000);
      } else {
        toast({ variant: "destructive", title: "Erreur", description: "Impossible de supprimer le compte. Réessayez." });
        setLoading(false);
      }
    } catch {
      toast({ variant: "destructive", title: "Erreur réseau", description: "Vérifiez votre connexion et réessayez." });
      setLoading(false);
    }
  }

  return (
    <>
      <Button
        variant="outline"
        size="sm"
        className="gap-2 text-destructive border-destructive/30 hover:bg-destructive/5"
        onClick={() => setOpen(true)}
      >
        <Trash2 className="w-3.5 h-3.5" /> Supprimer
      </Button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
            onClick={() => !loading && setOpen(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-card border border-border/60 rounded-2xl p-6 max-w-md w-full shadow-2xl"
              onClick={(e: React.MouseEvent) => e.stopPropagation()}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center flex-shrink-0">
                  <AlertTriangle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <h3 className="font-semibold">Supprimer votre compte</h3>
                  <p className="text-xs text-muted-foreground">Action irréversible (RGPD Art. 17)</p>
                </div>
              </div>

              <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                Cette action supprime définitivement :
                <ul className="mt-2 space-y-1 text-xs text-muted-foreground/80 list-disc pl-4">
                  <li>Toutes vos adresses enregistrées</li>
                  <li>Toutes vos automations et leurs tâches</li>
                  <li>Vos organismes connectés</li>
                  <li>Vos notifications et préférences</li>
                </ul>
              </p>

              {!confirming ? (
                <div className="flex gap-3 justify-end">
                  <Button variant="outline" size="sm" onClick={() => setOpen(false)}>Annuler</Button>
                  <Button variant="destructive" size="sm" className="gap-2" onClick={() => setConfirming(true)}>
                    <Trash2 className="w-3.5 h-3.5" /> Continuer
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="p-3 rounded-lg bg-red-500/5 border border-red-500/20">
                    <p className="text-xs text-red-400 font-medium">Confirmez en cliquant ci-dessous :</p>
                  </div>
                  <div className="flex gap-3 justify-end">
                    <Button variant="outline" size="sm" disabled={loading} onClick={() => setOpen(false)}>Annuler</Button>
                    <Button variant="destructive" size="sm" className="gap-2" disabled={loading} onClick={handleDelete}>
                      {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      {loading ? "Suppression..." : "Confirmer la suppression"}
                    </Button>
                  </div>
                </div>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
