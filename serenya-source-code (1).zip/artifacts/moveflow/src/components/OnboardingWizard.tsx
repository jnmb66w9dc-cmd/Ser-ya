import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { MapPin, Building2, Zap, ArrowRight, X, CheckCircle2, Shield, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useUser } from "@clerk/react";
import { Link, useLocation } from "wouter";

const STORAGE_KEY = "serenya_onboarded";

interface Step {
  icon: React.ElementType;
  iconBg: string;
  iconColor: string;
  title: string;
  subtitle: string;
  body: React.ReactNode;
}

function FeatureRow({ icon: Icon, color, text }: { icon: React.ElementType; color: string; text: string }) {
  return (
    <div className="flex items-center gap-3">
      <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0", color)}>
        <Icon className="w-4 h-4" />
      </div>
      <span className="text-sm text-foreground/80 leading-snug">{text}</span>
    </div>
  );
}

const PUBLIC_PATHS = ["/", "/landing", "/sign-in", "/sign-up", "/pricing", "/confidentialite", "/cgu", "/contact", "/demo"];

export default function OnboardingWizard() {
  const { user } = useUser();
  const [location] = useLocation();
  const [step, setStep] = useState(0);
  const [visible, setVisible] = useState(false);

  const isPublicRoute = PUBLIC_PATHS.some(p => location === p || location.startsWith("/sign-in") || location.startsWith("/sign-up") || location.startsWith("/partage/"));

  useEffect(() => {
    if (isPublicRoute || !user) return;
    const done = localStorage.getItem(STORAGE_KEY);
    if (!done) {
      const t = setTimeout(() => setVisible(true), 600);
      return () => clearTimeout(t);
    }
    return undefined;
  }, [isPublicRoute, user]);

  function dismiss() {
    localStorage.setItem(STORAGE_KEY, "1");
    setVisible(false);
  }

  function next() {
    if (step < STEPS.length - 1) {
      setStep(s => s + 1);
    } else {
      dismiss();
    }
  }

  const firstName = user?.firstName ?? "là";

  const STEPS: Step[] = [
    {
      icon: Sparkles,
      iconBg: "bg-primary/15",
      iconColor: "text-primary",
      title: `Bienvenue sur Serenya${firstName ? `, ${firstName}` : ""} 👋`,
      subtitle: "Version bêta publique",
      body: (
        <div className="space-y-4">
          <div className="flex items-center justify-center gap-2 mb-1">
            <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 text-[10px] font-semibold border border-amber-500/20">
              BETA
            </span>
            <span className="text-[10px] text-muted-foreground">
              Préparations en déploiement progressif
            </span>
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed text-center">
            Serenya prépare et guide vos changements d'adresse auprès de vos organismes.
            Vous gardez le contrôle total — aucune modification n'est effectuée sans votre validation.
          </p>
          <div className="bg-muted/40 rounded-xl p-4 space-y-3">
            <FeatureRow icon={MapPin} color="bg-blue-500/10 text-blue-400" text="Saisissez votre nouvelle adresse une seule fois" />
            <FeatureRow icon={Building2} color="bg-violet-500/10 text-violet-400" text="Connectez vos banques, opérateurs, assurances" />
            <FeatureRow icon={Zap} color="bg-amber-500/10 text-amber-400" text="Serenya prépare les démarches — vous validez chaque étape" />
          </div>
        </div>
      ),
    },
    {
      icon: Shield,
      iconBg: "bg-emerald-500/15",
      iconColor: "text-emerald-400",
      title: "Vos données sont protégées",
      subtitle: "Confidentialité & sécurité",
      body: (
        <div className="space-y-4">
          <p className="text-sm text-muted-foreground leading-relaxed text-center">
            Serenya ne stocke jamais vos mots de passe. Vos données restent chiffrées et hébergées en Europe.
          </p>
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: "Chiffrement AES-256", sub: "Toutes les données" },
              { label: "RGPD conforme", sub: "Hébergé en Europe" },
              { label: "Zéro mot de passe", sub: "Aucune credential stockée" },
              { label: "Suppression totale", sub: "Sur simple demande" },
            ].map(item => (
              <div key={item.label} className="bg-muted/30 rounded-xl p-3">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400 flex-shrink-0" />
                  <span className="text-xs font-semibold">{item.label}</span>
                </div>
                <p className="text-xs text-muted-foreground pl-4">{item.sub}</p>
              </div>
            ))}
          </div>
        </div>
      ),
    },
    {
      icon: MapPin,
      iconBg: "bg-blue-500/15",
      iconColor: "text-blue-400",
      title: "Commençons ensemble",
      subtitle: "3 étapes pour démarrer",
      body: (
        <div className="space-y-3">
          {[
            { num: "1", label: "Ajoutez votre nouvelle adresse", href: "/addresses", cta: "Ajouter une adresse" },
            { num: "2", label: "Connectez vos services (banque, opérateur…)", href: "/services", cta: "Parcourir les services" },
            { num: "3", label: "Lancez la préparation depuis le tableau de bord", href: "/dashboard", cta: null },
          ].map((item) => (
            <div key={item.num} className="flex items-center gap-3 p-3 rounded-xl bg-muted/30">
              <div className="w-6 h-6 rounded-full bg-primary/15 text-primary text-xs font-bold flex items-center justify-center flex-shrink-0">
                {item.num}
              </div>
              <p className="text-sm flex-1 leading-snug">{item.label}</p>
            </div>
          ))}
        </div>
      ),
    },
  ];

  const currentStep = STEPS[step];
  const Icon = currentStep.icon;

  if (isPublicRoute) return null;

  return (
    <AnimatePresence>
      {visible && (
        <>
          {/* Backdrop */}
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm"
            onClick={dismiss}
          />

          {/* Dialog */}
          <motion.div
            key="dialog"
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 28 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 pointer-events-none"
          >
            <div
              className="pointer-events-auto w-full max-w-sm bg-card border border-border rounded-2xl shadow-2xl overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="relative p-6 pb-4">
                <button
                  onClick={dismiss}
                  className="absolute top-4 right-4 w-7 h-7 rounded-full bg-muted/60 flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>

                <AnimatePresence mode="wait">
                  <motion.div
                    key={step}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -12 }}
                    transition={{ duration: 0.22 }}
                    className="text-center space-y-3"
                  >
                    <div className={cn("w-14 h-14 rounded-2xl flex items-center justify-center mx-auto", currentStep.iconBg)}>
                      <Icon className={cn("w-7 h-7", currentStep.iconColor)} />
                    </div>
                    <div>
                      <h2 className="font-bold text-lg leading-snug">{currentStep.title}</h2>
                      <p className="text-xs text-muted-foreground mt-0.5">{currentStep.subtitle}</p>
                    </div>
                    <div className="text-left">{currentStep.body}</div>
                  </motion.div>
                </AnimatePresence>
              </div>

              {/* Footer */}
              <div className="px-6 pb-6 space-y-3">
                {/* Dots */}
                <div className="flex justify-center gap-1.5">
                  {STEPS.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setStep(i)}
                      className={cn(
                        "rounded-full transition-all duration-300",
                        i === step ? "w-5 h-1.5 bg-primary" : "w-1.5 h-1.5 bg-muted-foreground/30"
                      )}
                    />
                  ))}
                </div>

                {/* CTA */}
                {step === STEPS.length - 1 ? (
                  <div className="space-y-2">
                    <Link href="/addresses">
                      <Button className="w-full gap-2" onClick={dismiss}>
                        <MapPin className="w-4 h-4" />
                        Ajouter mon adresse
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </Link>
                    <button
                      onClick={dismiss}
                      className="w-full text-xs text-muted-foreground/60 hover:text-muted-foreground transition-colors py-1"
                    >
                      Je le ferai plus tard
                    </button>
                  </div>
                ) : (
                  <Button className="w-full gap-2" onClick={next}>
                    Suivant
                    <ArrowRight className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
