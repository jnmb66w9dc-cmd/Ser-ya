import { cn } from "@/lib/utils";

export const STATUS_CFG = {
  queued:    { label: "En attente",       cls: "bg-muted/60 text-muted-foreground border-border/50" },
  running:   { label: "En cours",         cls: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  completed: { label: "Confirmé",         cls: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  partial:   { label: "Partiel",          cls: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  failed:    { label: "Action requise",   cls: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  cancelled: { label: "Annulé",           cls: "bg-muted/60 text-muted-foreground border-border/50" },
  skipped:   { label: "Non traité",       cls: "bg-muted/60 text-muted-foreground border-border/50" },
};

export const AUTO_STATUS_CFG = {
  queued:    { label: "En file",   icon: "Clock",         color: "text-muted-foreground", bg: "bg-muted/60 text-muted-foreground" },
  running:   { label: "En cours",  icon: "Zap",           color: "text-blue-500",         bg: "bg-blue-500/10 text-blue-500" },
  completed: { label: "Terminé",   icon: "CheckCircle2",  color: "text-emerald-500",      bg: "bg-emerald-500/10 text-emerald-500" },
  partial:   { label: "Partiel",   icon: "AlertTriangle", color: "text-amber-500",        bg: "bg-amber-500/10 text-amber-500" },
  failed:    { label: "Échoué",   icon: "XCircle",       color: "text-red-500",          bg: "bg-red-500/10 text-red-500" },
  cancelled: { label: "Annulé",    icon: "Ban",           color: "text-muted-foreground", bg: "bg-muted/60 text-muted-foreground" },
};

export function StatusPill({ status }: { status: string }) {
  const c = STATUS_CFG[status as keyof typeof STATUS_CFG] ?? STATUS_CFG.queued;
  return <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium", c.cls)}>{c.label}</span>;
}
