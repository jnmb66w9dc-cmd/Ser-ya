import { cn } from "@/lib/utils";
import { ORG_COLORS } from "./OrgProfiles";

export function ServiceAvatar({ name, size = "md" }: { name: string; size?: "sm" | "md" | "lg" }) {
  const bg = ORG_COLORS[name] ?? "bg-primary";
  const sz = size === "sm" ? "w-8 h-8 text-xs" : size === "lg" ? "w-12 h-12 text-lg" : "w-9 h-9 text-sm";
  return (
    <div className={cn("rounded-xl flex items-center justify-center text-white font-bold flex-shrink-0", bg, sz)}>
      {name[0]}
    </div>
  );
}
