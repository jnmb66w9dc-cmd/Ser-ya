/* ────────────────────────────────────────────────────────────────
   ORG PROFILES — chaque organisation est unique
──────────────────────────────────────────────────────────────── */

export type AssistanceMode = "prefill" | "redirect" | "prepared" | "manual";

export interface OrgProfile {
  mode:              AssistanceMode;
  assistanceLabel:   string;
  processingTime:    string;
  modeLabel:         string;
  modeColor:         string;
  modeBg:            string;
  prepared:          string[];
  required:          string[];
  actionLabel:       string;
  orgNote:           string;
  securityNote:      string;
  nextSteps:         string[];
  prefillData?:      { label: string; value: string; masked?: boolean }[];
  checklistItems?:   { label: string; done: boolean }[];
  emailTemplate?:    (addr: string) => string;
}

const ORG_PROFILES: Record<string, OrgProfile> = {
  "EDF": {
    mode: "prefill",
    assistanceLabel: "Pré-remplissage disponible",
    processingTime: "24 à 48h",
    modeLabel: "Pré-remplissage automatique",
    modeColor: "text-blue-400", modeBg: "bg-blue-500/10 border-blue-500/20",
    prepared: ["Formulaire de changement d'adresse EDF pré-rempli","Numéro de contrat identifié","Date d'effet calée"],
    required: ["Vérifiez les informations","Validez — vous gardez le contrôle"],
    actionLabel: "Accéder à Mon EDF",
    orgNote: "EDF met à jour l'adresse dans les 24–48h après validation.",
    securityNote: "EDF utilise un portail sécurisé My EDF. Aucune donnée n'est soumise sans votre accord.",
    nextSteps: ["Email de confirmation sous 24–48h","Prochaine facture à la nouvelle adresse"],
    prefillData: [{ label: "Nouvelle adresse", value: "Issue de votre profil" },{ label: "Date d'effet", value: "1er jour du mois suivant" },{ label: "N° contrat", value: "Détecté", masked: true }],
  },
  "Orange": {
    mode: "prefill",
    assistanceLabel: "Mise à jour instantanée",
    processingTime: "Immédiat",
    modeLabel: "Pré-remplissage automatique",
    modeColor: "text-blue-400", modeBg: "bg-blue-500/10 border-blue-500/20",
    prepared: ["Adresse de facturation et livraison préparées","Options de transfert de ligne visibles"],
    required: ["Confirmez la nouvelle adresse","Validez le changement"],
    actionLabel: "Accéder à Mon compte Orange",
    orgNote: "Orange applique la modification immédiatement sur votre espace client.",
    securityNote: "Orange exige votre connexion directe. Serenya prépare — vous validez.",
    nextSteps: ["Modification visible immédiatement","Prochaine facture à la nouvelle adresse"],
    prefillData: [{ label: "Nouvelle adresse", value: "Issue de votre profil" },{ label: "Ligne", value: "Détectée", masked: true }],
  },
  "BNP Paribas": {
    mode: "redirect",
    assistanceLabel: "Guide pas à pas",
    processingTime: "48h à 5 jours",
    modeLabel: "Guide de navigation",
    modeColor: "text-emerald-400", modeBg: "bg-emerald-500/10 border-emerald-500/20",
    prepared: ["Instructions personnalisées pour votre profil BNP","Sections exactes à modifier identifiées"],
    required: ["Connectez-vous à votre espace client","Suivez le guide étape par étape"],
    actionLabel: "Accéder à Mon Compte BNP",
    orgNote: "BNP Paribas traite les changements d'adresse sous 48h–5j.",
    securityNote: "L'accès à votre espace BNP reste sous votre contrôle exclusif.",
    nextSteps: ["Mise à jour confirmée par email sous 48h","Adresse visible sur votre RIB"],
  },
  "AXA": {
    mode: "prepared",
    assistanceLabel: "Email prêt à envoyer",
    processingTime: "5 à 10 jours",
    modeLabel: "Email pré-rédigé",
    modeColor: "text-amber-400", modeBg: "bg-amber-500/10 border-amber-500/20",
    prepared: ["Email de demande rédigé en français formel","Coordonnées du service AXA identifiées"],
    required: ["Relisez l'email","Envoyez depuis votre messagerie"],
    actionLabel: "Copier l'email",
    orgNote: "AXA traite les demandes par email. Comptez 5–10 jours.",
    securityNote: "Votre envoi depuis votre propre boîte mail garantit l'authenticité.",
    nextSteps: ["Confirmation par email sous 5–10 jours","Attestation d'assurance à la nouvelle adresse"],
    emailTemplate: (addr) => `Objet : Mise à jour d'adresse — AXA\n\nMadame, Monsieur,\n\nJe vous contacte afin de vous informer d'un changement d'adresse.\n\nNouvelle adresse :\n${addr}\n\nCordialement,\n[Votre prénom et nom]`,
  },
  "Bouygues Telecom": {
    mode: "prefill",
    assistanceLabel: "Pré-remplissage disponible",
    processingTime: "24h",
    modeLabel: "Pré-remplissage automatique",
    modeColor: "text-blue-400", modeBg: "bg-blue-500/10 border-blue-500/20",
    prepared: ["Formulaire Bouygues pré-rempli","N° de ligne et abonné détectés"],
    required: ["Vérifiez les informations","Confirmez la mise à jour"],
    actionLabel: "Accéder à Mon compte Bouygues",
    orgNote: "Bouygues met à jour vos coordonnées sous 24h.",
    securityNote: "L'accès reste sous votre contrôle exclusif.",
    nextSteps: ["SMS de confirmation sous 24h","Prochaine facture à la nouvelle adresse"],
  },
  "CPAM": {
    mode: "redirect",
    assistanceLabel: "Guide ameli.fr",
    processingTime: "1 à 3 semaines",
    modeLabel: "Guide de navigation",
    modeColor: "text-emerald-400", modeBg: "bg-emerald-500/10 border-emerald-500/20",
    prepared: ["Instructions pour ameli.fr","Sections exactes à modifier"],
    required: ["Connectez-vous à ameli.fr","Suivez le guide étape par étape"],
    actionLabel: "Accéder à ameli.fr",
    orgNote: "La CPAM traite les changements sous 1–3 semaines.",
    securityNote: "ameli.fr est le portail officiel sécurisé de l'Assurance Maladie.",
    nextSteps: ["Nouvelle Carte Vitale envoyée","Coordonnées mises à jour"],
  },
  "Impôts": {
    mode: "redirect",
    assistanceLabel: "Guide impots.gouv.fr",
    processingTime: "Immédiat",
    modeLabel: "Guide de navigation",
    modeColor: "text-emerald-400", modeBg: "bg-emerald-500/10 border-emerald-500/20",
    prepared: ["Instructions pour impots.gouv.fr","Section « Gérer mes coordonnées » identifiée"],
    required: ["Connectez-vous à impots.gouv.fr","Suivez le guide étape par étape"],
    actionLabel: "Accéder à impots.gouv.fr",
    orgNote: "Les impôts mettent à jour l'adresse immédiatement.",
    securityNote: "impots.gouv.fr est le portail officiel de la DGFiP.",
    nextSteps: ["Adresse visible immédiatement","Prochain avis d'imposition à la nouvelle adresse"],
  },
};

export function getProfile(serviceName: string): OrgProfile {
  if (ORG_PROFILES[serviceName]) return ORG_PROFILES[serviceName];
  return {
    mode: "prepared",
    assistanceLabel: "Demande prête à envoyer",
    processingTime: "5 à 10 jours",
    modeLabel: "Demande rédigée",
    modeColor: "text-amber-400", modeBg: "bg-amber-500/10 border-amber-500/20",
    prepared: ["Email de demande rédigé en français formel","Coordonnées du service identifiées"],
    required: ["Relisez l'email","Envoyez depuis votre messagerie"],
    actionLabel: "Copier l'email",
    orgNote: `${serviceName} traite les demandes par email. Comptez 5–10 jours.`,
    securityNote: `Votre envoi depuis votre propre boîte mail garantit l'authenticité.`,
    nextSteps: ["Confirmation par email sous 5–10 jours","Mise à jour visible"],
    emailTemplate: (addr) => `Objet : Mise à jour d'adresse — ${serviceName}\n\nMadame, Monsieur,\n\nJe vous contacte afin de vous informer d'un changement d'adresse.\n\nNouvelle adresse :\n${addr}\n\nCordialement,\n[Votre prénom et nom]`,
  };
}

/* ── UI HELPERS ── */

export const ORG_COLORS: Record<string, string> = {
  "EDF": "bg-blue-600", "Orange": "bg-orange-500", "BNP Paribas": "bg-emerald-700",
  "Amazon": "bg-amber-500", "Free": "bg-red-600", "AXA": "bg-sky-700",
  "MAIF": "bg-green-600", "La Poste": "bg-yellow-600", "CPAM": "bg-blue-700",
  "SFR": "bg-red-700", "Netflix": "bg-red-600", "PayPal": "bg-blue-500",
  "CAF": "bg-indigo-600", "Société Générale": "bg-red-800", "Crédit Agricole": "bg-blue-800",
  "Engie": "bg-teal-600", "Spotify": "bg-green-500", "Bouygues Telecom": "bg-cyan-600",
  "Impôts": "bg-slate-600", "Pôle Emploi": "bg-rose-700", "Banque Postale": "bg-yellow-700",
  "Caisse d'Épargne": "bg-red-500", "LCL": "bg-blue-600", "SNCF": "bg-blue-500",
};

export function getConfidencePct(serviceName: string): number {
  const sum = serviceName.split("").reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return 92 + (sum % 8);
}
