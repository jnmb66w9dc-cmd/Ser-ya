import { motion } from "framer-motion";
import { Check, Clock, Send, PackageOpen, Loader2, AlertTriangle, FileText } from "lucide-react";
import { cn } from "@/lib/utils";

interface TrackingStep {
  status: string;
  label: string;
  description: string;
  timestamp?: string;
}

interface Props {
  steps: TrackingStep[];
  currentStatus: string;
  serviceName: string;
}

const STEP_ICONS: Record<string, React.ReactNode> = {
  prepared:     <FileText className="w-3.5 h-3.5" />,
  submitted:    <Send className="w-3.5 h-3.5" />,
  acknowledged: <PackageOpen className="w-3.5 h-3.5" />,
  processing:   <Loader2 className="w-3.5 h-3.5" />,
  completed:    <Check className="w-3.5 h-3.5" />,
  failed:       <AlertTriangle className="w-3.5 h-3.5" />,
};

const STEP_ORDER = ["prepared", "submitted", "acknowledged", "processing", "completed"];

export default function ServiceTrackingTimeline({ steps, currentStatus, serviceName }: Props) {
  const currentIdx = STEP_ORDER.indexOf(currentStatus);
  const failed = currentStatus === "failed";

  return (
    <div className="w-full">
      <div className="flex items-center justify-between relative">
        {/* Connecting line */}
        <div className="absolute top-[18px] left-0 right-0 h-[2px] bg-muted/40 -z-0" />
        <motion.div
          className="absolute top-[18px] left-0 h-[2px] bg-primary/60 -z-0"
          initial={{ width: "0%" }}
          animate={{ width: failed ? "75%" : `${Math.max(0, (currentIdx / (STEP_ORDER.length - 1)) * 100)}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />

        {steps.map((step, i) => {
          const stepIdx = STEP_ORDER.indexOf(step.status);
          const isDone = stepIdx <= currentIdx && !failed;
          const isActive = step.status === currentStatus;
          const isFailedStep = failed && step.status === "processing";

          return (
            <div key={step.status} className="flex flex-col items-center gap-1.5 relative z-10">
              <motion.div
                className={cn(
                  "w-9 h-9 rounded-full flex items-center justify-center border-2 transition-colors duration-300",
                  isFailedStep ? "bg-amber-500/15 border-amber-500 text-amber-400" :
                  isDone ? "bg-emerald-500/15 border-emerald-500 text-emerald-400" :
                  isActive ? "bg-primary/15 border-primary text-primary animate-pulse" :
                  "bg-muted/40 border-muted/60 text-muted-foreground"
                )}
                initial={isActive ? { scale: 0.8 } : { scale: 1 }}
                animate={isActive ? { scale: [1, 1.1, 1] } : { scale: 1 }}
                transition={isActive ? { duration: 2, repeat: Infinity } : {}}
              >
                {isDone && step.status !== "completed" ? <Check className="w-3.5 h-3.5" /> :
                 isFailedStep ? <AlertTriangle className="w-3.5 h-3.5" /> :
                 STEP_ICONS[step.status] ?? <Clock className="w-3.5 h-3.5" />}
              </motion.div>
              <span className={cn(
                "text-[10px] font-medium leading-tight text-center max-w-[60px]",
                isFailedStep ? "text-amber-400" :
                isDone ? "text-emerald-400" :
                isActive ? "text-primary" :
                "text-muted-foreground/50"
              )}>
                {step.label}
              </span>
              {isActive && step.timestamp && (
                <motion.span
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-[9px] text-muted-foreground/40 absolute -bottom-4 whitespace-nowrap"
                >
                  {new Date(step.timestamp).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                </motion.span>
              )}
            </div>
          );
        })}
      </div>

      {/* Current status description */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="mt-5 p-3 rounded-lg bg-muted/20 border border-border/30"
      >
        <p className="text-xs text-muted-foreground">
          <span className="font-medium text-foreground">{serviceName}</span>
          {" — "}
          {steps.find(s => s.status === currentStatus)?.description ?? "En attente de mise à jour"}
        </p>
      </motion.div>
    </div>
  );
}
