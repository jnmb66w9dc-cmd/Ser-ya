import { motion } from "@/lib/motion-compat";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import type { LucideIcon } from "lucide-react";

interface EmptyStateProps {
  icon: LucideIcon;
  iconColor?: string;
  iconBg?: string;
  iconBorder?: string;
  title: string;
  description: string;
  hint?: string;
  action?: {
    label: string;
    onClick?: () => void;
    href?: string;
    variant?: "default" | "outline" | "ghost";
    icon?: LucideIcon;
  };
  secondaryAction?: {
    label: string;
    onClick?: () => void;
    href?: string;
    icon?: LucideIcon;
  };
  className?: string;
}

function ActionButton({ action }: { action: NonNullable<EmptyStateProps["action"]> }) {
  const Icon = action.icon;
  if (action.href) {
    return (
      <Link href={action.href}>
        <Button className="gap-2" variant={action.variant ?? "default"}>
          {Icon && <Icon className="w-4 h-4" />}
          {action.label}
        </Button>
      </Link>
    );
  }
  return (
    <Button className="gap-2" variant={action.variant ?? "default"} onClick={action.onClick}>
      {Icon && <Icon className="w-4 h-4" />}
      {action.label}
    </Button>
  );
}

function SecondaryButton({ action }: { action: NonNullable<EmptyStateProps["secondaryAction"]> }) {
  const Icon = action.icon;
  if (action.href) {
    return (
      <Link href={action.href}>
        <Button variant="outline" className="gap-2">
          {Icon && <Icon className="w-4 h-4" />}
          {action.label}
        </Button>
      </Link>
    );
  }
  return (
    <Button variant="outline" className="gap-2" onClick={action.onClick}>
      {Icon && <Icon className="w-4 h-4" />}
      {action.label}
    </Button>
  );
}

export default function EmptyState({
  icon: Icon,
  iconColor = "text-primary/60",
  iconBg = "bg-primary/10",
  iconBorder = "border-primary/20",
  title,
  description,
  hint,
  action,
  secondaryAction,
  className,
}: EmptyStateProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: "easeOut" }}
      className={cn(
        "py-16 text-center border border-dashed border-border/50 rounded-2xl bg-muted/[0.03]",
        className
      )}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.1, duration: 0.35, type: "spring", stiffness: 300, damping: 20 }}
        className={cn(
          "w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4",
          "border transition-all duration-300",
          iconBg, iconBorder
        )}
      >
        <Icon className={cn("w-6 h-6", iconColor)} />
      </motion.div>
      <h3 className="font-semibold text-base mb-1.5 text-foreground/90">{title}</h3>
      <p className="text-sm text-muted-foreground max-w-sm mx-auto mb-1 leading-relaxed">
        {description}
      </p>
      {hint && (
        <p className="text-xs text-muted-foreground/50 max-w-xs mx-auto mb-5 leading-relaxed">
          {hint}
        </p>
      )}
      {(action || secondaryAction) && (
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
          {action && <ActionButton action={action} />}
          {secondaryAction && <SecondaryButton action={secondaryAction} />}
        </div>
      )}
    </motion.div>
  );
}
