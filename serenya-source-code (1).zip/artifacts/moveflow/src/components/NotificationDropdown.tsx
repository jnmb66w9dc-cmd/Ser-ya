import { Bell, CheckCheck, CheckCircle2, AlertTriangle, Info, RefreshCw, ShieldAlert, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  useListNotifications,
  useMarkNotificationRead,
  useMarkAllNotificationsRead,
  getListNotificationsQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "@/lib/motion-compat";

// ── Priority config ─────────────────────────────────────────────────────────

type Priority = "action_required" | "completed" | "processing" | "verification" | "info";

interface PriorityConfig {
  label: string;
  icon: React.ElementType;
  dot: string;
  bg: string;
  iconColor: string;
  labelColor: string;
}

const PRIORITY: Record<Priority, PriorityConfig> = {
  action_required: {
    label: "Action requise",
    icon: AlertTriangle,
    dot: "bg-amber-400",
    bg: "bg-amber-400/8",
    iconColor: "text-amber-400",
    labelColor: "text-amber-400",
  },
  verification: {
    label: "Vérification en attente",
    icon: ShieldAlert,
    dot: "bg-violet-400",
    bg: "bg-violet-400/8",
    iconColor: "text-violet-400",
    labelColor: "text-violet-400",
  },
  processing: {
    label: "Traitement en cours",
    icon: RefreshCw,
    dot: "bg-blue-400",
    bg: "bg-transparent",
    iconColor: "text-blue-400",
    labelColor: "text-blue-400",
  },
  completed: {
    label: "Terminé",
    icon: CheckCircle2,
    dot: "bg-emerald-500",
    bg: "bg-transparent",
    iconColor: "text-emerald-500",
    labelColor: "text-emerald-500",
  },
  info: {
    label: "Information",
    icon: Info,
    dot: "bg-muted-foreground/40",
    bg: "bg-transparent",
    iconColor: "text-muted-foreground/60",
    labelColor: "text-muted-foreground/60",
  },
};

function dbTypeToPriority(type: string): Priority {
  if (type === "warning") return "action_required";
  if (type === "error") return "action_required";
  if (type === "success") return "completed";
  return "info";
}

// ── Time grouping ────────────────────────────────────────────────────────────

function groupLabel(dateStr: string): string {
  const d = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffDays = diffMs / (1000 * 60 * 60 * 24);
  if (diffDays < 1) return "Aujourd'hui";
  if (diffDays < 7) return "Cette semaine";
  return "Plus ancien";
}

function relativeTime(dateStr: string): string {
  const d = new Date(dateStr);
  const now = new Date();
  const diffMs = now.getTime() - d.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  if (diffMins < 2) return "À l'instant";
  if (diffMins < 60) return `Il y a ${diffMins} min`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `Il y a ${diffHours}h`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) return "Hier";
  return `Il y a ${diffDays} jours`;
}

// ── Component ────────────────────────────────────────────────────────────────

export default function NotificationDropdown() {
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const { data: notifications } = useListNotifications();
  const markRead = useMarkNotificationRead();
  const markAll = useMarkAllNotificationsRead();

  const unread = notifications?.filter((n) => !n.isRead) ?? [];
  const hasActionRequired = notifications?.some(
    (n) => dbTypeToPriority(n.type) === "action_required" && !n.isRead
  );

  const invalidate = () =>
    queryClient.invalidateQueries({ queryKey: getListNotificationsQueryKey() });

  // Group by time bucket
  type NotifItem = NonNullable<typeof notifications>[number];
  const grouped: { label: string; items: NotifItem[] }[] = [];
  if (notifications && notifications.length > 0) {
    const buckets = new Map<string, NotifItem[]>();
    const ORDER = ["Aujourd'hui", "Cette semaine", "Plus ancien"];
    for (const n of notifications) {
      const lbl = groupLabel(n.createdAt);
      if (!buckets.has(lbl)) buckets.set(lbl, []);
      buckets.get(lbl)!.push(n);
    }
    for (const lbl of ORDER) {
      if (buckets.has(lbl)) grouped.push({ label: lbl, items: buckets.get(lbl)! });
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          className="relative text-muted-foreground hover:text-foreground"
        >
          <Bell className="w-4 h-4" />
          <AnimatePresence>
            {unread.length > 0 && (
              <motion.span
                key="badge"
                initial={{ scale: 0, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0, opacity: 0 }}
                transition={{ type: "spring", stiffness: 500, damping: 28 }}
                className={cn(
                  "absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full text-xs font-bold text-white flex items-center justify-center",
                  hasActionRequired ? "bg-amber-500" : "bg-primary"
                )}
              >
                {unread.length > 9 ? "9+" : unread.length}
              </motion.span>
            )}
          </AnimatePresence>
        </Button>
      </DropdownMenuTrigger>

      <DropdownMenuContent align="end" className="w-[340px] p-0 shadow-xl" sideOffset={8}>
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <div className="flex items-center gap-2">
            <h3 className="font-semibold text-sm">Notifications</h3>
            {unread.length > 0 && (
              <span className="inline-flex items-center justify-center h-5 min-w-[20px] px-1.5 rounded-full bg-primary/10 text-primary text-xs font-bold">
                {unread.length}
              </span>
            )}
          </div>
          {unread.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 text-xs text-muted-foreground hover:text-foreground gap-1.5"
              onClick={() => markAll.mutate(undefined as never, { onSuccess: invalidate })}
            >
              <CheckCheck className="w-3 h-3" />
              Tout marquer lu
            </Button>
          )}
        </div>

        {/* Body */}
        <ScrollArea className="max-h-[380px]">
          {grouped.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className="px-4 py-12 text-center"
            >
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.1, type: "spring", stiffness: 300, damping: 20 }}
                className="w-11 h-11 rounded-xl bg-muted/30 border border-border/30 flex items-center justify-center mx-auto mb-3"
              >
                <Bell className="w-5 h-5 text-muted-foreground/40" />
              </motion.div>
              <p className="text-sm font-medium text-muted-foreground">Tout est calme pour le moment</p>
              <p className="text-xs text-muted-foreground/50 mt-1 max-w-[240px] mx-auto leading-relaxed">
                Vous recevrez ici les confirmations de vos organismes et les étapes importantes.
              </p>
            </motion.div>
          ) : (
            grouped.map((group) => (
              <div key={group.label}>
                <div className="px-4 py-1.5 sticky top-0 bg-popover z-10">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground/50">
                    {group.label}
                  </p>
                </div>
                {group.items.map((n) => {
                  const priority = dbTypeToPriority(n.type);
                  const cfg = PRIORITY[priority];
                  const Icon = cfg.icon;
                  const isUnread = !n.isRead;
                  return (
                    <motion.div
                      key={n.id}
                      layout
                      initial={{ opacity: 0, y: 4 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.2 }}
                      className={cn(
                        "flex items-start gap-3 px-4 py-3 border-b border-border/40 last:border-0 cursor-pointer transition-colors",
                        isUnread ? cn("hover:bg-muted/40", cfg.bg) : "hover:bg-muted/20 opacity-70"
                      )}
                      onClick={() => {
                        if (isUnread) {
                          markRead.mutate({ id: n.id }, { onSuccess: invalidate });
                        }
                        navigate("/automations");
                      }}
                    >
                      {/* Icon */}
                      <div
                        className={cn(
                          "w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5",
                          isUnread ? "bg-muted/60" : "bg-muted/30"
                        )}
                      >
                        <Icon className={cn("w-3.5 h-3.5", isUnread ? cfg.iconColor : "text-muted-foreground/40")} />
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className={cn("text-sm leading-snug", isUnread ? "font-medium" : "text-muted-foreground")}>
                            {n.title}
                          </p>
                          {isUnread && (
                            <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0 mt-1.5", cfg.dot)} />
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2 leading-relaxed">
                          {n.message}
                        </p>
                        <div className="flex items-center gap-2 mt-1.5">
                          <Clock className="w-3 h-3 text-muted-foreground/35 flex-shrink-0" />
                          <span className="text-xs text-muted-foreground/40">{relativeTime(n.createdAt)}</span>
                          {isUnread && priority !== "info" && priority !== "processing" && (
                            <>
                              <span className="text-muted-foreground/25">·</span>
                              <span className={cn("text-xs font-medium", cfg.labelColor)}>
                                {cfg.label}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            ))
          )}
        </ScrollArea>

        {/* Footer — reassurance message */}
        {notifications && notifications.length > 0 && (
          <div className="px-4 py-2.5 border-t border-border/50 bg-muted/20">
            {hasActionRequired ? (
              <p className="text-xs text-amber-400/80 flex items-center gap-1.5">
                <AlertTriangle className="w-3 h-3 flex-shrink-0" />
                Certaines démarches nécessitent votre attention.
              </p>
            ) : unread.length > 0 ? (
              <p className="text-xs text-muted-foreground/50 flex items-center gap-1.5">
                <RefreshCw className="w-3 h-3 flex-shrink-0" />
                Serenya suit vos démarches. Aucune action requise.
              </p>
            ) : (
              <p className="text-xs text-emerald-500/70 flex items-center gap-1.5">
                <CheckCircle2 className="w-3 h-3 flex-shrink-0" />
                Tout est à jour. Vos démarches avancent bien.
              </p>
            )}
          </div>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
