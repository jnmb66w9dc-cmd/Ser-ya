import { Link, useLocation } from "wouter";
import { useUser, useClerk } from "@clerk/react";
import {
  LayoutDashboard, Building2, MapPin, Zap, FileText, ListChecks, Settings, LogOut, ChevronRight, Shield,
  Sparkles, HelpCircle, Tag, ArrowUpRight, Crown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useListNotifications } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";

const navItems = [
  { href: "/dashboard",   label: "Tableau de bord",   icon: LayoutDashboard, shortcut: "G D" },
  { href: "/services",    label: "Services connectés", icon: Building2,       shortcut: "G S" },
  { href: "/addresses",   label: "Mes adresses",       icon: MapPin,          shortcut: "G A" },
  { href: "/automations", label: "Préparations",    icon: Zap,             shortcut: "G Z" },
  { href: "/documents",   label: "Documents",          icon: FileText,        shortcut: "G F" },
  { href: "/tasks",       label: "Tâches",             icon: ListChecks,      shortcut: "G T" },
  { href: "/settings",    label: "Paramètres",         icon: Settings,        shortcut: "G P" },
];

function UpgradeCard({ plan }: { plan: string | null }) {
  if (plan === null) return null; // still loading
  if (plan === "pro" || plan === "business") {
    return (
      <div className="px-3 mb-2">
        <div className="flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-sidebar-accent/30 border border-sidebar-border/40">
          <Crown className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-white/70 leading-none">
              Plan {plan.charAt(0).toUpperCase() + plan.slice(1)}
            </p>
            <p className="text-xs text-sidebar-foreground/40 mt-0.5">Accès complet activé</p>
          </div>
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 flex-shrink-0" />
        </div>
      </div>
    );
  }
  // free plan — show upgrade CTA
  return (
    <div className="px-3 mb-2">
      <Link href="/pricing">
        <div className="group flex items-center gap-2.5 px-3 py-2.5 rounded-xl bg-primary/10 border border-primary/20 hover:bg-primary/15 hover:border-primary/35 transition-all cursor-pointer">
          <Sparkles className="w-3.5 h-3.5 text-primary flex-shrink-0" />
          <div className="flex-1 min-w-0">
            <p className="text-xs font-semibold text-primary/90 leading-none">Passer à Pro</p>
            <p className="text-xs text-sidebar-foreground/40 mt-0.5">Préparations illimitées</p>
          </div>
          <ArrowUpRight className="w-3 h-3 text-primary/60 group-hover:text-primary transition-colors flex-shrink-0" />
        </div>
      </Link>
    </div>
  );
}

export default function AppSidebar({ onClose, onHelpOpen }: { onClose?: () => void; onHelpOpen?: () => void }) {
  const [location] = useLocation();
  const { user } = useUser();
  const { signOut } = useClerk();
  const { data: notifications } = useListNotifications();
  const unreadCount = notifications?.filter((n) => !n.isRead).length ?? 0;
  const [plan, setPlan] = useState<string | null>("free");

  useEffect(() => {
    fetch("/api/stripe/subscription", { credentials: "include" })
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data?.plan) setPlan(data.plan); })
      .catch(() => setPlan("free"));
  }, []);

  return (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-sidebar-border">
        <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center flex-shrink-0 shadow-lg shadow-primary/30">
          <Sparkles className="w-4 h-4 text-white" />
        </div>
        <div>
          <span className="font-bold text-base text-white tracking-tight">Serenya</span>
          <p className="text-xs text-sidebar-foreground/40 leading-none mt-0.5">Assistant administratif</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location === item.href || location.startsWith(item.href + "/");
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onClose}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group",
                isActive
                  ? "bg-sidebar-accent text-white"
                  : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-white"
              )}
            >
              <item.icon className={cn("w-4 h-4 flex-shrink-0 transition-colors duration-200",
                isActive ? "text-primary" : "text-sidebar-foreground/60 group-hover:text-primary/80")} />
              <span className="flex-1">{item.label}</span>
              {item.href === "/automations" && unreadCount > 0 ? (
                <Badge className="bg-primary/90 text-white text-xs px-1.5 py-0 min-w-[1.25rem] text-center h-4">
                  {unreadCount}
                </Badge>
              ) : isActive ? (
                <ChevronRight className="w-3 h-3 text-primary/50" />
              ) : (
                <span className="text-xs font-mono px-1.5 py-0.5 rounded border opacity-0 group-hover:opacity-100 transition-all duration-150 border-sidebar-border/50 text-sidebar-foreground/35">
                  {item.shortcut}
                </span>
              )}
            </Link>
          );
        })}

        {/* Pricing link */}
        <Link
          href="/pricing"
          onClick={onClose}
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 group",
            location === "/pricing"
              ? "bg-sidebar-accent text-white"
              : "text-sidebar-foreground hover:bg-sidebar-accent/60 hover:text-white"
          )}
        >
          <Tag className={cn("w-4 h-4 flex-shrink-0 transition-colors",
            location === "/pricing" ? "text-primary" : "text-sidebar-foreground/60 group-hover:text-primary/80")} />
          <span className="flex-1">Tarifs</span>
          {location === "/pricing" && <ChevronRight className="w-3 h-3 text-primary/50" />}
        </Link>
      </nav>

      {/* Help button */}
      <div className="px-3 mb-2">
        <button
          type="button"
          onClick={onHelpOpen}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all text-sidebar-foreground/70 hover:bg-sidebar-accent/60 hover:text-white group"
        >
          <HelpCircle className="w-4 h-4 flex-shrink-0 text-sidebar-foreground/50 group-hover:text-primary/80 transition-colors" />
          <span className="flex-1">Aide & Support</span>
        </button>
      </div>

      {/* Upgrade CTA */}
      <UpgradeCard plan={plan} />

      {/* Security badge */}
      <div className="px-4 py-3 mx-3 mb-2 rounded-xl bg-sidebar-accent/40 border border-sidebar-border/60">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse flex-shrink-0" />
          <Shield className="w-3 h-3 text-emerald-500/70 flex-shrink-0" />
          <span className="text-xs text-sidebar-foreground/50">Chiffrement AES-256 actif</span>
        </div>
      </div>

      {/* Legal links */}
      <div className="px-4 py-2 mx-3 mb-3">
        <div className="flex items-center gap-2 text-[10px] text-sidebar-foreground/30">
          <Link href="/mentions-legales" className="hover:text-sidebar-foreground/60 transition-colors">Légal</Link>
          <span>·</span>
          <Link href="/confidentialite" className="hover:text-sidebar-foreground/60 transition-colors">Confidentialité</Link>
          <span>·</span>
          <Link href="/cgu" className="hover:text-sidebar-foreground/60 transition-colors">CGU</Link>
          <span>·</span>
          <Link href="/contact" className="hover:text-sidebar-foreground/60 transition-colors">Contact</Link>
        </div>
      </div>

      {/* User */}
      <div className="border-t border-sidebar-border px-3 py-3">
        <div className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-sidebar-accent/50 transition-colors">
          <Avatar className="w-8 h-8 flex-shrink-0">
            <AvatarImage src={user?.imageUrl} />
            <AvatarFallback className="bg-primary/20 text-primary text-xs font-semibold">
              {user?.firstName?.[0]}{user?.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-white truncate">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-xs text-sidebar-foreground/50 truncate">
              {user?.emailAddresses[0]?.emailAddress}
            </p>
          </div>
          <Button
            variant="ghost" size="icon"
            className="w-8 h-8 text-sidebar-foreground/40 hover:text-destructive hover:bg-destructive/10 flex-shrink-0 transition-colors duration-200"
            onClick={() => signOut()}
          >
            <LogOut className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
