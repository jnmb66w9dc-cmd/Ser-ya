import { useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { X, Keyboard } from "lucide-react";

interface Props {
  open: boolean;
  onClose: () => void;
}

const SECTIONS = [
  {
    title: "Navigation",
    shortcuts: [
      { keys: ["G", "D"], label: "Tableau de bord" },
      { keys: ["G", "S"], label: "Services connectés" },
      { keys: ["G", "A"], label: "Mes adresses" },
      { keys: ["G", "Z"], label: "Préparations" },
      { keys: ["G", "P"], label: "Paramètres" },
    ],
  },
  {
    title: "Commandes",
    shortcuts: [
      { keys: ["⌘", "K"], label: "Palette de commandes" },
      { keys: ["⌘", "J"], label: "Ouvrir l'assistant Sofia" },
      { keys: ["⌘", "T"], label: "Basculer thème clair/sombre" },
      { keys: ["?"], label: "Afficher les raccourcis" },
      { keys: ["Esc"], label: "Fermer la fenêtre" },
    ],
  },
  {
    title: "Dans la palette ⌘K",
    shortcuts: [
      { keys: ["↑", "↓"], label: "Naviguer entre les résultats" },
      { keys: ["↵"], label: "Sélectionner" },
      { keys: ["Esc"], label: "Fermer" },
    ],
  },
];

function Key({ children }: { children: string }) {
  return (
    <kbd className="inline-flex items-center justify-center min-w-[1.5rem] h-6 px-1.5 rounded-md border border-border/60 bg-muted/50 text-xs font-mono font-medium text-muted-foreground leading-none shadow-sm">
      {children}
    </kbd>
  );
}

export default function KeyboardShortcutsModal({ open, onClose }: Props) {
  useEffect(() => {
    function handler(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    if (open) document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: 8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 8 }}
            transition={{ type: "spring", stiffness: 350, damping: 30 }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md"
          >
            <div className="bg-card border border-border/60 rounded-2xl shadow-2xl overflow-hidden">
              {/* Header */}
              <div className="flex items-center gap-3 px-5 py-4 border-b border-border/40">
                <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Keyboard className="w-3.5 h-3.5 text-primary" />
                </div>
                <h2 className="font-semibold text-sm flex-1">Raccourcis clavier</h2>
                <button
                  onClick={onClose}
                  className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Shortcuts */}
              <div className="p-5 space-y-5 max-h-[60vh] overflow-y-auto">
                {SECTIONS.map((section) => (
                  <div key={section.title}>
                    <p className="text-xs uppercase tracking-wider font-semibold text-muted-foreground/50 mb-2.5">
                      {section.title}
                    </p>
                    <div className="space-y-1.5">
                      {section.shortcuts.map((s) => (
                        <div key={s.label} className="flex items-center justify-between gap-4 py-1">
                          <span className="text-sm text-muted-foreground">{s.label}</span>
                          <div className="flex items-center gap-1 flex-shrink-0">
                            {s.keys.map((k, i) => (
                              <span key={i} className="flex items-center gap-1">
                                <Key>{k}</Key>
                                {i < s.keys.length - 1 && (
                                  <span className="text-xs text-muted-foreground/40 font-mono">then</span>
                                )}
                              </span>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              {/* Footer */}
              <div className="px-5 py-3 border-t border-border/30 bg-muted/10">
                <p className="text-xs text-muted-foreground/50 text-center">
                  Appuyez sur <Key>?</Key> à tout moment pour afficher cette fenêtre
                </p>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
