import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { Cookie, X } from "lucide-react";

const CONSENT_KEY = "serenya_cookie_consent";

export default function CookieBanner() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const consent = localStorage.getItem(CONSENT_KEY);
    if (!consent) setVisible(true);
  }, []);

  function accept() {
    localStorage.setItem(CONSENT_KEY, JSON.stringify({ essential: true, analytics: true, date: new Date().toISOString() }));
    setVisible(false);
  }

  function reject() {
    localStorage.setItem(CONSENT_KEY, JSON.stringify({ essential: true, analytics: false, date: new Date().toISOString() }));
    setVisible(false);
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 100, opacity: 0 }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="fixed bottom-4 left-4 right-4 z-[60] max-w-lg mx-auto"
        >
          <div className="bg-card border border-border/60 rounded-2xl shadow-2xl p-4 flex flex-col gap-3">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-400/10 flex items-center justify-center flex-shrink-0">
                <Cookie className="w-4 h-4 text-amber-400" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium">Votre vie privée est importante</p>
                <p className="text-xs text-muted-foreground mt-1 leading-relaxed">
                  Serenya utilise uniquement des cookies nécessaires au fonctionnement (authentification, sécurité). Aucun tracker publicitaire. Vous pouvez modifier vos préférences à tout moment dans les Paramètres.
                </p>
              </div>
              <button onClick={reject} className="w-6 h-6 rounded-full hover:bg-muted flex items-center justify-center text-muted-foreground flex-shrink-0">
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="flex items-center gap-2 justify-end">
              <button
                onClick={reject}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-muted-foreground hover:bg-muted transition-colors"
              >
                Refuser les mesures
              </button>
              <button
                onClick={accept}
                className="px-3 py-1.5 rounded-lg text-xs font-medium bg-primary text-white hover:bg-primary/90 transition-colors"
              >
                Accepter tout
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
