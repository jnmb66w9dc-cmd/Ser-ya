import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { Shield, X, RotateCcw } from "lucide-react";
import { clearAutoSave, hasAutoSave } from "@/hooks/useAutoSave";

export default function DraftRecoveryBanner({
  storageKey,
  onRestore,
  onClear,
  label = "vos modifications",
}: {
  storageKey: string;
  onRestore: () => void;
  onClear?: () => void;
  label?: string;
}) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (hasAutoSave(storageKey)) {
      setVisible(true);
    }
  }, [storageKey]);

  function handleRestore() {
    onRestore();
    setVisible(false);
  }

  function handleClear() {
    clearAutoSave(storageKey);
    if (onClear) onClear();
    setVisible(false);
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: -10, height: 0 }}
          animate={{ opacity: 1, y: 0, height: "auto" }}
          exit={{ opacity: 0, y: -10, height: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-4 overflow-hidden"
        >
          <div className="flex items-center gap-3 p-3.5 rounded-xl bg-primary/8 border border-primary/15">
            <Shield className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
            <div className="flex-1 min-w-0">
              <p className="text-sm text-foreground/80 leading-snug">
                <span className="font-medium">Progrès sauvegardé.</span>{" "}
                Serenya a automatiquement sauvegardé {label}.
                Vous pouvez continuer où vous vous étiez arrêté.
              </p>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <button
                onClick={handleRestore}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-xs font-medium hover:bg-primary/20 transition-colors"
              >
                <RotateCcw className="w-3 h-3" /> Restaurer
              </button>
              <button
                onClick={handleClear}
                className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                title="Effacer la sauvegarde"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
