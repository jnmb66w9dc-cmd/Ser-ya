import { useState } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import {
  X, HelpCircle, Shield, Clock, CheckCircle2, AlertTriangle,
  ChevronDown, Mail, Zap, Lock, Bot, MessageSquare, HeartHandshake,
} from "lucide-react";
import { cn } from "@/lib/utils";

/* ══════════════════════════════════════════════
   FAQ CONTENT — human-written, calm, reassuring
══════════════════════════════════════════════ */

const FAQ_ITEMS = [
  {
    q: "Combien de temps prend une mise à jour d'adresse ?",
    a: "Ça dépend de l'organisation. Amazon ou Netflix mettent l'adresse à jour en quelques minutes. Les opérateurs (Orange, Free, SFR) prennent généralement 3 à 7 jours. Les banques et les administrations (CPAM, CAF) peuvent prendre jusqu'à 15 à 30 jours. C'est tout à fait normal — et Serenya vous notifie dès qu'une confirmation arrive.",
    icon: Clock,
  },
  {
    q: "Pourquoi ma banque demande une confirmation supplémentaire ?",
    a: "Les banques sont soumises à des obligations légales strictes (KYC, LCB-FT) pour protéger vos données. Votre présence directe est légalement requise pour toute modification de compte. Ce n'est pas un problème — c'est une protection pour vous. Serenya vous guide pas à pas pour que ce soit aussi simple que possible.",
    icon: Shield,
  },
  {
    q: "Mes données personnelles sont-elles en sécurité ?",
    a: "Oui, totalement. Serenya ne conserve jamais vos mots de passe ni vos coordonnées bancaires. Toutes vos données sont chiffrées avec AES-256 et nous sommes conformes au RGPD. Vous pouvez demander la suppression de vos données à tout moment.",
    icon: Lock,
  },
  {
    q: "Que se passe-t-il si une démarche ne fonctionne pas ?",
    a: "Ça peut arriver — certaines organisations changent leurs systèmes ou demandent une vérification supplémentaire. Serenya vous l'indique clairement avec des instructions pour finaliser en quelques minutes. Vous n'êtes jamais seul face à une difficulté.",
    icon: AlertTriangle,
  },
  {
    q: "Puis-je annuler ou modifier une préparation en cours ?",
    a: "Oui. Vous pouvez annuler une préparation à tout moment depuis la page Préparations. Les démarches déjà transmises aux organismes ne peuvent plus être rappelées, mais vous pouvez toujours contacter l'organisme directement — Serenya vous donne les coordonnées utiles.",
    icon: Zap,
  },
  {
    q: "Ma Carte Vitale va-t-elle changer après la mise à jour CPAM ?",
    a: "Non, pas du tout. Votre Carte Vitale reste valide indéfiniment — elle n'est liée à aucune adresse. La mise à jour CPAM ne modifie que votre adresse de correspondance dans leurs fichiers. Vos remboursements continuent normalement sans aucune interruption.",
    icon: CheckCircle2,
  },
  {
    q: "Est-ce que Serenya agit sans mon accord ?",
    a: "Jamais. Serenya prépare, guide et suggère — mais ne soumet rien sans votre validation explicite. Pour les démarches en ligne, vous confirmez vous-même. Pour les organisations sensibles (banques, assurances), votre présence directe est requise par la loi. Vous gardez le contrôle à chaque instant.",
    icon: Bot,
  },
  {
    q: "Les délais indiqués sont-ils fiables ?",
    a: "Les délais affichés sont ceux communiqués par les organisations elles-mêmes. Serenya les indique honnêtement. Certaines périodes chargées peuvent allonger légèrement ces délais. Serenya vous notifie dès qu'une confirmation est reçue — vous n'avez pas à vérifier vous-même.",
    icon: MessageSquare,
  },
];

const SELF_HELP = [
  {
    label: "Vérifier l'état de mes démarches",
    desc: "Rendez-vous sur la page Préparations pour consulter le statut détaillé de chaque service.",
  },
  {
    label: "Une organisation ne répond pas",
    desc: "Les délais peuvent varier. Attendez 48h supplémentaires avant de relancer — certaines organisations ont des délais naturellement plus longs.",
  },
  {
    label: "Je n'ai pas reçu d'email de confirmation",
    desc: "Vérifiez votre dossier spams ou courriers indésirables. Les confirmations automatiques y arrivent parfois.",
  },
  {
    label: "Une démarche est bloquée",
    desc: "Cliquez sur la démarche en question depuis la page Préparations — Serenya vous explique exactement quoi faire.",
  },
];

/* ══════════════════════════════════════════════
   COMPONENT
══════════════════════════════════════════════ */

interface HelpCenterProps {
  open: boolean;
  onClose: () => void;
}

export default function HelpCenter({ open, onClose }: HelpCenterProps) {
  const [tab, setTab]         = useState<"faq" | "contact">("faq");
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-[2px]"
            onClick={onClose}
          />

          {/* Panel */}
          <motion.div
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 260 }}
            className="fixed right-0 top-0 bottom-0 z-50 w-full sm:w-[460px] bg-background border-l border-border/50 shadow-2xl flex flex-col"
          >
            {/* Header */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-border/40 flex-shrink-0">
              <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                <HeartHandshake className="w-5 h-5 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <h2 className="font-bold text-base">Centre d'aide</h2>
                <p className="text-xs text-muted-foreground mt-0.5">
                  Serenya vous accompagne à chaque étape.
                </p>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Tab switcher */}
            <div className="flex gap-1 px-4 py-3 border-b border-border/30 bg-muted/10 flex-shrink-0">
              {([
                { id: "faq",     label: "Questions fréquentes" },
                { id: "contact", label: "Besoin d'aide ?" },
              ] as const).map(t => (
                <button
                  key={t.id}
                  onClick={() => setTab(t.id)}
                  className={cn(
                    "flex-1 py-2 px-3 rounded-lg text-xs font-medium transition-all",
                    tab === t.id
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                  )}
                >
                  {t.label}
                </button>
              ))}
            </div>

            {/* Content */}
            <div className="flex-1 overflow-y-auto">
              {tab === "faq" ? (
                <div className="p-5 space-y-2.5">

                  {/* Contextual reassurance */}
                  <div className="rounded-xl bg-primary/5 border border-primary/15 p-4 flex items-start gap-3 mb-1">
                    <Bot className="w-4 h-4 text-primary/60 flex-shrink-0 mt-0.5" />
                    <div className="space-y-1.5">
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        <span className="font-medium text-foreground/70">Votre demande est bien enregistrée.</span>{" "}
                        Certaines organisations prennent un peu plus de temps que d'autres — c'est tout à fait normal.
                      </p>
                      <p className="text-xs text-muted-foreground/70 leading-relaxed">
                        Serenya vous notifie à chaque étape importante. Aucune action supplémentaire n'est nécessaire pour le moment.
                      </p>
                    </div>
                  </div>

                  {/* FAQ accordion */}
                  {FAQ_ITEMS.map((item, i) => (
                    <div key={i} className="rounded-xl border border-border/50 overflow-hidden bg-card">
                      <button
                        onClick={() => setOpenFaq(openFaq === i ? null : i)}
                        className="w-full flex items-center gap-3 px-4 py-3.5 text-left hover:bg-muted/20 transition-colors group"
                      >
                        <div className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/10 transition-colors">
                          <item.icon className="w-3.5 h-3.5 text-muted-foreground group-hover:text-primary transition-colors" />
                        </div>
                        <span className="flex-1 text-sm font-medium leading-snug">{item.q}</span>
                        <ChevronDown className={cn(
                          "w-4 h-4 text-muted-foreground/40 flex-shrink-0 transition-transform duration-200",
                          openFaq === i && "rotate-180"
                        )} />
                      </button>
                      <AnimatePresence>
                        {openFaq === i && (
                          <motion.div
                            initial={{ height: 0 }} animate={{ height: "auto" }}
                            exit={{ height: 0 }} transition={{ duration: 0.2, ease: "easeOut" }}
                            className="overflow-hidden"
                          >
                            <div className="px-4 pb-4 pt-3 border-t border-border/30 bg-muted/15">
                              <p className="text-sm text-muted-foreground leading-relaxed">{item.a}</p>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  ))}

                  <p className="text-xs text-muted-foreground/35 text-center pt-2 pb-1">
                    Une question non listée ? Consultez l'onglet "Besoin d'aide ?".
                  </p>
                </div>
              ) : (
                <div className="p-5 space-y-4">

                  {/* Self-help */}
                  <div>
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                      Résoudre par vous-même
                    </p>
                    <div className="space-y-2">
                      {SELF_HELP.map((item, i) => (
                        <div
                          key={i}
                          className="rounded-xl border border-border/50 bg-card p-4 hover:bg-muted/20 transition-colors"
                        >
                          <p className="text-sm font-medium mb-1">{item.label}</p>
                          <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Divider */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 h-px bg-border/40" />
                    <span className="text-xs text-muted-foreground/40 px-1">ou</span>
                    <div className="flex-1 h-px bg-border/40" />
                  </div>

                  {/* Contact section */}
                  <div className="rounded-2xl border border-border/60 overflow-hidden bg-card">
                    <div className="px-5 py-4 border-b border-border/40 bg-muted/10">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                          <Mail className="w-4 h-4 text-primary" />
                        </div>
                        <div>
                          <p className="font-semibold text-sm">Contacter l'équipe Serenya</p>
                          <p className="text-xs text-muted-foreground">Réponse sous 24h ouvrées</p>
                        </div>
                      </div>
                      <p className="text-xs text-muted-foreground leading-relaxed">
                        L'équipe Serenya est formée pour les situations de déménagement. Nous comprenons ce que représente cette période — et nous sommes là pour vous.
                      </p>
                    </div>
                    <div className="px-5 py-4 space-y-3">
                      <a
                        href="mailto:aide@serenya.fr"
                        className="flex items-center justify-center gap-2 w-full py-3 rounded-xl border border-border/60 text-sm font-medium hover:bg-muted/40 transition-colors"
                      >
                        <Mail className="w-4 h-4 text-muted-foreground" />
                        aide@serenya.fr
                      </a>
                      <div className="flex items-start gap-2.5 p-3 rounded-lg bg-emerald-500/5 border border-emerald-500/15">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          Nos conseillers ne partagent jamais vos données avec des tiers et ne vous demanderont jamais votre mot de passe.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Emotional reassurance */}
                  <div className="rounded-xl bg-muted/20 border border-border/40 p-5 text-center">
                    <HeartHandshake className="w-7 h-7 text-primary/30 mx-auto mb-3" />
                    <p className="text-sm font-semibold mb-2">Vous n'êtes pas seul.</p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      Un déménagement est une période chargée et parfois stressante. Serenya est conçu pour alléger cette charge — pas pour l'augmenter. Prenez le temps qu'il vous faut.
                    </p>
                  </div>

                  {/* Security reminder */}
                  <div className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-muted/15 border border-border/30">
                    <Lock className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />
                    <p className="text-xs text-muted-foreground/50 leading-relaxed">
                      Toutes vos données sont chiffrées et protégées · RGPD · AES-256
                    </p>
                  </div>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-5 py-3 border-t border-border/30 flex-shrink-0 bg-muted/10 text-center">
              <p className="text-xs text-muted-foreground/40">
                Serenya vous accompagne à chaque étape · Vous gardez toujours le contrôle
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
