import { useState } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { MessageSquare, X, Send, Star, Bug, Lightbulb, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { trackFeedbackSent } from "@/hooks/useAnalytics";

const FEEDBACK_TYPES = [
  { id: "praise", label: "J'adore", icon: Star, color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20" },
  { id: "suggestion", label: "Suggestion", icon: Lightbulb, color: "text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20" },
  { id: "bug", label: "Bug", icon: Bug, color: "text-red-400", bg: "bg-red-500/10", border: "border-red-500/20" },
];

export default function FeedbackWidget() {
  const [open, setOpen] = useState(false);
  const [type, setType] = useState<string | null>(null);
  const [rating, setRating] = useState(0);
  const [text, setText] = useState("");
  const [state, setState] = useState<"idle" | "submitting" | "success">("idle");

  async function submit() {
    if (!type || rating === 0) return;
    setState("submitting");
    try {
      const res = await fetch("/api/feedback", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type, rating, text: text.trim() }),
      });
      if (res.ok) {
        setState("success");
        trackFeedbackSent(type);
        setTimeout(() => {
          setOpen(false);
          setTimeout(() => {
            setState("idle");
            setType(null);
            setRating(0);
            setText("");
          }, 300);
        }, 2000);
      } else {
        setState("idle");
      }
    } catch {
      setState("idle");
    }
  }

  return (
    <>
      {/* Floating trigger */}
      <motion.button
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1, type: "spring", stiffness: 300, damping: 20 }}
        onClick={() => setOpen(!open)}
        className={cn(
          "fixed bottom-5 right-5 z-50 w-12 h-12 rounded-full shadow-lg shadow-primary/20",
          "flex items-center justify-center transition-colors",
          open
            ? "bg-muted text-foreground hover:bg-muted/80"
            : "bg-primary text-white hover:bg-primary/90"
        )}
        aria-label="Feedback"
      >
        {open ? <X className="w-5 h-5" /> : <MessageSquare className="w-5 h-5" />}
      </motion.button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            transition={{ type: "spring", stiffness: 400, damping: 30 }}
            className="fixed bottom-20 right-5 z-50 w-80 bg-card border border-border rounded-2xl shadow-xl p-5"
          >
            {state === "success" ? (
              <div className="text-center py-6">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 300, damping: 20 }}
                  className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center mx-auto mb-3"
                >
                  <CheckCircle2 className="w-6 h-6 text-emerald-400" />
                </motion.div>
                <p className="text-sm font-medium">Merci pour votre retour !</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Votre avis aide à améliorer Serenya.
                </p>
              </div>
            ) : (
              <>
                <h3 className="text-sm font-semibold mb-3">Votre avis compte</h3>

                {/* Type selector */}
                <div className="flex gap-2 mb-3">
                  {FEEDBACK_TYPES.map((t) => {
                    const Icon = t.icon;
                    const selected = type === t.id;
                    return (
                      <button
                        key={t.id}
                        onClick={() => setType(t.id)}
                        className={cn(
                          "flex-1 flex flex-col items-center gap-1 py-2 rounded-lg border transition-all text-[10px] font-medium",
                          selected
                            ? cn(t.bg, t.border, t.color, "border-solid")
                            : "border-border/40 text-muted-foreground hover:border-border/80"
                        )}
                      >
                        <Icon className="w-4 h-4" />
                        {t.label}
                      </button>
                    );
                  })}
                </div>

                {/* Rating */}
                <div className="flex items-center gap-1 mb-3">
                  {[1, 2, 3, 4, 5].map((n) => (
                    <button
                      key={n}
                      onClick={() => setRating(n)}
                      className={cn(
                        "w-7 h-7 rounded flex items-center justify-center transition-colors",
                        n <= rating
                          ? "bg-amber-500/10 text-amber-400"
                          : "bg-muted/50 text-muted-foreground/40 hover:text-amber-400/60"
                      )}
                    >
                      <Star className="w-3.5 h-3.5" fill={n <= rating ? "currentColor" : "none"} />
                    </button>
                  ))}
                </div>

                {/* Text input */}
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Dites-nous ce que vous pensez..."
                  className="w-full min-h-[80px] rounded-lg border border-border/40 bg-muted/30 px-3 py-2 text-xs resize-none focus:outline-none focus:ring-1 focus:ring-primary/30 mb-3"
                />

                {/* Submit */}
                <Button
                  size="sm"
                  className="w-full gap-1.5 text-xs"
                  disabled={!type || rating === 0 || state === "submitting"}
                  onClick={submit}
                >
                  {state === "submitting" ? (
                    <>
                      <span className="w-3.5 h-3.5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      Envoi...
                    </>
                  ) : (
                    <>
                      <Send className="w-3.5 h-3.5" />
                      Envoyer
                    </>
                  )}
                </Button>

                <p className="text-[10px] text-muted-foreground/50 text-center mt-2">
                  Version bêta — votre retour nous aide à progresser
                </p>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
