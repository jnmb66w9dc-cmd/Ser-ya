import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { MessageCircle, X, Send, Plus, Trash2, ChevronLeft, Sparkles, Loader2, ArrowRight } from "lucide-react";
import { cn } from "@/lib/utils";
import { useUser } from "@clerk/react";
import { useLocation } from "wouter";
import { Link } from "wouter";
import { useAgentName } from "@/hooks/useAgentName";

/* ── Types ────────────────────────────────────────────────────────────────── */
interface Msg { id: number; role: "user" | "assistant"; content: string; createdAt: string; }
interface Conv { id: number; title: string; createdAt: string; }

/* ── Quick suggestions per page ──────────────────────────────────────────── */
const PAGE_SUGGESTIONS: Record<string, string[]> = {
  "/dashboard":    ["Comment lancer une préparation ?", "Combien de temps ça prend ?", "Mes données sont-elles sécurisées ?"],
  "/addresses":    ["Comment ajouter une adresse ?", "Quelle adresse choisir comme principale ?", "Puis-je avoir plusieurs adresses ?"],
  "/services":     ["Quels services peuvent être mis à jour ?", "Pourquoi mon service n'est pas dans la liste ?", "Comment connecter une banque ?"],
  "/automations":  ["Une tâche a échoué, que faire ?", "Combien de temps pour la CAF ?", "Comment fonctionne la Sécu ?"],
  "/settings":     ["Comment exporter mes données ?", "Comment supprimer mon compte ?", "Où va mon argent si je prends un abonnement ?"],
  "/":             ["Comment fonctionne Serenya ?", "Est-ce vraiment gratuit au début ?", "Quels organismes sont couverts ?"],
};

const DEFAULT_SUGGESTIONS = ["Comment ça marche ?", "Est-ce sécurisé ?", "Quels organismes sont couverts ?"];

/* ── Chip parser ─────────────────────────────────────────────────────────── */
const CHIP_MARKER = "___CHIPS___";

interface Chip { label: string; href: string; }

function parseChips(content: string): { text: string; chips: Chip[] } {
  const idx = content.lastIndexOf(CHIP_MARKER);
  if (idx === -1) return { text: content, chips: [] };
  const rawText = content.slice(0, idx).trimEnd();
  try {
    const chips: Chip[] = JSON.parse(content.slice(idx + CHIP_MARKER.length).trim());
    return { text: rawText, chips: Array.isArray(chips) ? chips.slice(0, 3) : [] };
  } catch {
    return { text: content, chips: [] };
  }
}

/* ── Markdown-lite renderer ──────────────────────────────────────────────── */
function renderContent(text: string) {
  const lines = text.split("\n");
  const elements: React.ReactNode[] = [];
  let listItems: string[] = [];

  const flushList = (key: string) => {
    if (listItems.length) {
      elements.push(
        <ul key={key} className="my-1.5 space-y-1 pl-1">
          {listItems.map((item, i) => (
            <li key={i} className="flex gap-2 text-[13px]">
              <span className="text-primary/60 flex-shrink-0 mt-0.5">•</span>
              <span dangerouslySetInnerHTML={{ __html: formatInline(item) }} />
            </li>
          ))}
        </ul>
      );
      listItems = [];
    }
  };

  lines.forEach((line, i) => {
    if (line.startsWith("- ") || line.startsWith("* ")) {
      listItems.push(line.slice(2));
    } else {
      flushList(`list-${i}`);
      if (line.startsWith("**") && line.endsWith("**") && line.length > 4) {
        elements.push(<p key={i} className="font-semibold text-[13px] mt-2 mb-0.5" dangerouslySetInnerHTML={{ __html: formatInline(line) }} />);
      } else if (line.trim()) {
        elements.push(<p key={i} className="text-[13px] leading-relaxed" dangerouslySetInnerHTML={{ __html: formatInline(line) }} />);
      } else if (elements.length) {
        elements.push(<div key={i} className="h-1.5" />);
      }
    }
  });
  flushList("final");
  return elements;
}

function formatInline(text: string): string {
  return text
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.*?)\*/g, "<em>$1</em>")
    .replace(/`(.*?)`/g, '<code class="bg-muted/60 px-1 py-0.5 rounded text-xs font-mono">$1</code>');
}

/* ── API helpers ─────────────────────────────────────────────────────────── */
async function apiFetch(url: string, opts?: RequestInit) {
  const r = await fetch(url, { credentials: "include", ...opts });
  if (!r.ok) throw new Error(`${r.status}`);
  return r;
}

/* ── Component ───────────────────────────────────────────────────────────── */
export default function ChatWidget() {
  const { isSignedIn, user } = useUser();
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  const [view, setView] = useState<"list" | "chat">("list");
  const [convs, setConvs] = useState<Conv[]>([]);
  const [activeConv, setActiveConv] = useState<Conv | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [streamingContent, setStreamingContent] = useState("");
  const [loading, setLoading] = useState(false);
  const [unread, setUnread] = useState(false);
  const [greeting, setGreeting] = useState<string | null>(null);
  const [greetingLoading, setGreetingLoading] = useState(false);
  const agentName = useAgentName();
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const abortRef = useRef<AbortController | null>(null);
  const greetingFetched = useRef(false);

  // Listen for global open-chat event (from command palette)
  useEffect(() => {
    const handler = () => { setOpen(true); setUnread(false); };
    window.addEventListener("serenya:open-chat", handler);
    return () => window.removeEventListener("serenya:open-chat", handler);
  }, []);

  const suggestions = PAGE_SUGGESTIONS[location] ?? DEFAULT_SUGGESTIONS;

  // Load conversations when opened
  useEffect(() => {
    if (open && isSignedIn) loadConvs();
  }, [open, isSignedIn]);

  // Proactive greeting: pre-fetch at dashboard mount (before widget opens)
  useEffect(() => {
    if (!isSignedIn || location !== "/dashboard" || greetingFetched.current) return;
    greetingFetched.current = true;
    setGreetingLoading(true);
    (async () => {
      try {
        const ctxR = await apiFetch("/api/ai/user-context");
        const ctx = await ctxR.json();
        const grR = await apiFetch("/api/ai/greeting", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ firstName: user?.firstName ?? undefined, context: ctx }),
        });
        const gr = await grR.json();
        setGreeting(gr.greeting ?? null);
      } catch { /* silent */ }
      setGreetingLoading(false);
    })();
  }, [isSignedIn, location]);

  // Auto-scroll
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, streamingContent]);

  // Focus input when chat opens
  useEffect(() => {
    if (view === "chat" && open) setTimeout(() => inputRef.current?.focus(), 150);
  }, [view, open]);

  async function loadConvs() {
    try {
      const r = await apiFetch("/api/anthropic/conversations");
      setConvs(await r.json());
    } catch { /* silent */ }
  }

  async function openConv(conv: Conv) {
    setActiveConv(conv);
    setView("chat");
    setLoading(true);
    try {
      const r = await apiFetch(`/api/anthropic/conversations/${conv.id}/messages`);
      setMsgs(await r.json());
    } catch { setMsgs([]); }
    setLoading(false);
  }

  async function newConv(firstMessage?: string) {
    const title = firstMessage
      ? firstMessage.slice(0, 60)
      : `Conversation du ${new Date().toLocaleDateString("fr-FR", { day: "numeric", month: "long" })}`;
    try {
      const r = await apiFetch("/api/anthropic/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title }),
      });
      const conv: Conv = await r.json();
      setConvs(prev => [conv, ...prev]);
      setActiveConv(conv);
      setMsgs([]);
      setView("chat");
      return conv;
    } catch { return null; }
  }

  async function deleteConv(e: React.MouseEvent, convId: number) {
    e.stopPropagation();
    try {
      await apiFetch(`/api/anthropic/conversations/${convId}`, { method: "DELETE" });
      setConvs(prev => prev.filter(c => c.id !== convId));
      if (activeConv?.id === convId) { setActiveConv(null); setView("list"); }
    } catch { /* silent */ }
  }

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || streaming) return;
    setInput("");

    let conv = activeConv;
    if (!conv) {
      conv = await newConv(text);
      if (!conv) return;
    }

    const userMsg: Msg = { id: Date.now(), role: "user", content: text.trim(), createdAt: new Date().toISOString() };
    setMsgs(prev => [...prev, userMsg]);
    setStreaming(true);
    setStreamingContent("");

    const abort = new AbortController();
    abortRef.current = abort;

    try {
      const resp = await fetch(`/api/anthropic/conversations/${conv.id}/messages`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ content: text.trim() }),
        signal: abort.signal,
      });

      if (!resp.ok || !resp.body) throw new Error("Erreur serveur");

      const reader = resp.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      let full = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const parts = buffer.split("\n\n");
        buffer = parts.pop() ?? "";
        for (const part of parts) {
          const line = part.startsWith("data: ") ? part.slice(6) : part;
          try {
            const parsed = JSON.parse(line);
            if (parsed.content) { full += parsed.content; setStreamingContent(full); }
            if (parsed.done) break;
            if (parsed.error) { full = parsed.error; setStreamingContent(full); }
          } catch { /* skip malformed chunk */ }
        }
      }

      setMsgs(prev => [
        ...prev,
        { id: Date.now() + 1, role: "assistant", content: full, createdAt: new Date().toISOString() },
      ]);
      setUnread(false);
    } catch (err: any) {
      if (err.name !== "AbortError") {
        const isRateLimit = err.message === "429";
        setMsgs(prev => [
          ...prev,
          {
            id: Date.now() + 1,
            role: "assistant",
            content: isRateLimit
              ? "Vous envoyez des messages trop rapidement. Attendez une minute avant de réessayer."
              : "Désolée, une erreur s'est produite. Réessayez dans un instant.",
            createdAt: new Date().toISOString(),
          },
        ]);
      }
    } finally {
      setStreaming(false);
      setStreamingContent("");
    }
  }, [activeConv, streaming]);

  function handleKey(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(input); }
  }

  function backToList() {
    abortRef.current?.abort();
    setView("list");
    setActiveConv(null);
    setMsgs([]);
    setStreamingContent("");
    setStreaming(false);
    loadConvs();
  }

  if (!isSignedIn) return null;

  return (
    <>
      {/* ── Floating button ── */}
      <AnimatePresence>
        {!open && (
          <motion.button
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0, opacity: 0 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            onClick={() => { setOpen(true); setUnread(false); }}
            className="fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full bg-primary shadow-lg shadow-primary/30 flex items-center justify-center text-primary-foreground hover:scale-105 transition-transform"
            aria-label="Ouvrir l'assistant"
          >
            {unread && (
              <span className="absolute -top-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-background" />
            )}
            <MessageCircle className="w-6 h-6" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* ── Panel ── */}
      <AnimatePresence>
        {open && (
          <>
            {/* Backdrop (mobile only) */}
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/30 sm:hidden"
              onClick={() => setOpen(false)}
            />

            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.97 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 20, scale: 0.97 }}
              transition={{ type: "spring", stiffness: 300, damping: 28 }}
              className="fixed bottom-6 right-6 z-50 w-[360px] max-w-[calc(100vw-2rem)] h-[540px] max-h-[calc(100dvh-5rem)] bg-card border border-border/60 rounded-2xl shadow-2xl flex flex-col overflow-hidden"
            >
              {/* Header */}
              <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border/40 flex-shrink-0 bg-card/95">
                {view === "chat" && (
                  <button onClick={backToList} className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors flex-shrink-0">
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                )}
                <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Sparkles className="w-4 h-4 text-primary" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm leading-tight">Sofia</p>
                  <p className="text-xs text-muted-foreground/70 flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 inline-block" />
                    Assistante Serenya · en ligne
                  </p>
                </div>
                {view === "list" && (
                  <button
                    onClick={() => newConv().then(() => {})}
                    className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors"
                    title="Nouvelle conversation"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                )}
                <button onClick={() => setOpen(false)} className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Body */}
              <AnimatePresence mode="wait">
                {view === "list" ? (
                  <motion.div key="list" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 overflow-y-auto">
                    {/* Welcome banner — proactive on /dashboard, static elsewhere */}
                    <div className="px-4 py-5 border-b border-border/25">
                      {greetingLoading ? (
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                            <Sparkles className="w-4 h-4 text-primary" />
                          </div>
                          <div className="space-y-1.5 flex-1">
                            <div className="h-3.5 w-3/4 rounded-md bg-muted/60 animate-pulse" />
                            <div className="h-3 w-1/2 rounded-md bg-muted/40 animate-pulse" />
                          </div>
                        </div>
                      ) : greeting ? (
                        <div className="space-y-3">
                          <div className="flex items-start gap-2.5">
                            <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                              <Sparkles className="w-4 h-4 text-primary" />
                            </div>
                            <div className="flex-1">
                              <p className="text-xs text-muted-foreground/50 mb-1 font-medium uppercase tracking-wider">Sofia</p>
                              <p className="text-sm leading-relaxed text-foreground/90">{greeting}</p>
                            </div>
                          </div>
                          <button
                            onClick={() => newConv(greeting).then(conv => conv && sendMessage("Que me conseilles-tu aujourd'hui ?"))}
                            className="w-full flex items-center justify-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 py-2 rounded-xl border border-primary/20 hover:bg-primary/5 transition-all"
                          >
                            Parler à {agentName} <ArrowRight className="w-3 h-3" />
                          </button>
                        </div>
                      ) : (
                        <>
                          <p className="text-sm font-medium mb-1">Bonjour ! Je suis Sofia 👋</p>
                          <p className="text-xs text-muted-foreground leading-relaxed">
                            Je suis là pour vous aider avec toutes vos questions sur vos démarches de changement d'adresse.
                          </p>
                        </>
                      )}
                    </div>

                    {/* Quick suggestions */}
                    <div className="px-4 py-3 border-b border-border/20">
                      <p className="text-xs uppercase tracking-wider text-muted-foreground/50 font-semibold mb-2">Questions fréquentes</p>
                      <div className="space-y-1.5">
                        {suggestions.map(s => (
                          <button key={s}
                            onClick={() => newConv(s).then(conv => conv && sendMessage(s))}
                            className="w-full text-left text-xs px-3 py-2 rounded-xl bg-muted/30 hover:bg-muted/60 transition-colors text-foreground/80 hover:text-foreground"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Past conversations */}
                    {convs.length > 0 && (
                      <div className="px-4 py-3">
                        <p className="text-xs uppercase tracking-wider text-muted-foreground/50 font-semibold mb-2">Conversations précédentes</p>
                        <div className="space-y-1">
                          {convs.map(c => (
                            <div key={c.id}
                              onClick={() => openConv(c)}
                              className="flex items-center gap-2 px-3 py-2.5 rounded-xl hover:bg-muted/40 cursor-pointer group transition-colors"
                            >
                              <MessageCircle className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0" />
                              <span className="flex-1 text-xs truncate text-foreground/80 group-hover:text-foreground transition-colors">{c.title}</span>
                              <button
                                onClick={(e) => deleteConv(e, c.id)}
                                className="opacity-0 group-hover:opacity-100 w-5 h-5 rounded flex items-center justify-center hover:bg-destructive/10 hover:text-destructive text-muted-foreground transition-all"
                              >
                                <Trash2 className="w-3 h-3" />
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {convs.length === 0 && (
                      <div className="px-4 py-8 text-center">
                        <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-3">
                          <MessageCircle className="w-4 h-4 text-primary/60" />
                        </div>
                        <p className="text-xs text-muted-foreground/60 mb-1">Vos conversations apparaîtront ici</p>
                        <p className="text-sm text-muted-foreground/40">Posez une question à Sofia pour commencer.</p>
                      </div>
                    )}
                  </motion.div>
                ) : (
                  <motion.div key="chat" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex-1 flex flex-col min-h-0">
                    {/* Messages */}
                    <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
                      {loading && (
                        <div className="flex justify-center py-6">
                          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground/40" />
                        </div>
                      )}

                      {msgs.length === 0 && !loading && (
                        <div className="text-center py-8 space-y-2">
                          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mx-auto">
                            <Sparkles className="w-5 h-5 text-primary" />
                          </div>
                          <p className="text-xs text-muted-foreground">Je suis {agentName}, votre assistante. Comment puis-je vous aider ?</p>
                          <div className="space-y-1.5 mt-3">
                            {suggestions.slice(0, 2).map(s => (
                              <button key={s} onClick={() => sendMessage(s)}
                                className="w-full text-left text-xs px-3 py-2 rounded-xl bg-muted/30 hover:bg-muted/60 transition-colors text-foreground/80">
                                {s}
                              </button>
                            ))}
                          </div>
                        </div>
                      )}

                      {msgs.map(m => {
                        const isAssistant = m.role === "assistant";
                        const { text: msgText, chips } = isAssistant
                          ? parseChips(m.content)
                          : { text: m.content, chips: [] as Chip[] };
                        return (
                          <div key={m.id} className={cn("flex flex-col", m.role === "user" ? "items-end" : "items-start")}>
                            <div className={cn("flex gap-2.5", m.role === "user" ? "justify-end" : "justify-start")}>
                              {isAssistant && (
                                <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                                  <Sparkles className="w-3 h-3 text-primary" />
                                </div>
                              )}
                              <div className={cn(
                                "max-w-[82%] rounded-2xl px-3.5 py-2.5",
                                m.role === "user"
                                  ? "bg-primary text-primary-foreground rounded-br-sm"
                                  : "bg-muted/50 rounded-bl-sm"
                              )}>
                                {isAssistant
                                  ? <div className="space-y-0.5">{renderContent(msgText)}</div>
                                  : <p className="text-[13px] leading-relaxed">{msgText}</p>
                                }
                              </div>
                            </div>
                            {/* Action chips — rendered below the message bubble */}
                            {chips.length > 0 && (
                              <div className="flex flex-wrap gap-1.5 mt-1.5 ml-8">
                                {chips.map((chip, ci) => (
                                  <Link key={ci} href={chip.href} onClick={() => setOpen(false)}>
                                    <button className="flex items-center gap-1 text-xs font-medium px-3 py-1.5 rounded-full border border-primary/25 bg-primary/5 text-primary hover:bg-primary/15 hover:border-primary/40 transition-all">
                                      {chip.label}
                                      <ArrowRight className="w-3 h-3" />
                                    </button>
                                  </Link>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}

                      {/* Streaming message */}
                      {streaming && (
                        <div className="flex gap-2.5 justify-start">
                          <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
                            <Sparkles className="w-3 h-3 text-primary" />
                          </div>
                          <div className="max-w-[82%] rounded-2xl rounded-bl-sm px-3.5 py-2.5 bg-muted/50">
                            {streamingContent ? (
                              <div className="space-y-0.5">{renderContent(streamingContent)}</div>
                            ) : (
                              <div className="flex gap-1 items-center py-1">
                                {[0, 0.15, 0.3].map((delay, i) => (
                                  <motion.span key={i} className="w-1.5 h-1.5 rounded-full bg-muted-foreground/40"
                                    animate={{ opacity: [0.3, 1, 0.3], y: [0, -3, 0] }}
                                    transition={{ repeat: Infinity, duration: 1, delay }} />
                                ))}
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      <div ref={bottomRef} />
                    </div>

                    {/* Input */}
                    <div className="flex-shrink-0 px-3 pb-3 pt-2 border-t border-border/30">
                      <div className="flex gap-2 items-end bg-muted/30 rounded-xl border border-border/40 px-3 py-2 focus-within:border-primary/40 transition-colors">
                        <textarea
                          ref={inputRef}
                          value={input}
                          onChange={e => setInput(e.target.value)}
                          onKeyDown={handleKey}
                          placeholder="Écrivez votre question…"
                          rows={1}
                          disabled={streaming}
                          className="flex-1 bg-transparent resize-none text-[13px] placeholder:text-muted-foreground/40 focus:outline-none max-h-24 leading-relaxed disabled:opacity-50"
                          style={{ fieldSizing: "content" } as any}
                        />
                        <button
                          onClick={() => sendMessage(input)}
                          disabled={!input.trim() || streaming}
                          className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center text-primary-foreground disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/90 transition-all flex-shrink-0"
                        >
                          {streaming
                            ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                            : <Send className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                      <p className="text-xs text-muted-foreground/40 text-center mt-1.5">Entrée pour envoyer · Shift+Entrée pour saut de ligne</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
