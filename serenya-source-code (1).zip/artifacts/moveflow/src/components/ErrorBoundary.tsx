import { Component, type ErrorInfo, type ReactNode } from "react";
import { AlertTriangle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props { children: ReactNode }
interface State { error: Error | null }

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // In production you'd send to Sentry / LogRocket here
    console.error("[ErrorBoundary]", error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;

    return (
      <div className="flex h-screen items-center justify-center bg-background px-6">
        <div className="max-w-md w-full text-center">
          <div className="w-14 h-14 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto mb-5">
            <AlertTriangle className="w-7 h-7 text-destructive" />
          </div>
          <h1 className="text-xl font-semibold mb-2">Une erreur inattendue s'est produite</h1>
          <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
            L'application a rencontré un problème. Rafraîchissez la page — si le problème persiste, contactez le support.
          </p>
          <details className="text-left mb-6">
            <summary className="text-xs text-muted-foreground/60 cursor-pointer hover:text-muted-foreground transition-colors mb-2">
              Détails techniques
            </summary>
            <pre className="text-xs bg-muted/50 rounded-lg p-3 overflow-auto max-h-32 text-muted-foreground border border-border/50">
              {this.state.error.message}
            </pre>
          </details>
          <Button onClick={() => window.location.reload()} className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Rafraîchir la page
          </Button>
        </div>
      </div>
    );
  }
}
