import { motion } from "@/lib/motion-compat";
import { Sparkles, Shield, Lock, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { cn } from "@/lib/utils";

interface SerenyaAuthPageProps {
  children: React.ReactNode;
  mode: "sign-in" | "sign-up";
}

export default function SerenyaAuthPage({ children, mode }: SerenyaAuthPageProps) {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background px-4 py-8 relative overflow-hidden">
      {/* Subtle ambient background */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/[0.03] rounded-full blur-3xl" />
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-violet-500/[0.03] rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-[440px] relative z-10">
        {/* Back to home */}
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <Link href="/">
            <button className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
              <ArrowLeft className="w-4 h-4" />
              Retour à l&apos;accueil
            </button>
          </Link>
        </motion.div>

        {/* Brand header */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="text-center mb-6"
        >
          <div className="flex items-center justify-center gap-2.5 mb-4">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center shadow-lg shadow-primary/20">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">Serenya</span>
          </div>
          <h1 className="font-semibold text-lg text-foreground">
            {mode === "sign-in" ? "Bienvenue sur Serenya" : "Rejoignez Serenya"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Votre assistant administratif de déménagement
          </p>
        </motion.div>

        {/* Auth card */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
          className="rounded-2xl border border-border/50 bg-card shadow-xl shadow-black/[0.04] overflow-hidden"
        >
          {children}
        </motion.div>

        {/* Trust footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.4 }}
          className="mt-6 space-y-3"
        >
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground/60">
            <span className="flex items-center gap-1">
              <Lock className="w-3 h-3" /> Connexion sécurisée
            </span>
            <span className="flex items-center gap-1">
              <Shield className="w-3 h-3" /> RGPD conforme
            </span>
          </div>
          <p className="text-xs text-muted-foreground/40 text-center leading-relaxed">
            Vos informations restent privées et sécurisées. Aucune démarche sensible n&apos;est effectuée sans votre validation.
          </p>
          <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground/40">
            <Link href="/confidentialite">
              <span className="hover:text-muted-foreground transition-colors cursor-pointer">Confidentialité</span>
            </Link>
            <span className="w-1 h-1 rounded-full bg-muted-foreground/20" />
            <Link href="/cgu">
              <span className="hover:text-muted-foreground transition-colors cursor-pointer">CGU</span>
            </Link>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
