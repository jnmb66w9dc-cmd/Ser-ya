import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { Sparkles, ArrowRight, RefreshCw, Loader2, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

interface Insight {
  id: string;
  icon: string;
  title: string;
  description: string;
  action: string;
  actionLabel: string;
}

interface UserContext {
  totalServices: number;
  totalAutomations: number;
  failedAutomations: number;
  successRate: number | null;
  daysSinceLastAutomation: number | null;
  connectedServices: { name: string; category: string }[];
}

const ROUTE_MAP: Record<string, string> = {
  services: "/services",
  automations: "/automations",
  addresses: "/addresses",
  dashboard: "/dashboard",
};

const CACHE_KEY = "serenya_insights_cache";
const CACHE_TTL_MS = 5 * 60 * 1000; // 5 minutes

interface CachedInsights {
  data: Insight[];
  cachedAt: number;
}

function readCache(): Insight[] | null {
  try {
    const raw = sessionStorage.getItem(CACHE_KEY);
    if (!raw) return null;
    const parsed: CachedInsights = JSON.parse(raw);
    if (Date.now() - parsed.cachedAt > CACHE_TTL_MS) {
      sessionStorage.removeItem(CACHE_KEY);
      return null;
    }
    return parsed.data;
  } catch {
    return null;
  }
}

function writeCache(data: Insight[]): void {
  try {
    const payload: CachedInsights = { data, cachedAt: Date.now() };
    sessionStorage.setItem(CACHE_KEY, JSON.stringify(payload));
  } catch { /* quota exceeded — ignore */ }
}

async function fetchWithCredentials(url: string, opts?: RequestInit) {
  const r = await fetch(url, { credentials: "include", ...opts });
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}

export default function AIInsights() {
  const [insights, setInsights] = useState<Insight[]>([]);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const [forceRefresh, setForceRefresh] = useState(0);

  useEffect(() => {
    let cancelled = false;

    async function load(skipCache = false) {
      setLoading(true);

      // Try cache first (unless forced refresh)
      if (!skipCache) {
        const cached = readCache();
        if (cached) {
          if (!cancelled) { setInsights(cached); setLoading(false); }
          return;
        }
      }

      try {
        const ctx: UserContext = await fetchWithCredentials("/api/ai/user-context");
        const data: Insight[] = await fetchWithCredentials("/api/ai/insights", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ context: ctx }),
        });
        if (!cancelled) {
          writeCache(data);
          setInsights(data);
        }
      } catch {
        if (!cancelled) {
          // Try to use stale cache as fallback even if expired
          const stale = (() => {
            try {
              const raw = sessionStorage.getItem(CACHE_KEY);
              return raw ? (JSON.parse(raw) as CachedInsights).data : null;
            } catch { return null; }
          })();
          setInsights(stale ?? []);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load(forceRefresh > 0);
    return () => { cancelled = true; };
  }, [forceRefresh]);

  function handleRefresh() {
    sessionStorage.removeItem(CACHE_KEY);
    setDismissed(new Set());
    setForceRefresh(k => k + 1);
  }

  const visible = insights.filter(i => !dismissed.has(i.id));

  if (!loading && visible.length === 0) return null;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.25, duration: 0.35 }}
      className="rounded-2xl border border-primary/15 bg-primary/[0.03] overflow-hidden"
    >
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-primary/10">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-primary/15 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
          </div>
          <span className="text-sm font-semibold">Suggestions de Sofia</span>
          {!loading && visible.length > 0 && (
            <span className="text-xs px-1.5 py-0.5 rounded-full bg-primary/10 text-primary/70 font-medium">
              {visible.length}
            </span>
          )}
        </div>
        <button
          onClick={handleRefresh}
          disabled={loading}
          className="w-6 h-6 rounded-md flex items-center justify-center text-muted-foreground hover:text-foreground hover:bg-muted/40 transition-colors disabled:opacity-40"
          title="Actualiser les suggestions"
        >
          <RefreshCw className={cn("w-3 h-3", loading && "animate-spin")} />
        </button>
      </div>

      {/* Insights */}
      <div className="p-3 space-y-2">
        {loading ? (
          <div className="flex items-center gap-2.5 py-3 px-2">
            <Loader2 className="w-4 h-4 animate-spin text-primary/50" />
            <p className="text-xs text-muted-foreground">Sofia analyse votre profil…</p>
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            {visible.map((insight, i) => (
              <motion.div
                key={insight.id}
                initial={{ opacity: 0, x: -6 }} animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 6, scale: 0.97 }}
                transition={{ delay: i * 0.08, duration: 0.25 }}
                className="group relative flex items-start gap-3 rounded-xl border border-border/40 bg-card hover:border-primary/25 hover:bg-primary/[0.02] p-3.5 transition-all"
              >
                {/* Icon */}
                <div className="w-9 h-9 rounded-xl bg-muted/70 flex items-center justify-center flex-shrink-0 text-lg leading-none">
                  {insight.icon}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0 space-y-1">
                  <p className="text-sm font-semibold leading-snug">{insight.title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed">{insight.description}</p>
                  <Link href={ROUTE_MAP[insight.action] ?? "/dashboard"}>
                    <button className="flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 transition-colors mt-1">
                      {insight.actionLabel}
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </Link>
                </div>

                {/* Dismiss */}
                <button
                  onClick={() => setDismissed(prev => new Set([...prev, insight.id]))}
                  className="flex-shrink-0 w-5 h-5 rounded flex items-center justify-center text-muted-foreground/40 hover:text-muted-foreground hover:bg-muted/40 opacity-0 group-hover:opacity-100 transition-all"
                >
                  <X className="w-3 h-3" />
                </button>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>

      {/* Sofia label */}
      <div className="px-4 pb-3 flex items-center gap-1.5">
        <div className="w-1 h-1 rounded-full bg-emerald-400 animate-pulse" />
        <p className="text-xs text-muted-foreground/40">Sofia · Suggestions personnalisées · Mis à jour toutes les 5 min</p>
      </div>
    </motion.div>
  );
}
