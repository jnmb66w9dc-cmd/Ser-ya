import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { X, CheckCircle2, XCircle, Sparkles, Loader2, Trophy, AlertTriangle, ArrowRight, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { Link } from "wouter";

interface TaskNote {
  serviceName: string;
  status: "completed" | "failed" | "skipped" | string;
  duration?: string;
  note: string;
  suggestion?: string;
}

interface DebriefData {
  narrative: string;
  score: number;
  scoreMessage: string;
  taskNotes: TaskNote[];
}

interface Props {
  automationId: number;
  addressLabel?: string;
  onClose: () => void;
}

const ORG_COLORS: Record<string, string> = {
  "EDF": "bg-blue-600", "Orange": "bg-orange-500", "BNP Paribas": "bg-emerald-700",
  "Amazon": "bg-amber-500", "Free": "bg-red-600", "AXA": "bg-sky-700",
  "MAIF": "bg-green-600", "La Poste": "bg-yellow-600", "CPAM": "bg-blue-700",
  "SFR": "bg-red-700", "Netflix": "bg-red-600", "PayPal": "bg-blue-500",
  "CAF": "bg-indigo-600",
};

function ScoreRing({ score }: { score: number }) {
  const size = 96;
  const stroke = 7;
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const color = score >= 90 ? "#22c55e" : score >= 60 ? "#f59e0b" : "#ef4444";
  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="rotate-[-90deg]">
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-muted/40" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={r} fill="none"
          strokeWidth={stroke} strokeLinecap="round"
          stroke={color}
          strokeDasharray={circ}
          initial={{ strokeDashoffset: circ }}
          animate={{ strokeDashoffset: circ - (score / 100) * circ }}
          transition={{ duration: 1, ease: "easeOut", delay: 0.3 }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <motion.span
          className="text-2xl font-bold tabular-nums leading-none"
          style={{ color }}
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }}
        >
          {score}%
        </motion.span>
        <span className="text-[9px] text-muted-foreground/60 uppercase tracking-wider mt-0.5">succès</span>
      </div>
    </div>
  );
}

export default function AutomationDebrief({ automationId, addressLabel, onClose }: Props) {
  const [data, setData] = useState<DebriefData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    async function fetchDebrief() {
      try {
        const r = await fetch(`/api/automations/${automationId}/debrief`, {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
        });
        if (!r.ok) throw new Error("Erreur serveur");
        const json = await r.json();
        setData(json);
      } catch {
        setError(true);
      } finally {
        setLoading(false);
      }
    }
    fetchDebrief();
  }, [automationId]);

  const hasFailed = data?.taskNotes.some(t => t.status !== "completed") ?? false;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
        onClick={(e: React.MouseEvent) => e.target === e.currentTarget && onClose()}
      >
        <motion.div
          initial={{ opacity: 0, y: 24, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 12, scale: 0.98 }}
          transition={{ type: "spring", stiffness: 300, damping: 28 }}
          className="w-full max-w-lg bg-card border border-border/60 rounded-2xl shadow-2xl overflow-hidden max-h-[90dvh] flex flex-col"
        >
          {/* Header */}
          <div className="flex items-center gap-3 px-5 py-4 border-b border-border/40 flex-shrink-0">
            <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm">Compte-rendu Sofia</p>
              <p className="text-xs text-muted-foreground/60 truncate">
                {addressLabel ? `Préparation — ${addressLabel}` : "Analyse de votre préparation"}
              </p>
            </div>
            <button onClick={onClose} className="w-7 h-7 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3">
                <div className="relative">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                    <Sparkles className="w-5 h-5 text-primary" />
                  </div>
                  <Loader2 className="absolute -bottom-1 -right-1 w-4 h-4 animate-spin text-primary" />
                </div>
                <p className="text-sm font-medium">Sofia analyse votre session…</p>
                <p className="text-xs text-muted-foreground/50 text-center max-w-xs">
                  Je passe en revue chaque démarche pour vous préparer un bilan personnalisé.
                </p>
              </div>
            ) : error ? (
              <div className="flex flex-col items-center justify-center py-16 gap-3 text-center px-6">
                <AlertTriangle className="w-8 h-8 text-amber-400/60" />
                <p className="text-sm font-medium">Analyse temporairement indisponible</p>
                <p className="text-xs text-muted-foreground/50">Sofia reviendra avec votre bilan dès que possible.</p>
                <Button variant="outline" size="sm" onClick={onClose} className="mt-2">Fermer</Button>
              </div>
            ) : data ? (
              <div className="p-5 space-y-6">
                {/* Score + narrative */}
                <div className="flex items-start gap-5">
                  <ScoreRing score={data.score} />
                  <div className="flex-1 pt-1">
                    <div className="flex items-center gap-2 mb-2">
                      {data.score === 100 && <Trophy className="w-4 h-4 text-amber-400" />}
                      <p className="font-semibold text-sm">{data.scoreMessage}</p>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{data.narrative}</p>
                  </div>
                </div>

                {/* Task breakdown */}
                <div>
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
                    Détail service par service
                  </p>
                  <div className="space-y-2">
                    {data.taskNotes.map((task, i) => {
                      const isDone = task.status === "completed";
                      const color = ORG_COLORS[task.serviceName] ?? "bg-primary";
                      return (
                        <motion.div
                          key={i}
                          initial={{ opacity: 0, x: -8 }} animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: 0.1 + i * 0.07 }}
                          className={cn(
                            "rounded-xl border p-3.5 flex items-start gap-3",
                            isDone ? "bg-emerald-500/5 border-emerald-500/15" : "bg-amber-500/5 border-amber-500/15"
                          )}
                        >
                          <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center text-white font-bold text-xs flex-shrink-0", color)}>
                            {task.serviceName[0]}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-0.5">
                              <span className="text-sm font-semibold">{task.serviceName}</span>
                              {task.duration && (
                                <span className="text-xs text-muted-foreground/50 font-mono">{task.duration}</span>
                              )}
                              {isDone
                                ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 ml-auto flex-shrink-0" />
                                : <XCircle className="w-3.5 h-3.5 text-amber-500 ml-auto flex-shrink-0" />
                              }
                            </div>
                            <p className="text-xs text-muted-foreground leading-relaxed">{task.note}</p>
                            {task.suggestion && (
                              <p className="text-xs text-amber-400/80 mt-1 flex items-center gap-1">
                                <ArrowRight className="w-3 h-3 flex-shrink-0" />
                                {task.suggestion}
                              </p>
                            )}
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>
                </div>

                {/* Suggested next action */}
                {hasFailed && (
                  <div className="rounded-xl bg-primary/5 border border-primary/15 p-4">
                    <p className="text-xs font-semibold mb-2 flex items-center gap-1.5">
                      <ArrowRight className="w-3.5 h-3.5 text-primary" />
                      Prochaine étape recommandée
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed mb-3">
                      Consultez la page Préparations pour accéder aux détails de chaque service en échec et aux instructions personnalisées.
                    </p>
                    <Link href="/automations" onClick={onClose}>
                      <Button size="sm" variant="outline" className="gap-2 text-xs h-9 w-full">
                        <RotateCcw className="w-3 h-3" /> Voir les démarches à compléter
                      </Button>
                    </Link>
                  </div>
                )}

                {/* Footer note */}
                <p className="text-xs text-muted-foreground/40 text-center">
                  Analyse de l'assistant Serenya · Pour information · Non contractuelle
                </p>
              </div>
            ) : null}
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}
