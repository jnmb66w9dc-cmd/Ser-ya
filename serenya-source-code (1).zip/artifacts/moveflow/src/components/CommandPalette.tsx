import { useEffect, useState, useCallback } from "react";
import { useLocation } from "wouter";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput,
  CommandItem, CommandList, CommandSeparator, CommandShortcut,
} from "@/components/ui/command";
import {
  LayoutDashboard, Building2, MapPin, Zap, Settings, Tag,
  Plus, Download, Sparkles, MessageCircle, Moon, Sun, LogOut,
  ArrowRight, HelpCircle, Shield, Keyboard,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useClerk } from "@clerk/react";

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onOpenChat?: () => void;
}

const NAV_ITEMS = [
  { label: "Tableau de bord",    href: "/dashboard",   icon: LayoutDashboard, shortcut: "G D" },
  { label: "Services connectés", href: "/services",    icon: Building2,       shortcut: "G S" },
  { label: "Mes adresses",       href: "/addresses",   icon: MapPin,          shortcut: "G A" },
  { label: "Préparations",    href: "/automations", icon: Zap,             shortcut: "G Z" },
  { label: "Paramètres",         href: "/settings",    icon: Settings,        shortcut: "G P" },
  { label: "Tarifs",             href: "/pricing",     icon: Tag,             shortcut: ""    },
];

export default function CommandPalette({ open, onOpenChange, onOpenChat }: CommandPaletteProps) {
  const [, navigate] = useLocation();
  const { theme, setTheme } = useTheme();
  const { signOut } = useClerk();

  const go = useCallback((href: string) => {
    navigate(href);
    onOpenChange(false);
  }, [navigate, onOpenChange]);

  function run(fn: () => void) {
    fn();
    onOpenChange(false);
  }

  // Global Cmd+K / Ctrl+K listener
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        onOpenChange(!open);
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, onOpenChange]);

  return (
    <CommandDialog open={open} onOpenChange={onOpenChange}>
      <CommandInput placeholder="Rechercher une page, une action…" />
      <CommandList>
        <CommandEmpty>
          <div className="flex flex-col items-center gap-2 py-4">
            <Sparkles className="w-6 h-6 text-muted-foreground/30" />
            <p className="text-sm text-muted-foreground">Aucun résultat trouvé.</p>
          </div>
        </CommandEmpty>

        {/* Navigation */}
        <CommandGroup heading="Navigation">
          {NAV_ITEMS.map((item) => (
            <CommandItem
              key={item.href}
              onSelect={() => go(item.href)}
              className="gap-3 cursor-pointer"
            >
              <div className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0">
                <item.icon className="w-3.5 h-3.5 text-muted-foreground" />
              </div>
              <span>{item.label}</span>
              <ArrowRight className="w-3.5 h-3.5 text-muted-foreground/30 ml-auto mr-1 flex-shrink-0" />
              {item.shortcut && <CommandShortcut>{item.shortcut}</CommandShortcut>}
            </CommandItem>
          ))}
        </CommandGroup>

        <CommandSeparator />

        {/* Actions */}
        <CommandGroup heading="Actions rapides">
          <CommandItem onSelect={() => go("/addresses")} className="gap-3 cursor-pointer">
            <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
              <Plus className="w-3.5 h-3.5 text-primary" />
            </div>
            Nouvelle adresse
          </CommandItem>
          <CommandItem onSelect={() => go("/dashboard")} className="gap-3 cursor-pointer">
            <div className="w-7 h-7 rounded-lg bg-violet-500/10 flex items-center justify-center flex-shrink-0">
              <Zap className="w-3.5 h-3.5 text-violet-400" />
            </div>
            Lancer une préparation
          </CommandItem>
          <CommandItem onSelect={() => go("/services")} className="gap-3 cursor-pointer">
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center flex-shrink-0">
              <Building2 className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            Connecter un service
          </CommandItem>
          <CommandItem
            onSelect={() => run(async () => {
              const res = await fetch("/api/user/export", { credentials: "include" });
              if (!res.ok) return;
              const blob = await res.blob();
              const url = URL.createObjectURL(blob);
              const a = document.createElement("a");
              a.href = url; a.download = `serenya-export-${new Date().toISOString().split("T")[0]}.json`;
              a.click(); URL.revokeObjectURL(url);
            })}
            className="gap-3 cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <Download className="w-3.5 h-3.5 text-blue-400" />
            </div>
            Exporter mes données (RGPD)
          </CommandItem>
          <CommandItem
            onSelect={() => run(() => setTheme(theme === "dark" ? "light" : "dark"))}
            className="gap-3 cursor-pointer"
          >
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center flex-shrink-0">
              {theme === "dark"
                ? <Sun className="w-3.5 h-3.5 text-amber-400" />
                : <Moon className="w-3.5 h-3.5 text-amber-400" />
              }
            </div>
            Basculer en mode {theme === "dark" ? "clair" : "sombre"}
            <CommandShortcut>⌘ T</CommandShortcut>
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        {/* Sofia */}
        <CommandGroup heading="Assistant Sofia">
          <CommandItem
            onSelect={() => run(() => onOpenChat?.())}
            className="gap-3 cursor-pointer"
          >
            <div className="w-7 h-7 rounded-xl bg-primary/15 flex items-center justify-center flex-shrink-0">
              <Sparkles className="w-3.5 h-3.5 text-primary" />
            </div>
            <div>
              <p className="text-sm font-medium">Demander à Sofia</p>
              <p className="text-xs text-muted-foreground">Posez n'importe quelle question sur vos démarches</p>
            </div>
            <CommandShortcut>⌘ J</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => run(() => onOpenChat?.())} className="gap-3 cursor-pointer">
            <div className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0">
              <MessageCircle className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            Que faire si une tâche échoue ?
          </CommandItem>
          <CommandItem onSelect={() => run(() => onOpenChat?.())} className="gap-3 cursor-pointer">
            <div className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0">
              <HelpCircle className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            Délais de traitement par organisme
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        {/* Keyboard shortcuts */}
        <CommandGroup heading="Raccourcis clavier">
          <CommandItem onSelect={() => onOpenChange(false)} className="gap-3 cursor-default opacity-70 select-none">
            <div className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0">
              <Keyboard className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            <span>Afficher tous les raccourcis</span>
            <CommandShortcut>?</CommandShortcut>
          </CommandItem>
          <CommandItem onSelect={() => onOpenChange(false)} className="gap-3 cursor-default opacity-60 select-none pointer-events-none">
            <div className="w-7 h-7 flex-shrink-0" />
            <span className="text-xs text-muted-foreground">Navigation : G puis D / S / A / Z / P</span>
          </CommandItem>
        </CommandGroup>

        <CommandSeparator />

        {/* Account */}
        <CommandGroup heading="Compte">
          <CommandItem onSelect={() => go("/settings")} className="gap-3 cursor-pointer">
            <div className="w-7 h-7 rounded-lg bg-muted/50 flex items-center justify-center flex-shrink-0">
              <Shield className="w-3.5 h-3.5 text-muted-foreground" />
            </div>
            Sécurité & Confidentialité
          </CommandItem>
          <CommandItem
            onSelect={() => run(() => signOut())}
            className="gap-3 cursor-pointer text-destructive data-[selected=true]:bg-destructive/10"
          >
            <div className="w-7 h-7 rounded-lg bg-destructive/10 flex items-center justify-center flex-shrink-0">
              <LogOut className="w-3.5 h-3.5 text-destructive" />
            </div>
            Se déconnecter
          </CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
