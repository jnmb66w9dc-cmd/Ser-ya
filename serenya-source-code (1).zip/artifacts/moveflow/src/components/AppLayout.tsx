import { useState, useEffect, useRef } from "react";
import { useAuth } from "@clerk/react";
import { Redirect, useLocation } from "wouter";
import { Menu, Moon, Sun, HelpCircle, Search, Keyboard, ChevronLeft } from "lucide-react";
import AppSidebar from "./AppSidebar";
import HelpCenter from "./HelpCenter";
import CommandPalette from "./CommandPalette";
import KeyboardShortcutsModal from "./KeyboardShortcutsModal";
import { motion } from "@/lib/motion-compat";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import { useTheme } from "next-themes";
import { Skeleton } from "@/components/ui/skeleton";
import NotificationDropdown from "./NotificationDropdown";
import FeedbackWidget from "./FeedbackWidget";

interface AppLayoutProps {
  children: React.ReactNode;
  title?: string;
}

export default function AppLayout({ children, title }: AppLayoutProps) {
  const { isSignedIn, isLoaded } = useAuth();
  const [location] = useLocation();
  const [sidebarOpen, setSidebarOpen]     = useState(false);
  const [helpOpen, setHelpOpen]           = useState(false);
  const [cmdOpen, setCmdOpen]             = useState(false);
  const [shortcutsOpen, setShortcutsOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  function openChat() {
    window.dispatchEvent(new CustomEvent("serenya:open-chat"));
  }

  // Global keyboard shortcuts (Linear-style)
  const gPressedRef = useRef(false);
  const gTimerRef   = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!isSignedIn) return;
    function handler(e: KeyboardEvent) {
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (tag === "input" || tag === "textarea" || (e.target as HTMLElement)?.isContentEditable) return;

      // ⌘T → toggle theme
      if ((e.metaKey || e.ctrlKey) && e.key === "t") {
        e.preventDefault();
        setTheme(theme === "dark" ? "light" : "dark");
        return;
      }
      // ⌘J → open chat
      if ((e.metaKey || e.ctrlKey) && e.key === "j") {
        e.preventDefault();
        openChat();
        return;
      }

      // ? → keyboard shortcuts modal
      if (e.key === "?" && !e.metaKey && !e.ctrlKey) {
        e.preventDefault();
        setShortcutsOpen(true);
        return;
      }

      // g+key navigation (like Linear)
      if (e.key.toLowerCase() === "g" && !e.metaKey && !e.ctrlKey && !e.altKey) {
        gPressedRef.current = true;
        if (gTimerRef.current) clearTimeout(gTimerRef.current);
        gTimerRef.current = setTimeout(() => { gPressedRef.current = false; }, 800);
        return;
      }
      if (gPressedRef.current) {
        const NAV: Record<string, string> = {
          d: "/dashboard", s: "/services", a: "/addresses",
          z: "/automations", f: "/documents", t: "/tasks", p: "/settings",
        };
        const dest = NAV[e.key.toLowerCase()];
        if (dest) { e.preventDefault(); window.location.href = dest; }
        gPressedRef.current = false;
        if (gTimerRef.current) clearTimeout(gTimerRef.current);
      }
    }
    window.addEventListener("keydown", handler);
    return () => {
      window.removeEventListener("keydown", handler);
      if (gTimerRef.current) clearTimeout(gTimerRef.current);
    };
  }, [isSignedIn, theme, setTheme]);

  if (!isLoaded) {
    return (
      <div className="flex h-screen bg-background">
        <div className="hidden lg:flex w-64 flex-col bg-sidebar animate-pulse" />
        <div className="flex-1 flex flex-col">
          <div className="h-14 border-b border-border bg-card flex items-center px-6 gap-4">
            <Skeleton className="h-6 w-40" />
            <div className="flex-1" />
            <Skeleton className="h-8 w-8 rounded-full" />
          </div>
          <div className="flex-1 p-6">
            <Skeleton className="h-8 w-48 mb-6" />
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!isSignedIn) return <Redirect to="/sign-in" />;

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      {/* Desktop Sidebar */}
      <aside aria-label="Navigation principale" className="hidden lg:flex w-64 flex-col flex-shrink-0 border-r border-sidebar-border">
        <AppSidebar onHelpOpen={() => setHelpOpen(true)} />
      </aside>

      {/* Mobile Sidebar */}
      <Sheet open={sidebarOpen} onOpenChange={setSidebarOpen}>
        <SheetContent side="left" className="p-0 w-64 border-r border-sidebar-border bg-sidebar">
          <AppSidebar onClose={() => setSidebarOpen(false)} onHelpOpen={() => { setSidebarOpen(false); setHelpOpen(true); }} />
        </SheetContent>
      </Sheet>

      {/* Help Center */}
      <HelpCenter open={helpOpen} onClose={() => setHelpOpen(false)} />

      {/* Command Palette */}
      <CommandPalette open={cmdOpen} onOpenChange={setCmdOpen} onOpenChat={openChat} />

      {/* Keyboard shortcuts modal */}
      <KeyboardShortcutsModal open={shortcutsOpen} onClose={() => setShortcutsOpen(false)} />

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* BETA transparency banner */}
        <div className="bg-amber-500/8 border-b border-amber-500/15 px-4 py-1.5 flex items-center justify-center gap-2 text-[11px] text-amber-400/80">
          <span className="px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 font-semibold text-[10px]">BETA</span>
          <span>Serenya prépare les démarches — vous finalisez sur chaque site. Connexions aux organismes en déploiement progressif.</span>
        </div>

        {/* Topbar */}
        <header className="h-14 border-b border-border bg-card/80 backdrop-blur-sm flex items-center px-4 lg:px-6 gap-3 flex-shrink-0 z-10">
          <Button
            variant="ghost"
            size="icon"
            aria-label="Ouvrir le menu"
            className="lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          {/* Back button — shown on all app pages except /dashboard */}
          {location !== "/dashboard" && (
            <Button
              variant="ghost"
              size="icon"
              aria-label="Retour"
              title="Retour (Alt+←)"
              className="text-muted-foreground hover:text-foreground"
              onClick={() => window.history.back()}
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
          )}
          {title && (
            <h1 className="text-base font-semibold text-foreground hidden lg:block">{title}</h1>
          )}
          <div className="flex-1" />
          {/* ⌘K Search trigger */}
          <button
            onClick={() => setCmdOpen(true)}
            className="hidden sm:flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-border/50 bg-muted/30 text-muted-foreground hover:text-foreground hover:border-border hover:bg-muted/50 transition-all text-xs"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Rechercher…</span>
            <kbd className="ml-1 flex items-center gap-0.5 text-xs font-mono bg-background/60 border border-border/60 rounded px-1 py-0.5 leading-none">
              ⌘K
            </kbd>
          </button>
          <Button
            variant="ghost"
            size="icon"
            className="sm:hidden text-muted-foreground hover:text-foreground"
            onClick={() => setCmdOpen(true)}
          >
            <Search className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="hidden sm:inline-flex text-muted-foreground hover:text-foreground"
            title="Raccourcis clavier (?)"
            onClick={() => setShortcutsOpen(true)}
          >
            <Keyboard className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground"
            title="Centre d'aide"
            onClick={() => setHelpOpen(true)}
          >
            <HelpCircle className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="text-muted-foreground hover:text-foreground"
            title={theme === "dark" ? "Passer en mode clair (⌘T)" : "Passer en mode sombre (⌘T)"}
            aria-label={theme === "dark" ? "Passer en mode clair" : "Passer en mode sombre"}
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </Button>
          <NotificationDropdown />
        </header>

        {/* Page content */}
        <main aria-label="Contenu principal" className="flex-1 overflow-y-auto">
          <motion.div
            key={typeof window !== "undefined" ? window.location.pathname : ""}
            initial={{ opacity: 0, y: 4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.15, ease: "easeOut" }}
            className="h-full"
          >
            {children}
          </motion.div>
        </main>
      </div>

      {/* Feedback widget — visible on all authenticated pages */}
      <FeedbackWidget />
    </div>
  );
}
