import { useEffect, useRef, useState } from "react";
import { useIsFetching, useIsMutating } from "@tanstack/react-query";
import { motion, AnimatePresence } from "@/lib/motion-compat";

export default function TopLoadingBar() {
  const isFetching  = useIsFetching();
  const isMutating  = useIsMutating();
  const isActive    = isFetching > 0 || isMutating > 0;

  const [progress, setProgress] = useState(0);
  const [visible,  setVisible]  = useState(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const hideTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    if (isActive) {
      setVisible(true);
      setProgress(10);
      if (timerRef.current) clearInterval(timerRef.current);
      timerRef.current = setInterval(() => {
        setProgress(p => {
          if (p >= 90) return 90;
          const delta = p < 50 ? 8 : p < 70 ? 4 : 1;
          return Math.min(90, p + delta);
        });
      }, 200);
    } else {
      if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
      setProgress(100);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
      hideTimerRef.current = setTimeout(() => {
        setVisible(false);
        setProgress(0);
      }, 400);
    }
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isActive]);

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed top-0 left-0 right-0 z-[100] h-0.5 pointer-events-none"
        >
          <motion.div
            className="h-full bg-primary rounded-r-full shadow-[0_0_8px_0] shadow-primary/60"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3, ease: "easeOut" }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
