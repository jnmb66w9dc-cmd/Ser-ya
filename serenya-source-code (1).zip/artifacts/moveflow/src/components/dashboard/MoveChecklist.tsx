import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { Card } from "@/components/ui/card";
import { ListChecks, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

const CHECKLIST_ITEMS = [
  { id: "addr",     label: "Enregistrer ma nouvelle adresse" },
  { id: "svcs",     label: "Connecter mes services (EDF, Orange, banque…)" },
  { id: "launch",   label: "Lancer la préparation Serenya" },
  { id: "elec",     label: "Confirmer la mise à jour EDF / électricité" },
  { id: "bank",     label: "Confirmer la banque (justificatif requis)" },
  { id: "insure",   label: "Notifier mutuelle et assurances" },
  { id: "official", label: "Démarches officielles (CPAM, CAF, Impôts)" },
];

const STORAGE_KEY = "serenya_move_checklist";

export default function MoveChecklist() {
  const [checkedItems, setCheckedItems] = useState<boolean[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : CHECKLIST_ITEMS.map(() => false);
    } catch { return CHECKLIST_ITEMS.map(() => false); }
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(checkedItems));
  }, [checkedItems]);

  return (
    <Card className="p-4 border border-card-border bg-card hover:border-primary/15 transition-all duration-200">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <ListChecks className="w-4 h-4 text-emerald-400" />
          <span className="font-semibold text-sm">Checklist déménagement</span>
        </div>
        <span className="text-xs text-muted-foreground/50 tabular-nums font-medium">
          {checkedItems.filter(Boolean).length}/{CHECKLIST_ITEMS.length}
        </span>
      </div>
      <div className="w-full h-1 bg-muted/60 rounded-full mb-3.5 overflow-hidden">
        <motion.div
          className="h-full bg-emerald-500 rounded-full"
          initial={{ width: 0 }}
          animate={{ width: `${(checkedItems.filter(Boolean).length / CHECKLIST_ITEMS.length) * 100}%` }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        />
      </div>
      <div className="space-y-1">
        {CHECKLIST_ITEMS.map((item, i) => (
          <button
            key={item.id}
            type="button"
            onClick={() => {
              const next = [...checkedItems];
              next[i] = !next[i];
              setCheckedItems(next);
            }}
            className="w-full flex items-center gap-2.5 py-1.5 text-left group/ck rounded-lg hover:bg-muted/20 px-1 transition-colors"
          >
            <div className={cn(
              "w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 transition-all duration-150",
              checkedItems[i]
                ? "border-emerald-500 bg-emerald-500"
                : "border-border/60 group-hover/ck:border-primary/50"
            )}>
              {checkedItems[i] && <CheckCircle2 className="w-3 h-3 text-white" />}
            </div>
            <span className={cn("text-xs leading-relaxed",
              checkedItems[i] ? "text-muted-foreground/35 line-through" : "text-foreground/75"
            )}>
              {item.label}
            </span>
          </button>
        ))}
      </div>
      <AnimatePresence>
        {checkedItems.every(Boolean) && (
          <motion.div
            initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.25 }}
            className="mt-3 overflow-hidden"
          >
            <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-center">
              <p className="text-xs text-emerald-400 font-medium">🎉 Toutes vos démarches sont complètes !</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  );
}
