import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import {
  Activity, CheckCircle2, AlertTriangle, Info,
  ArrowUpRight, RefreshCw,
} from "lucide-react";
import EmptyState from "@/components/EmptyState";
import { Zap } from "lucide-react";

interface ActivityItem {
  id: number;
  type: string;
  message: string;
  createdAt: string;
}

function relativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const min = Math.floor(diff / 60000);
  const hr = Math.floor(diff / 3600000);
  const day = Math.floor(diff / 86400000);
  if (min < 2) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  if (hr < 24) return `il y a ${hr}h`;
  if (day < 7) return `il y a ${day}j`;
  return new Date(dateStr).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

export default function ActivityTimeline({
  activity,
  isRunning,
}: {
  activity: ActivityItem[] | undefined;
  isRunning: boolean;
}) {
  return (
    <Card className="p-4 border border-card-border bg-card hover:border-primary/15 transition-all duration-200">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-muted-foreground" />
          <span className="font-semibold text-sm">Activité récente</span>
        </div>
        <Link href="/automations">
          <Button variant="ghost" size="icon" className="w-8 h-8">
            <ArrowUpRight className="w-3.5 h-3.5" />
          </Button>
        </Link>
      </div>
      {!activity || activity.length === 0 ? (
        <div className="py-5">
          <EmptyState
            icon={Activity}
            iconColor="text-muted-foreground/40"
            iconBg="bg-muted/30"
            iconBorder="border-border/30"
            title="Tout commence ici"
            description="Lancez votre première préparation. Serenya vous guidera étape par étape avec les vrais formulaires de chaque organisme."
            hint="Vous gardez le contrôle à chaque étape. Les actions sensibles demandent toujours votre confirmation."
            action={{ label: "Commencer", href: "/automations", icon: Zap }}
            className="py-8"
          />
        </div>
      ) : (
        <div className="relative">
          <div className="absolute left-[13px] top-2 bottom-2 w-px bg-border/50" />
          <div className="space-y-0">
            {activity.slice(0, 5).map((item, idx) => {
              const isOk = item.type === "automation_completed" || item.type === "service_connected";
              const isErr = item.type === "automation_failed";
              const isUpdate = item.type === "task_updated" || item.type === "address_added";
              const nextStep = isOk
                ? "Aucune action requise de votre part."
                : isErr
                ? "Consultez vos démarches — une action peut être nécessaire."
                : isUpdate
                ? "Serenya prépare vos démarches et vous guide."
                : "Serenya suit cette démarche pour vous.";
              return (
                <div key={item.id} className={cn("flex items-start gap-3 pb-3.5", idx === activity.slice(0, 5).length - 1 && "pb-0")}>
                  <div className="relative z-10 flex-shrink-0 mt-0.5">
                    <div className={cn(
                      "w-[27px] h-[27px] rounded-full flex items-center justify-center",
                      isOk ? "bg-emerald-500/10" : isErr ? "bg-amber-400/10" : "bg-blue-400/10"
                    )}>
                      {isOk ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
                        : isErr ? <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                        : <Info className="w-3.5 h-3.5 text-blue-400" />}
                    </div>
                  </div>
                  <div className="flex-1 min-w-0 pt-0.5">
                    <p className="text-xs leading-snug font-medium line-clamp-2">{item.message}</p>
                    <p className={cn("text-xs mt-0.5 leading-relaxed", isErr ? "text-amber-400/70" : "text-muted-foreground/50")}>
                      {nextStep}
                    </p>
                    <p className="text-xs text-muted-foreground/40 mt-0.5 tabular-nums">{relativeTime(item.createdAt)}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {isRunning && (
        <div className="mt-3 pt-3 border-t border-border/50 flex items-start gap-2">
          <RefreshCw className="w-3 h-3 text-blue-400/70 flex-shrink-0 mt-0.5 animate-spin" style={{ animationDuration: "3s" }} />
          <p className="text-xs text-muted-foreground/55 leading-relaxed">
            Certaines démarches peuvent prendre un peu plus de temps. Vous serez notifié des prochaines étapes.
          </p>
        </div>
      )}
    </Card>
  );
}
