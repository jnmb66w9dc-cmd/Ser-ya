import { motion } from "@/lib/motion-compat";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { cn } from "@/lib/utils";
import {
  Activity, AlertTriangle, CheckCircle2, ChevronRight,
  Loader2, Shield, ShieldCheck,
} from "lucide-react";

type AutoPriority = "action" | "running" | "done" | "idle";

function getAutoPriority(status: string, failed: number): AutoPriority {
  if (status === "partial" || failed > 0) return "action";
  if (status === "running" || status === "queued") return "running";
  if (status === "completed") return "done";
  return "idle";
}

function getAutoGuidance(status: string, failed: number): string {
  if (status === "partial" || failed > 0)
    return `${failed} organisme(s) demandent votre intervention. Consultez les détails.`;
  if (status === "running") return "Serenya prépare vos démarches — vous pourrez les valider ensuite.";
  if (status === "queued") return "En file d'attente — démarrage imminent.";
  if (status === "completed") return "Toutes vos démarches ont abouti. Aucune action requise.";
  if (status === "cancelled") return "Cette préparation a été annulée.";
  return "Serenya accompagne votre déménagement à chaque étape.";
}

function PriorityBadge({ priority }: { priority: AutoPriority }) {
  const cfg = {
    action:  { label: "Action requise", cls: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
    running: { label: "En cours",       cls: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
    done:    { label: "Terminé",        cls: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
    idle:    { label: "En attente",     cls: "bg-muted/60 text-muted-foreground border-border/50" },
  }[priority];
  return (
    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium flex-shrink-0", cfg.cls)}>
      {cfg.label}
    </span>
  );
}

interface Automation {
  id: number;
  status: string;
  addressLabel: string | null;
  failedServices: number;
  completedServices: number;
  totalServices: number;
  progressPercent: number;
}

export default function ControlCenter({ automations }: { automations: Automation[] }) {
  if (!automations || automations.length === 0) return null;

  const completedCount = automations.filter(a => a.status === "completed").length;
  const runningCount = automations.filter(a => a.status === "running" || a.status === "queued").length;
  const actionCount = automations.filter(a => a.status === "partial" || a.failedServices > 0).length;

  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.18 }}
    >
      <Card className="border border-card-border overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-border/40">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
              <Activity className="w-3.5 h-3.5 text-primary" />
            </div>
            <span className="font-semibold text-sm">Centre de démarches</span>
            {actionCount > 0 && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
                <AlertTriangle className="w-2.5 h-2.5" /> {actionCount} action(s) requise(s)
              </span>
            )}
          </div>
          <Link href="/automations">
            <Button variant="ghost" size="sm" className="h-8 text-xs text-muted-foreground gap-1 hover:text-foreground">
              Tout voir <ChevronRight className="w-3 h-3" />
            </Button>
          </Link>
        </div>

        {/* Status summary strip */}
        <div className="flex flex-wrap items-center gap-3 px-5 py-2.5 bg-muted/10 border-b border-border/25">
          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <CheckCircle2 className="w-3 h-3 text-emerald-500/70" />
            {completedCount} terminée(s)
          </span>
          <span className="text-muted-foreground/20">·</span>
          <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
            <Loader2 className={cn("w-3 h-3 text-blue-400", runningCount > 0 && "animate-spin")} />
            {runningCount} en cours
          </span>
          {actionCount > 0 ? (
            <>
              <span className="text-muted-foreground/20">·</span>
              <span className="inline-flex items-center gap-1.5 text-xs text-amber-400/80 font-medium">
                <AlertTriangle className="w-3 h-3" />
                {actionCount} nécessite votre attention
              </span>
            </>
          ) : (
            <>
              <span className="text-muted-foreground/20">·</span>
              <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground/50">
                <ShieldCheck className="w-3 h-3 text-emerald-500/50" />
                Aucune action requise
              </span>
            </>
          )}
        </div>

        {/* Automation rows */}
        {automations.slice(0, 3).map((auto) => {
          const priority = getAutoPriority(auto.status, auto.failedServices);
          const guidance = getAutoGuidance(auto.status, auto.failedServices);
          const borderCls = {
            action:  "border-l-amber-500/50",
            running: "border-l-blue-500/50",
            done:    "border-l-emerald-500/40",
            idle:    "border-l-border/30",
          }[priority];
          const barCls = {
            action:  "bg-amber-500",
            running: "bg-primary",
            done:    "bg-emerald-500",
            idle:    "bg-muted-foreground/30",
          }[priority];
          const hasAction = priority === "action";
          const isRunning = priority === "running";
          return (
            <Link key={auto.id} href="/automations">
              <div className={cn(
                "flex items-start gap-4 px-5 py-4 border-b border-border/25 last:border-0 border-l-2 hover:bg-muted/20 transition-colors cursor-pointer group",
                borderCls
              )}>
                <div className="flex-1 min-w-0 space-y-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold truncate">{auto.addressLabel ?? "Adresse"}</p>
                    <PriorityBadge priority={priority} />
                    {isRunning && (
                      <span className="inline-flex items-center gap-1 text-xs text-blue-400/60">
                        <Loader2 className="w-2.5 h-2.5 animate-spin" />
                        En traitement…
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{guidance}</p>
                  {hasAction && auto.failedServices > 0 && (
                    <p className="text-xs text-amber-400/70 font-medium">
                      → Ouvrez les détails pour voir les services concernés
                    </p>
                  )}
                  <div className="flex items-center gap-2 pt-0.5">
                    <div className="flex-1 h-1 bg-muted/60 rounded-full overflow-hidden">
                      <motion.div
                        className={cn("h-full rounded-full", barCls)}
                        initial={{ width: 0 }}
                        animate={{ width: `${auto.progressPercent}%` }}
                        transition={{ duration: 0.7, ease: "easeOut" }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground/50 tabular-nums flex-shrink-0">
                      {auto.completedServices}/{auto.totalServices}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-muted-foreground/30 flex-shrink-0 pt-0.5">
                  <ChevronRight className="w-4 h-4 group-hover:text-primary/50 transition-colors" />
                </div>
              </div>
            </Link>
          );
        })}

        {/* Footer trust line */}
        <div className="px-5 py-2.5 bg-muted/10 border-t border-border/25 flex items-center justify-between">
          <p className="text-xs text-muted-foreground/40 flex items-center gap-1.5">
            <Shield className="w-3 h-3" /> Vous gardez le contrôle · Aucune modification sans votre accord
          </p>
          <span className="text-xs text-muted-foreground/30 tabular-nums">
            {completedCount}/{automations.length} terminée(s)
          </span>
        </div>
      </Card>
    </motion.div>
  );
}
