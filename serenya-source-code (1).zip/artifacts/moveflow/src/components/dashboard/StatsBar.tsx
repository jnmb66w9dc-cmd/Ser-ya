import { motion } from "@/lib/motion-compat";
import { Card } from "@/components/ui/card";
import { useState, useEffect, useRef } from "react";

interface StatItem {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  rawValue: number | undefined;
  suffix: string;
  dot: string;
}

function AnimatedStat({ rawValue, suffix }: { rawValue: number | undefined; suffix: string }) {
  const [display, setDisplay] = useState<string>("—");
  const prevRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (rawValue === undefined) { setDisplay("—"); return; }
    const target = rawValue;
    const prev = prevRef.current ?? 0;
    prevRef.current = target;
    if (target === prev) { setDisplay(`${target}${suffix}`); return; }
    const start = Date.now();
    const dur = 700;
    const tick = () => {
      const t = Math.min(1, (Date.now() - start) / dur);
      const eased = 1 - (1 - t) * (1 - t);
      setDisplay(`${Math.round(prev + eased * (target - prev))}${suffix}`);
      if (t < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [rawValue, suffix]);

  return <p className="text-lg font-bold leading-none tabular-nums">{display}</p>;
}

export default function StatsBar({ stats }: { stats: StatItem[] }) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {stats.map((s, i) => (
        <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
          <Card className="p-4 border border-card-border hover:border-primary/20 hover:shadow-sm transition-all duration-200 group cursor-default">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-muted/60 flex items-center justify-center flex-shrink-0 group-hover:bg-primary/10 transition-colors duration-200">
                <s.icon className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors duration-200" />
              </div>
              <div>
                <AnimatedStat rawValue={s.rawValue} suffix={s.suffix} />
                <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
              </div>
            </div>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}
