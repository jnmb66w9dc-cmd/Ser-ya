import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@clerk/react";

/* ══════════════════════════════════════════════
   Types — match DB schema
   ══════════════════════════════════════════════ */

export type TaskCategory = "document" | "email" | "online" | "call" | "confirm" | "download";
export type TaskStatus = "pending" | "in_progress" | "completed" | "skipped";
export type TaskPriority = "low" | "medium" | "high";

export interface ApiUserTask {
  id: number;
  userId: string;
  title: string;
  description: string | null;
  category: TaskCategory;
  status: TaskStatus;
  priority: TaskPriority;
  orgName: string | null;
  automationId: number | null;
  completedAt: string | null;
  createdAt: string;
}

export interface CreateTaskInput {
  title: string;
  description?: string;
  category?: TaskCategory;
  priority?: TaskPriority;
  orgName?: string;
  automationId?: number;
}

/* ══════════════════════════════════════════════
   Helpers
   ══════════════════════════════════════════════ */

const TASKS_KEY = ["user-tasks"];

async function fetchJson<T>(url: string, init?: RequestInit): Promise<T> {
  const res = await fetch(url, { ...init, headers: { ...(init?.headers || {}), "Content-Type": "application/json" } });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

/* ══════════════════════════════════════════════
   Hook
   ══════════════════════════════════════════════ */

export function useUserTasks() {
  const { getToken } = useAuth();
  const queryClient = useQueryClient();

  const authInit = async (): Promise<RequestInit> => ({
    headers: { Authorization: `Bearer ${await getToken()}` },
  });

  const list = useQuery<ApiUserTask[]>({
    queryKey: TASKS_KEY,
    queryFn: async () => {
      const init = await authInit();
      return fetchJson<ApiUserTask[]>("/api/user-tasks", init);
    },
  });

  const create = useMutation<ApiUserTask, Error, CreateTaskInput>({
    mutationFn: async (input) => {
      const init = await authInit();
      return fetchJson<ApiUserTask>("/api/user-tasks", { ...init, method: "POST", body: JSON.stringify(input) });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: TASKS_KEY }),
  });

  const updateStatus = useMutation<ApiUserTask, Error, { id: number; status: TaskStatus }>({
    mutationFn: async ({ id, status }) => {
      const init = await authInit();
      return fetchJson<ApiUserTask>(`/api/user-tasks/${id}/status`, { ...init, method: "PATCH", body: JSON.stringify({ status }) });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: TASKS_KEY }),
  });

  const remove = useMutation<void, Error, number>({
    mutationFn: async (id) => {
      const init = await authInit();
      const res = await fetch(`/api/user-tasks/${id}`, { ...init, method: "DELETE" });
      if (!res.ok && res.status !== 204) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `HTTP ${res.status}`);
      }
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: TASKS_KEY }),
  });

  return { tasks: list.data ?? [], isLoading: list.isLoading, error: list.error, create, updateStatus, remove, refetch: list.refetch };
}

/* ══════════════════════════════════════════════
   Batch create (used by dashboard automation launch)
   ══════════════════════════════════════════════ */

export async function createTasksBatch(inputs: CreateTaskInput[]) {
  // Fire sequentially to avoid race conditions
  for (const input of inputs) {
    await new Promise<void>((resolve) => setTimeout(resolve, 30));
    await fetch("/api/user-tasks", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(input),
    });
  }
}
