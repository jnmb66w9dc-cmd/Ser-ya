import { useState, useEffect, useRef } from "react";

/**
 * Hook ligero para animaciones de scroll (remplace Framer Motion whileInView).
 * Utilise IntersectionObserver pour déclencher une classe CSS quand l'élément
 * entre dans le viewport. ~0.3KB vs 125KB de framer-motion.
 */
export function useScrollReveal<T extends HTMLElement>(options?: IntersectionObserverInit) {
  const ref = useRef<T>(null);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    // Si le navigateur ne supporte pas IO, on affiche tout de suite
    if (typeof IntersectionObserver === "undefined") {
      setRevealed(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1, rootMargin: "0px 0px -40px 0px", ...options }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [options?.threshold, options?.rootMargin]);

  return { ref, revealed };
}

/**
 * Variante avec un délai en cascade pour les listes d'éléments.
 */
export function useScrollRevealList<T extends HTMLElement>(count: number, options?: IntersectionObserverInit) {
  const ref = useRef<T>(null);
  const [revealed, setRevealed] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setRevealed(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true);
          observer.disconnect();
        }
      },
      { threshold: 0.05, rootMargin: "0px 0px -60px 0px", ...options }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [options?.threshold, options?.rootMargin]);

  return { ref, revealed, staggerDelay: (i: number) => revealed ? Math.min(i * 80, 600) : 0 };
}
