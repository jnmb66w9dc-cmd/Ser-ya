import { useUser } from "@clerk/react";
import { getAgentNameForUser } from "@/lib/agentNames";

/**
 * Returns the human-sounding agent name assigned to the current user.
 * Computed deterministically from the userId — same user always gets the same name.
 * Behind the scenes, it's always the same AI (Claude via Anthropic).
 */
export function useAgentName(): string {
  const { user } = useUser();
  if (!user?.id) return "Serenya";
  return getAgentNameForUser(user.id);
}

export const FALLBACK_AGENT_NAME = "Serenya";
