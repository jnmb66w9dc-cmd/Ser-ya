import { useEffect } from "react";

/**
 * useBeforeUnload — warns the user if they try to leave with unsaved changes.
 * Pass `hasUnsavedChanges: true` when there are pending edits.
 */
export function useBeforeUnload(hasUnsavedChanges: boolean) {
  useEffect(() => {
    if (!hasUnsavedChanges) return;

    const handler = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      // Modern browsers show a generic message; the string is only for legacy
      e.returnValue = "Vos modifications non sauvegardées seront perdues.";
      return "Vos modifications non sauvegardées seront perdues.";
    };

    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [hasUnsavedChanges]);
}
