import { useEffect } from "react";

/**
 * Lightweight analytics tracking.
 * Events are queued and sent in batches to avoid blocking the UI.
 * In production, replace the console with a real analytics provider
 * (PostHog, Plausible, Mixpanel, etc.)
 */

const EVENT_QUEUE: Array<{ event: string; props?: Record<string, unknown>; ts: number }> = [];
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function flush() {
  if (EVENT_QUEUE.length === 0) return;
  const batch = EVENT_QUEUE.splice(0, EVENT_QUEUE.length);

  // Send to analytics endpoint
  try {
    const blob = new Blob(
      [JSON.stringify({ events: batch })],
      { type: "application/json" }
    );
    navigator.sendBeacon("/api/analytics/events", blob);
  } catch {
    // Fallback: console log in dev
    if (import.meta.env.DEV) {
      // eslint-disable-next-line no-console
      console.log("[Analytics]", batch);
    }
  }
}

function scheduleFlush() {
  if (flushTimer) clearTimeout(flushTimer);
  flushTimer = setTimeout(flush, 5000);
}

export function track(event: string, props?: Record<string, unknown>) {
  EVENT_QUEUE.push({ event, props: props ?? {}, ts: Date.now() });
  scheduleFlush();
}

export function trackPageView(page: string) {
  track("page_view", { page });
}

export function trackSignup(method: "email" | "google" | "apple") {
  track("signup", { method });
}

export function trackAddressCreated() {
  track("address_created");
}

export function trackServiceConnected(serviceName: string) {
  track("service_connected", { service_name: serviceName });
}

export function trackAutomationLaunched(serviceCount: number) {
  track("automation_launched", { service_count: serviceCount });
}

export function trackUpgradeAttempt(plan: string) {
  track("upgrade_attempt", { plan });
}

export function trackDemoStarted() {
  track("demo_started");
}

export function trackFeedbackSent(type: string) {
  track("feedback_sent", { feedback_type: type });
}

/**
 * Hook: automatically track page views on mount
 */
export function usePageTracking(pageName: string) {
  useEffect(() => {
    trackPageView(pageName);
  }, [pageName]);
}
