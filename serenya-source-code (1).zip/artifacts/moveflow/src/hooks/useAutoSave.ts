import { useEffect, useRef, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

interface AutoSaveOptions {
  key: string;
  data: Record<string, unknown>;
  debounceMs?: number;
  onRestore?: (saved: Record<string, unknown>) => void;
  onCleared?: () => void;
}

/**
 * useAutoSave — persists form state to localStorage with debounce.
 * On mount, checks for saved draft and calls onRestore if found.
 * Call clearAutoSave(key) after successful submission.
 */
export function useAutoSave({ key, data, debounceMs = 500, onRestore, onCleared }: AutoSaveOptions) {
  const { toast } = useToast();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Save on data change (debounced)
  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      try {
        const json = JSON.stringify(data);
        localStorage.setItem(`serenya_draft_${key}`, json);
      } catch {
        // ignore quota errors
      }
    }, debounceMs);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [key, data, debounceMs]);

  // Check for saved draft on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(`serenya_draft_${key}`);
      if (!raw) return;
      const saved = JSON.parse(raw);
      // Only restore if there's meaningful data (not empty defaults)
      const hasData = Object.values(saved).some((v) => {
        if (typeof v === "string") return v.trim().length > 0;
        if (Array.isArray(v)) return v.length > 0;
        if (typeof v === "number") return v !== 0;
        return v !== null && v !== undefined;
      });
      if (hasData && onRestore) {
        onRestore(saved);
      }
    } catch {
      // ignore parse errors
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
}

export function clearAutoSave(key: string) {
  localStorage.removeItem(`serenya_draft_${key}`);
}

export function hasAutoSave(key: string): boolean {
  try {
    return localStorage.getItem(`serenya_draft_${key}`) !== null;
  } catch {
    return false;
  }
}
