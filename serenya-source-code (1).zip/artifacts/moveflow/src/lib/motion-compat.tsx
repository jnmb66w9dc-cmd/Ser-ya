/**
 * Wrapper compatible con Framer Motion que utiliza CSS nativo + IntersectionObserver.
 * Permite reemplazar framer-motion en páginas específicas para reducir el bundle
 * (~0.5KB vs 125KB de framer-motion).
 *
 * Soporta: motion.div/p/h2/span/section/button/li, AnimatePresence, variants,
 * initial/whileInView/animate/exit/viewport, staggerChildren (delay simple).
 */

import { useState, useEffect, useRef, type ReactNode, type HTMLAttributes } from "react";

/* ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────
   AnimatePresence — no-op wrapper (CSS handles transitions natively)
   ────────────────────────────────────────────────────────────────────────────────────────────────────────────────── */

export function AnimatePresence({ children, mode }: { children?: ReactNode; mode?: string }) {
  return <>{children}</>;
}

/* ───────────────────────────────────────────────────────────────────────────────────────────────────────────────────
   Motion wrapper — un componente por cada tag HTML soportado
   ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────── */

interface MotionProps extends Record<string, any> {
  initial?: Record<string, any> | string;
  animate?: Record<string, any> | string;
  whileInView?: Record<string, any> | string;
  exit?: Record<string, any>;
  variants?: Record<string, Record<string, any>>;
  viewport?: { once?: boolean; margin?: string };
  transition?: { duration?: number; delay?: number; type?: string; damping?: number; stiffness?: number; ease?: string };
  children?: ReactNode;
}

function useMotionReveal(elRef: React.RefObject<HTMLElement | null>, viewport?: { once?: boolean }) {
  const [revealed, setRevealed] = useState(false);
  useEffect(() => {
    const el = elRef.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setRevealed(true);
      return;
    }
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setRevealed(true);
          if (viewport?.once !== false) observer.disconnect();
        }
      },
      { threshold: 0.05, rootMargin: "0px 0px -40px 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, [viewport?.once]);
  return revealed;
}

function buildClasses(props: any, revealed: boolean): string {
  const base: string[] = [];
  // If whileInView or variants are present, start hidden
  const hasReveal = props.whileInView !== undefined || props.variants !== undefined;
  if (hasReveal) {
    base.push("reveal-up");
    if (revealed) base.push("revealed");
  } else if (props.initial) {
    // For direct initial/animate (not viewport-based), always show (CSS handles static)
    base.push("revealed");
  }
  // Apply stagger delay from transition prop
  const delay = props.transition?.delay;
  if (delay !== undefined) {
    // Map delay to nearest delay-N class
    const idx = Math.min(Math.round(delay / 0.08), 6);
    if (idx > 0) base.push(`delay-${idx}`);
  }
  // Merge with existing className
  if (props.className) base.push(props.className);
  return base.join(" ");
}

type IntrinsicTags = keyof import("react").JSX.IntrinsicElements;

function MotionTag<T extends IntrinsicTags>(
  tag: T
) {
  return function MotionComponent(props: any) {
    const ref = useRef<any>(null);
    const revealed = useMotionReveal(ref, props.viewport);
    const { initial, animate, whileInView, exit, variants, viewport, transition, className, ...rest } = props;
    const Tag = tag as any;
    return <Tag ref={ref} className={buildClasses(props, revealed)} {...rest} />;
  };
}

export const motion = {
  div: MotionTag("div"),
  span: MotionTag("span"),
  p: MotionTag("p"),
  h1: MotionTag("h1"),
  h2: MotionTag("h2"),
  h3: MotionTag("h3"),
  section: MotionTag("section"),
  button: MotionTag("button"),
  li: MotionTag("li"),
  form: MotionTag("form"),
  circle: MotionTag("circle"),
  svg: MotionTag("svg"),
} as const;
