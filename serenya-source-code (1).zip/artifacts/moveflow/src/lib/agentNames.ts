/**
 * Deterministic human agent name assignment (client-side mirror of server logic).
 * Every user gets a unique human-sounding name based on their userId.
 * The same user always sees the same name. Different users see different names.
 */

const AGENT_NAMES = [
  // French names
  "Claire", "Julie", "Camille", "Emma", "Manon", "Lucas", "Hugo", "Louis", "Léo", "Gabriel",
  "Thomas", "Nathan", "Mathis", "Maxime", "Chloé", "Sarah", "Laura", "Marie", "Jeanne", "Alice",
  "Jules", "Raphaël", "Ethan", "Maël", "Gabin", "Léna", "Jade", "Zoé", "Lina", "Mila",
  "Aaron", "Adam", "Nolan", "Timéo", "Théo", "Victor", "Noah", "Tom", "Sacha", "Simon",
  // Spanish/Latin names
  "María", "Lucía", "Elena", "Carmen", "Ana", "Isabel", "Paula", "Marta", "Sofía", "Valeria",
  "Marcos", "Diego", "Pablo", "Javier", "Antonio", "Carlos", "Miguel", "Álvaro", "Daniel", "David",
  "Sara", "Alba", "Claudia", "Irene", "Aitana", "Vega", "Martina", "Lola", "Candela", "Nora",
  "Bruno", "Héctor", "Iker", "Liam", "Mario", "Martín", "Sergio", "Adrián", "Alejandro", "Francisco",
];

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash);
}

export function getAgentNameForUser(userId: string): string {
  const hash = hashString(userId);
  return AGENT_NAMES[hash % AGENT_NAMES.length];
}

export const FALLBACK_AGENT_NAME = "Serenya";
