import AppLayout from "@/components/AppLayout";
import { MapPin, Plus, Star, Trash2, Edit2, Check, X, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle
} from "@/components/ui/alert-dialog";
import {
  useListAddresses,
  useCreateAddress,
  useUpdateAddress,
  useDeleteAddress,
  useSetDefaultAddress,
  getListAddressesQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { motion } from "@/lib/motion-compat";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import AddressAutocomplete from "@/components/AddressAutocomplete";
import { useAutoSave, clearAutoSave } from "@/hooks/useAutoSave";
import DraftRecoveryBanner from "@/components/DraftRecoveryBanner";

const addressSchema = z.object({
  label: z.string().min(1, "Requis"),
  street: z.string().min(1, "Requis"),
  complement: z.string().optional(),
  city: z.string().min(1, "Requis"),
  postalCode: z.string().min(1, "Requis").regex(/^\d{5}$/, "Le code postal doit contenir 5 chiffres"),
  country: z.string().default("France"),
});

type AddressForm = z.infer<typeof addressSchema>;

function AddressFormDialog({
  open, onClose, onSave, initial, loading
}: {
  open: boolean;
  onClose: () => void;
  onSave: (data: AddressForm) => void;
  initial?: Partial<AddressForm>;
  loading?: boolean;
}) {
  const { register, handleSubmit, formState: { errors }, reset, watch, setValue } = useForm<AddressForm>({
    resolver: zodResolver(addressSchema),
    defaultValues: { country: "France", ...initial },
  });

  const isNew = !initial?.street;
  const storageKey = isNew ? "address_new" : `address_edit_${initial?.street ?? ""}`;
  const formValues = watch();

  // Auto-save new address drafts
  useAutoSave({
    key: storageKey,
    data: formValues as Record<string, unknown>,
    onRestore: isNew ? (saved) => {
      if (saved.label) setValue("label", saved.label as string, { shouldValidate: true });
      if (saved.street) setValue("street", saved.street as string, { shouldValidate: true });
      if (saved.complement) setValue("complement", saved.complement as string);
      if (saved.postalCode) setValue("postalCode", saved.postalCode as string, { shouldValidate: true });
      if (saved.city) setValue("city", saved.city as string, { shouldValidate: true });
      if (saved.country) setValue("country", saved.country as string);
    } : undefined,
  });

  return (
    <Dialog open={open} onOpenChange={(v) => { if (!v) { onClose(); reset(); } }}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>{initial ? "Modifier l'adresse" : "Nouvelle adresse"}</DialogTitle>
          <DialogDescription>Renseignez les informations de votre adresse.</DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSave)} className="space-y-4">
          <div>
            <Label>Libellé</Label>
            <Input {...register("label")} placeholder="Ex: Domicile, Bureau..." className="mt-1" />
            {errors.label && <p className="text-xs text-destructive mt-1">{errors.label.message}</p>}
          </div>
          <div>
            <Label>Rue</Label>
            <AddressAutocomplete
              value={watch("street") || ""}
              onChange={(val) => setValue("street", val, { shouldValidate: true })}
              onSelect={(s) => {
                setValue("postalCode", s.postalCode, { shouldValidate: true });
                setValue("city", s.city, { shouldValidate: true });
              }}
              placeholder="12 rue de la Paix"
              disabled={loading}
            />
            {errors.street && <p className="text-xs text-destructive mt-1">{errors.street.message}</p>}
          </div>
          <div>
            <Label>Complément (optionnel)</Label>
            <Input {...register("complement")} placeholder="Appartement 4B..." className="mt-1" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Code postal</Label>
              <Input {...register("postalCode")} placeholder="75001" className="mt-1" />
              {errors.postalCode && <p className="text-xs text-destructive mt-1">{errors.postalCode.message}</p>}
            </div>
            <div>
              <Label>Ville</Label>
              <Input {...register("city")} placeholder="Paris" className="mt-1" />
              {errors.city && <p className="text-xs text-destructive mt-1">{errors.city.message}</p>}
            </div>
          </div>
          <div>
            <Label>Pays</Label>
            <Input {...register("country")} placeholder="France" className="mt-1" />
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" className="flex-1" onClick={() => { onClose(); reset(); }}>
              Annuler
            </Button>
            <Button type="submit" className="flex-1" disabled={loading}>
              {loading ? "Enregistrement..." : "Enregistrer"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}

export default function AddressesPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [addOpen, setAddOpen] = useState(false);
  const [editAddress, setEditAddress] = useState<any | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const { data: addresses, isLoading, isError } = useListAddresses();
  const create = useCreateAddress();
  const update = useUpdateAddress();
  const remove = useDeleteAddress();
  const setDefault = useSetDefaultAddress();

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListAddressesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  return (
    <AppLayout title="Mes adresses">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-4xl mx-auto space-y-6">
        <DraftRecoveryBanner
          storageKey="address_new"
          onRestore={() => setAddOpen(true)}
          label="votre nouvelle adresse"
        />
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Adresses</h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {addresses?.length ?? 0} adresse(s) enregistrée(s)
            </p>
          </div>
          <Button onClick={() => setAddOpen(true)} className="gap-2">
            <Plus className="w-4 h-4" /> Nouvelle adresse
          </Button>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[...Array(2)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
          </div>
        ) : isError ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="py-14 text-center rounded-2xl border border-dashed border-amber-500/20 bg-amber-500/5"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-4 h-4 text-amber-400/70" />
            </div>
            <p className="text-sm font-medium text-foreground/80">Impossible de charger vos adresses</p>
            <p className="text-xs text-muted-foreground mt-1.5 max-w-xs mx-auto leading-relaxed">
              Un petit souci technique de notre côté. Vos données sont en sécurité — réessayez dans un instant.
            </p>
          </motion.div>
        ) : !addresses || addresses.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className="py-16 text-center border border-dashed border-border/50 rounded-2xl bg-muted/[0.03]"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 300, damping: 20 }}
              className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-4"
            >
              <MapPin className="w-6 h-6 text-primary/60" />
            </motion.div>
            <h3 className="font-semibold text-base mb-1.5 text-foreground/90">Votre adresse, le point de départ</h3>
            <p className="text-sm text-muted-foreground max-w-sm mx-auto mb-1 leading-relaxed">
              Ajoutez votre nouvelle adresse — Serenya s'occupera de tout mettre à jour auprès de vos organismes.
            </p>
            <p className="text-xs text-muted-foreground/50 max-w-xs mx-auto mb-5 leading-relaxed">
              Banques, assurances, opérateurs... une seule saisie suffit pour lancer toutes vos démarches.
            </p>
            <Button
              onClick={() => setAddOpen(true)}
              className="gap-2 transition-all duration-200 hover:shadow-sm"
            >
              <Plus className="w-4 h-4" /> Ajouter ma première adresse
            </Button>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {addresses.map((a, i) => (
              <motion.div key={a.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
                <Card className={cn(
                  "p-5 border transition-all duration-200 hover:shadow-sm hover:border-border/80",
                  a.isDefault ? "border-primary/40 bg-primary/[0.02]" : "border-card-border hover:bg-muted/[0.02]"
                )}>
                  <div className="flex items-start gap-4">
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0",
                      a.isDefault ? "bg-primary/15" : "bg-muted"
                    )}>
                      <MapPin className={cn("w-5 h-5", a.isDefault ? "text-primary" : "text-muted-foreground")} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <h3 className="font-semibold">{a.label}</h3>
                        {a.isDefault && (
                          <Badge className="text-xs bg-primary/10 text-primary border-primary/20">
                            <Star className="w-2.5 h-2.5 mr-1" /> Par défaut
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {a.street}{a.complement ? `, ${a.complement}` : ""}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {a.postalCode} {a.city}, {a.country}
                      </p>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      {!a.isDefault && (
                        <Button
                          variant="ghost"
                          size="icon"
                          className="w-8 h-8 text-muted-foreground hover:text-primary"
                          title="Définir par défaut"
                          onClick={() => setDefault.mutate({ id: a.id }, { onSuccess: () => { invalidate(); toast({ title: "Adresse principale mise à jour" }); }})}
                        >
                          <Star className="w-3.5 h-3.5" />
                        </Button>
                      )}
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 text-muted-foreground hover:text-foreground"
                        onClick={() => setEditAddress(a)}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        onClick={() => setDeleteId(a.id)}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        )}

        {/* Add dialog */}
        <AddressFormDialog
          open={addOpen}
          onClose={() => setAddOpen(false)}
          loading={create.isPending}
          onSave={(data) =>
            create.mutate(
              { data },
              {
                onSuccess: () => {
                  setAddOpen(false);
                  invalidate();
                  toast({ title: "Adresse ajoutée", description: "Elle est prête à être utilisée pour vos démarches." });
                },
                onError: (err: any) => {
                  const msg = err?.response?.data?.error ?? err?.message ?? "Impossible d'ajouter l'adresse.";
                  toast({ title: "Adresse invalide", description: msg, variant: "destructive" });
                },
              }
            )
          }
        />

        {/* Edit dialog */}
        <AddressFormDialog
          open={!!editAddress}
          onClose={() => setEditAddress(null)}
          initial={editAddress ?? undefined}
          loading={update.isPending}
          onSave={(data) =>
            update.mutate(
              { id: editAddress!.id, data },
              {
                onSuccess: () => {
                  setEditAddress(null);
                  invalidate();
                  toast({ title: "Adresse mise à jour" });
                },
                onError: (err: any) => {
                  const msg = err?.response?.data?.error ?? err?.message ?? "Impossible de mettre à jour l'adresse.";
                  toast({ title: "Erreur de mise à jour", description: msg, variant: "destructive" });
                },
              }
            )
          }
        />

        {/* Delete dialog */}
        <AlertDialog open={deleteId !== null} onOpenChange={(v) => !v && setDeleteId(null)}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Supprimer cette adresse ?</AlertDialogTitle>
              <AlertDialogDescription>
                Cette action est irréversible. L'adresse sera supprimée définitivement.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Annuler</AlertDialogCancel>
              <AlertDialogAction
                className="bg-destructive hover:bg-destructive/90 text-white"
                onClick={() =>
                  remove.mutate(
                    { id: deleteId! },
                    {
                      onSuccess: () => { setDeleteId(null); invalidate(); toast({ title: "Adresse supprimée", description: "Vous pouvez en ajouter une nouvelle à tout moment." }); },
                      onError: (err: any) => {
                        const msg = err?.response?.data?.error ?? err?.message ?? "Impossible de supprimer l'adresse.";
                        toast({ title: "Erreur de suppression", description: msg, variant: "destructive" });
                      },
                    }
                  )
                }
              >
                Supprimer
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </AppLayout>
  );
}
