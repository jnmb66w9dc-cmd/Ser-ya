import AppLayout from "@/components/AppLayout";
import { Building2, Plus, Trash2, CheckCircle2, AlertCircle, Clock, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  useListServices,
  useListUserServices,
  useConnectService,
  useDisconnectService,
  getListUserServicesQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { motion } from "@/lib/motion-compat";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

const statusConfig = {
  connected: { label: "À préparer", icon: CheckCircle2, color: "text-green-500", bg: "bg-green-500/10" },
  pending: { label: "En attente", icon: Clock, color: "text-yellow-500", bg: "bg-yellow-500/10" },
  error: { label: "Erreur", icon: AlertCircle, color: "text-red-500", bg: "bg-red-500/10" },
  updating: { label: "Mise à jour", icon: Clock, color: "text-blue-500", bg: "bg-blue-500/10" },
};

const categoryColors: Record<string, string> = {
  banque: "bg-blue-500/10 text-blue-500 border-blue-500/20",
  assurance: "bg-purple-500/10 text-purple-500 border-purple-500/20",
  telecom: "bg-orange-500/10 text-orange-500 border-orange-500/20",
  energie: "bg-yellow-500/10 text-yellow-500 border-yellow-500/20",
  "e-commerce": "bg-green-500/10 text-green-500 border-green-500/20",
  administration: "bg-gray-500/10 text-gray-500 border-gray-500/20",
  abonnement: "bg-pink-500/10 text-pink-500 border-pink-500/20",
  finance: "bg-teal-500/10 text-teal-500 border-teal-500/20",
};

const serviceEmoji: Record<string, string> = {
  "Amazon":            "🛒",
  "EDF":               "⚡",
  "Orange":            "📱",
  "PayPal":            "💳",
  "Free":              "📡",
  "BNP Paribas":       "🏦",
  "AXA":               "🛡️",
  "Société Générale":  "🏛️",
  "MAIF":              "🚗",
  "La Poste":          "📮",
  "Netflix":           "🎬",
  "Spotify":           "🎵",
  "SNCF":              "🚄",
  "Engie":             "🔥",
  "Crédit Agricole":   "🌾",
  "Caisse d'Épargne":  "🏦",
  "LCL":               "🏦",
  "SFR":               "📶",
  "Bouygues Telecom":  "📞",
  "Impôts":            "🏛️",
  "CAF":               "👨‍👩‍👧",
  "Cpam":              "💊",
  "Pôle Emploi":       "💼",
  "Banque Postale":    "📬",
};

const serviceColors: Record<string, string> = {
  "Amazon": "bg-orange-500",
  "EDF": "bg-blue-600",
  "Orange": "bg-orange-400",
  "PayPal": "bg-blue-500",
  "Free": "bg-red-500",
  "BNP Paribas": "bg-green-700",
  "AXA": "bg-blue-700",
  "Société Générale": "bg-red-600",
  "MAIF": "bg-green-600",
  "La Poste": "bg-yellow-600",
  "Netflix": "bg-red-600",
  "Spotify": "bg-green-500",
};

function getServiceColor(name: string) {
  return serviceColors[name] ?? "bg-primary";
}

function ServiceIcon({ name }: { name: string }) {
  const emoji = serviceEmoji[name];
  if (emoji) {
    return (
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-lg flex-shrink-0 bg-muted/60 border border-border/40`}>
        {emoji}
      </div>
    );
  }
  return (
    <div className={`w-9 h-9 rounded-lg flex items-center justify-center text-white font-bold text-sm flex-shrink-0 ${getServiceColor(name)}`}>
      {name[0]}
    </div>
  );
}

export default function ServicesPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [search, setSearch] = useState("");

  const { data: services, isLoading: loadingServices, isError: servicesError } = useListServices();
  const { data: userServices, isLoading: loadingUser, isError: userServicesError } = useListUserServices();
  const connect = useConnectService();
  const disconnect = useDisconnectService();

  const connectedServiceIds = new Set(userServices?.map((s) => s.serviceId) ?? []);

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListUserServicesQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  const filteredServices = services?.filter((s) =>
    s.name.toLowerCase().includes(search.toLowerCase()) ||
    s.category.toLowerCase().includes(search.toLowerCase())
  ) ?? [];

  const categories = [...new Set(services?.map((s) => s.category) ?? [])];

  return (
    <AppLayout title="Services connectés">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-6xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Services</h2>
            <p className="text-sm text-muted-foreground mt-0.5">
              {userServices?.length ?? 0} connecté(s) sur {services?.length ?? 0} disponibles
            </p>
          </div>
          {services && services.length > 0 && (
            <div className="hidden sm:flex items-center gap-3">
              <div className="text-right">
                <p className="text-xs text-muted-foreground/60 mb-1">Couverture</p>
                <p className="text-sm font-semibold tabular-nums">
                  {Math.round(((userServices?.length ?? 0) / services.length) * 100)}%
                </p>
              </div>
              <div className="w-24 h-2 bg-muted rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-primary rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${Math.round(((userServices?.length ?? 0) / services.length) * 100)}%` }}
                  transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                />
              </div>
            </div>
          )}
        </div>

        <Tabs defaultValue="all">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3">
            <TabsList>
              <TabsTrigger value="all">Tous</TabsTrigger>
              <TabsTrigger value="connected">
                Connectés
                {userServices && userServices.length > 0 && (
                  <Badge className="ml-1.5 text-xs" variant="secondary">{userServices.length}</Badge>
                )}
              </TabsTrigger>
            </TabsList>
            <div className="relative sm:ml-auto sm:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher un service..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          {/* All services */}
          <TabsContent value="all" className="mt-4">
            {loadingServices ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(6)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
              </div>
            ) : servicesError || userServicesError ? (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                className="py-14 text-center rounded-2xl border border-dashed border-amber-500/20 bg-amber-500/5"
              >
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3">
                  <AlertCircle className="w-4 h-4 text-amber-400/70" />
                </div>
                <p className="text-sm font-medium text-foreground/80">Impossible de charger les services</p>
                <p className="text-xs text-muted-foreground mt-1.5 max-w-xs mx-auto leading-relaxed">
                  Un petit souci technique de notre côté. Réessayez dans un instant — vos données sont en sécurité.
                </p>
              </motion.div>
            ) : (
              <div className="space-y-6">
                {categories.map((cat) => {
                  const catServices = filteredServices.filter((s) => s.category === cat);
                  if (catServices.length === 0) return null;
                  return (
                    <div key={cat}>
                      <div className="flex items-center gap-2 mb-3">
                        <Badge variant="outline" className={cn("text-xs capitalize", categoryColors[cat])}>
                          {cat}
                        </Badge>
                        <span className="text-xs text-muted-foreground">{catServices.length} service(s)</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                        {catServices.map((service, i) => {
                          const isConnected = connectedServiceIds.has(service.id);
                          const userService = userServices?.find((us) => us.serviceId === service.id);
                          return (
                            <motion.div
                              key={service.id}
                              initial={{ opacity: 0, y: 12 }}
                              animate={{ opacity: 1, y: 0 }}
                              transition={{ delay: i * 0.05 }}
                            >
                              <Card className={cn(
                                "p-4 border transition-all duration-200 hover:shadow-sm",
                                isConnected ? "border-primary/30 bg-primary/[0.02] hover:border-primary/40" : "border-card-border hover:border-border/80 hover:bg-muted/[0.02]"
                              )}>
                                <div className="flex items-start gap-3">
                                  <ServiceIcon name={service.name} />
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 mb-0.5">
                                      <p className="font-semibold text-sm truncate">{service.name}</p>
                                      {isConnected && <CheckCircle2 className="w-3.5 h-3.5 text-green-500 flex-shrink-0" />}
                                    </div>
                                    <p className="text-xs text-muted-foreground line-clamp-2 mb-2">{service.description}</p>
                                    {isConnected ? (
                                      <Button
                                        variant="outline"
                                        size="sm"
                                        className="h-9 text-xs gap-1 text-destructive hover:text-destructive border-destructive/30 hover:bg-destructive/5"
                                        disabled={disconnect.isPending}
                                        onClick={() =>
                                          disconnect.mutate(
                                            { id: userService!.id },
                                            {
                                              onSuccess: () => {
                                                invalidate();
                                                toast({ title: `${service.name} déconnecté`, description: "Vous pouvez le reconnecter à tout moment depuis cette page." });
                                              },
                                            }
                                          )
                                        }
                                      >
                                        <Trash2 className="w-3 h-3" /> Déconnecter
                                      </Button>
                                    ) : (
                                      <Button
                                        size="sm"
                                        className="h-9 text-xs gap-1"
                                        disabled={connect.isPending}
                                        onClick={() =>
                                          connect.mutate(
                                            { data: { serviceId: service.id } },
                                            {
                                              onSuccess: () => {
                                                invalidate();
                                                toast({ title: `${service.name} ajouté`, description: "Serenya préparera les démarches pour cet organisme. Vous validerez chaque étape." });
                                              },
                                            }
                                          )
                                        }
                                      >
                                        <Plus className="w-3 h-3" /> Connecter
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </Card>
                            </motion.div>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
                {filteredServices.length === 0 && (
                  <div className="py-16 text-center">
                    <div className="w-14 h-14 rounded-2xl bg-muted/30 border border-border/30 flex items-center justify-center mx-auto mb-4">
                      <Search className="w-6 h-6 text-muted-foreground/40" />
                    </div>
                    <h3 className="font-semibold text-base mb-1.5 text-foreground/80">
                      Aucun résultat pour &ldquo;{search}&rdquo;
                    </h3>
                    <p className="text-sm text-muted-foreground max-w-xs mx-auto">
                      Essayez un autre mot-clé, ou consultez la liste complète des services disponibles.
                    </p>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* Connected services */}
          <TabsContent value="connected" className="mt-4">
            {loadingUser ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-28 rounded-xl" />)}
              </div>
            ) : !userServices || userServices.length === 0 ? (
              <motion.div
                initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                className="py-16 text-center border border-dashed border-border/50 rounded-2xl bg-muted/[0.03]"
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  transition={{ delay: 0.1, type: "spring", stiffness: 300, damping: 20 }}
                  className="w-14 h-14 rounded-2xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mx-auto mb-4"
                >
                  <Building2 className="w-6 h-6 text-violet-400/70" />
                </motion.div>
                <h3 className="font-semibold text-base mb-1.5 text-foreground/90">Vos services, vos interlocuteurs</h3>
                <p className="text-sm text-muted-foreground max-w-sm mx-auto mb-1">
                  Sélectionnez les organismes à mettre à jour. Serenya préparera les démarches et vous guidera étape par étape.
                </p>
                <p className="text-xs text-muted-foreground/50 max-w-xs mx-auto mb-5">
                  Une seule sélection suffit. Vous pourrez lancer vos démarches depuis le tableau de bord.
                </p>
                <Button
                  variant="outline"
                  className="gap-2 transition-all duration-200 hover:shadow-sm"
                  onClick={() => {
                    const tab = document.querySelector('[data-value="all"]') as HTMLElement;
                    tab?.click();
                  }}
                >
                  <Plus className="w-4 h-4" /> Parcourir les services
                </Button>
              </motion.div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {userServices.map((us, i) => {
                  const status = statusConfig[us.status as keyof typeof statusConfig] ?? statusConfig.connected;
                  return (
                    <motion.div key={us.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.06 }}>
                      <Card className="p-4 border border-primary/20 bg-primary/[0.02] transition-all duration-200 hover:shadow-sm hover:border-primary/30">
                        <div className="flex items-start gap-3">
                          <ServiceIcon name={us.serviceName} />
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-sm">{us.serviceName}</p>
                            <div className={cn("flex items-center gap-1 mt-1 text-xs", status.color)}>
                              <status.icon className="w-3 h-3" />
                              {status.label}
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              Connecté le {new Date(us.connectedAt).toLocaleDateString("fr-FR")}
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                            onClick={() => disconnect.mutate({ id: us.id }, { onSuccess: () => { invalidate(); toast({ title: `${us.serviceName} déconnecté`, description: "Vous pouvez le reconnecter à tout moment." }); }})}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </Button>
                        </div>
                      </Card>
                    </motion.div>
                  );
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
