import AppLayout from "@/components/AppLayout";
import AutomationDebrief from "@/components/AutomationDebrief";
import {
  Zap, CheckCircle2, XCircle, Clock, AlertTriangle, ChevronDown, ChevronUp, Ban,
  Shield, ChevronRight, X, Copy, ExternalLink, Download, FileText,
  MessageSquare, CheckCheck, HelpCircle, Sparkles, ArrowRight, Lock,
  Info, ListChecks, Eye, SendHorizonal, Share2, Link as LinkIcon, Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import {
  useListAutomations, useListAutomationTasks, useCancelAutomation,
  useCreateShareLink, useDeleteShareLink, useRetryAutomationTask,
  getListAutomationsQueryKey, getGetDashboardSummaryQueryKey, getListAutomationTasksQueryKey,
} from "@workspace/api-client-react";
import type { AutomationTaskStepData } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import confetti from "canvas-confetti";
import { generateTasksFromProfile, saveTasks } from "@/components/TaskCenter";
import type { AdminTask } from "@/components/TaskCenter";
import { getProfile, ORG_COLORS, getConfidencePct } from "@/components/automations/OrgProfiles";
import { ServiceAvatar } from "@/components/automations/ServiceAvatar";
import { StatusPill, AUTO_STATUS_CFG, STATUS_CFG } from "@/components/automations/StatusPill";
import ServiceTrackingTimeline from "@/components/tracking/ServiceTrackingTimeline";
  

/* ══════════════════════════════════════════════
/* ORG_PROFILES, getProfile, OrgProfile imported from @/components/automations/OrgProfiles */

/* ══════════════════════════════════════════════
   UI HELPERS
══════════════════════════════════════════════ */

/* ORG_COLORS, getConfidencePct imported */
/* ServiceAvatar imported */

const SENSITIVE_ORGS: Record<string, {
    category: string; verificationReason: string; reassurance: string[];
  }> = {
    "BNP Paribas": {
      category: "Établissement bancaire",
      verificationReason: "Les banques sont soumises à des obligations réglementaires strictes (LCB-FT, KYC) qui exigent votre présence directe pour toute modification de données personnelles. C'est une protection légale pour vous.",
      reassurance: [
        "Votre RIB et vos comptes restent entièrement inchangés",
        "Votre historique de transactions n'est pas affecté",
        "Aucune opération bancaire ne peut être effectuée sans vous",
      ],
    },
    "AXA": {
      category: "Assureur",
      verificationReason: "Les assureurs sont tenus de vérifier votre identité avant toute modification de contrat. C'est une protection légale qui garantit que personne ne peut modifier vos données à votre insu.",
      reassurance: [
        "Vos contrats et garanties restent identiques",
        "L'adresse est mise à jour sans résiliation ni changement de tarif",
        "Aucune couverture n'est interrompue pendant la démarche",
      ],
    },
    "MAIF": {
      category: "Assureur mutualiste",
      verificationReason: "La MAIF vérifie votre identité pour toute modification de contrat. Cette étape, obligatoire pour les mutuelles, garantit la sécurité de votre couverture et de vos données.",
      reassurance: [
        "Vos garanties et cotisations ne changent pas",
        "Seule l'adresse de correspondance est mise à jour",
        "Vous recevez une confirmation par courrier",
      ],
    },
    "CPAM": {
      category: "Organisme de santé publique",
      verificationReason: "La CPAM est un organisme de sécurité sociale. Toute modification passe obligatoirement par votre espace ameli.fr sécurisé. Un justificatif de domicile peut être demandé.",
      reassurance: [
        "Votre Carte Vitale reste valide et inchangée",
        "Vos remboursements continuent normalement",
        "La modification n'affecte ni vos droits ni votre médecin traitant",
      ],
    },
    "CAF": {
      category: "Organisme social",
      verificationReason: "La CAF doit être notifiée légalement dans les 30 jours suivant tout déménagement. Un retard pourrait affecter le versement de vos prestations.",
      reassurance: [
        "Vos allocations continuent sans interruption pendant la démarche",
        "La loi vous accorde 30 jours pour notifier la CAF",
        "Une pièce justificative de domicile peut être demandée",
      ],
    },
    "Société Générale": {
      category: "Établissement bancaire",
      verificationReason: "Société Générale, comme toutes les banques françaises, est soumise à des obligations strictes (LCB-FT, KYC) qui exigent votre présence directe pour toute modification de données personnelles.",
      reassurance: [
        "Vos comptes et votre RIB restent entièrement inchangés",
        "Aucune opération bancaire ne peut être effectuée sans vous",
        "Votre historique de transactions n'est pas affecté",
      ],
    },
    "Crédit Agricole": {
      category: "Établissement bancaire",
      verificationReason: "Le Crédit Agricole est soumis aux mêmes obligations réglementaires que toutes les banques. Votre connexion directe est requise pour protéger vos données bancaires.",
      reassurance: [
        "Vos comptes et assurances restent identiques",
        "Votre conseiller peut vous contacter pour confirmation",
        "Aucune donnée bancaire n'est modifiée sans vous",
      ],
    },
    "Banque Postale": {
      category: "Établissement bancaire",
      verificationReason: "La Banque Postale, en tant qu'établissement bancaire, impose une vérification d'identité stricte conforme à la réglementation LCB-FT.",
      reassurance: [
        "Vos comptes et votre Livret A restent inchangés",
        "Votre conseiller reste le même",
        "Aucune opération bancaire ne peut être effectuée sans vous",
      ],
    },
    "Caisse d'Épargne": {
      category: "Établissement bancaire",
      verificationReason: "La Caisse d'Épargne est soumise aux mêmes obligations réglementaires que toutes les banques. Votre présence directe est requise pour toute modification de données personnelles.",
      reassurance: [
        "Vos livrets et assurances restent inchangés",
        "Votre conseiller est informé de la démarche",
        "Aucune opération bancaire n'est possible sans vous",
      ],
    },
    "LCL": {
      category: "Établissement bancaire",
      verificationReason: "LCL, en tant qu'établissement bancaire, est soumis aux obligations LCB-FT et KYC qui imposent une vérification stricte de l'identité pour toute modification de données.",
      reassurance: [
        "Vos comptes et votre RIB restent entièrement inchangés",
        "Votre conseiller reste le même",
        "Aucune opération bancaire ne peut être effectuée sans vous",
      ],
    },
  };

/* STATUS_CFG, AUTO_STATUS_CFG, StatusPill imported */
/* TASK DETAIL PANEL */

interface TaskItem {
  id: number;
  serviceName: string;
  status: string;
  errorMessage?: string | null;
  stepData?: AutomationTaskStepData;
  createdAt: string;
}

function TaskDetailPanel({ task, addressLabel, onClose, onRetry }: {
  task: TaskItem; addressLabel: string; onClose: () => void; onRetry?: () => void;
}) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);
  const [checklist, setChecklist] = useState<boolean[]>([]);

  const profile = getProfile(task.serviceName);
  const isDone   = task.status === "completed";
  const isFailed = task.status === "failed";

  const emailContent = profile.emailTemplate
    ? profile.emailTemplate(addressLabel || "12 rue de la Paix, 75001 Paris, France")
    : null;

  // Initialize checklist once
  const checkItems = profile.checklistItems ?? [];
  const checks = checklist.length === checkItems.length ? checklist : checkItems.map(i => i.done);

  function handleCopy() {
    if (emailContent) {
      navigator.clipboard.writeText(emailContent).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 3000);
        toast({ title: "Email copié !", description: "Collez-le dans votre messagerie." });
      });
    }
  }

  // Build real steps from knowledge base stepData, or fallback to generic timeline
  const sd = task.stepData as any;
  const kbSteps = sd?.steps ?? [];
  const kbDocs = sd?.documentsNeeded ?? [];
  const kbUrl  = sd?.url ?? "";
  const kbDiff = sd?.difficulty ?? "moyen";
  const kbTime = sd?.estimatedTime ?? profile.processingTime;

  const diffEmoji = kbDiff === "facile" ? "🟢" : kbDiff === "moyen" ? "🟡" : "🔴";
  const diffLabel = kbDiff === "facile" ? "Facile" : kbDiff === "moyen" ? "Modéré" : "Complexe";

  const timelineSteps = kbSteps.length > 0
    ? kbSteps.map((s: any, i: number) => ({
        label: `${s.message}`,
        done: isDone || (isFailed && i < kbSteps.length - 1),
        active: !isDone && !isFailed && i === Math.floor(kbSteps.length / 2),
        type: s.type,
      }))
    : [
        { label: "Préparation par Serenya",             done: true,   active: false, type: "info" },
        { label: "Action de votre part",                done: isDone, active: !isDone && !isFailed, type: "action" },
        { label: `Traitement par ${task.serviceName}`,  done: isDone, active: false, type: "info" },
        { label: "Confirmation et clôture",             done: isDone, active: false, type: "success" },
      ];

  return (
    <>
      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
        className="fixed inset-0 z-40 bg-black/55 backdrop-blur-[3px]" onClick={onClose} />

      <motion.div
        initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 30, stiffness: 260 }}
        className="fixed right-0 top-0 bottom-0 z-50 w-full sm:w-[480px] bg-background border-l border-border/50 shadow-2xl flex flex-col"
      >
        {/* ── Header ── */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-border/40 flex-shrink-0">
          <ServiceAvatar name={task.serviceName} size="md" />
          <div className="flex-1 min-w-0">
            <h2 className="font-bold text-base leading-tight">{task.serviceName}</h2>
            <p className="text-xs text-muted-foreground mt-0.5">
              {profile.assistanceLabel} · {profile.processingTime}
            </p>
          </div>
          <StatusPill status={task.status} />
          <button onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors ml-1 flex-shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ── Trust strip ── */}
        <div className="flex items-center gap-3 px-5 py-2 bg-muted/10 border-b border-border/25 flex-shrink-0">
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground/45">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block flex-shrink-0" />
            Connexion sécurisée
          </div>
          <span className="text-border/50">·</span>
          <span className="text-xs text-muted-foreground/35">TLS 1.3 · AES-256</span>
          <span className="text-border/50">·</span>
          <span className="text-xs text-muted-foreground/35 flex items-center gap-1">
            <Shield className="w-2.5 h-2.5" /> RGPD
          </span>
          <span className="ml-auto text-xs text-muted-foreground/30 flex items-center gap-1">
            <Lock className="w-2.5 h-2.5" /> Données chiffrées
          </span>
        </div>

        {/* ── Scrollable content ── */}
        <div className="flex-1 overflow-y-auto">
          <div className="p-5 space-y-4">

            {/* Status banner */}
            {isDone ? (
              <div className="rounded-xl bg-emerald-500/10 border border-emerald-500/20 p-4 flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-emerald-300">Démarche préparée ✓</p>
                  <p className="text-xs text-emerald-400/70 mt-0.5">
                    Serenya a préparé les étapes pour {task.serviceName}. Connectez-vous sur le site officiel pour finaliser. Délai : {profile.processingTime}.
                  </p>
                </div>
              </div>
            ) : isFailed ? (
              <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-4 flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-amber-300">Une action de votre part est nécessaire</p>
                  <p className="text-xs text-amber-400/70 mt-1 leading-relaxed">
                    {task.errorMessage ?? "Certaines organisations demandent une validation supplémentaire de votre part. C'est normal et courant."}
                  </p>
                </div>
              </div>
            ) : (
              <div className="rounded-xl bg-primary/8 border border-primary/15 p-4 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-primary/80 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold">
                    {profile.mode === "prefill"  ? "Formulaire prêt — il ne vous reste qu'à confirmer." :
                     profile.mode === "redirect" ? "Guide prêt — connectez-vous pour finaliser." :
                     profile.mode === "prepared" ? "Email prêt — copiez et envoyez en 30 secondes." :
                     "Instructions préparées — suivez la checklist."}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">Délai estimé : {profile.processingTime}</p>
                </div>
              </div>
            )}

            {/* ── Verification context for sensitive orgs ── */}
            {SENSITIVE_ORGS[task.serviceName] && !isDone && (
              <div className="rounded-xl border border-blue-500/20 overflow-hidden">
                <div className="flex items-center gap-2.5 px-4 py-2.5 bg-blue-500/8 border-b border-blue-500/15">
                  <Lock className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />
                  <span className="text-xs font-semibold text-blue-300">Vérification d'identité requise</span>
                  <span className="ml-auto text-xs text-muted-foreground/50 bg-muted/40 px-2 py-0.5 rounded-full">
                    {SENSITIVE_ORGS[task.serviceName].category}
                  </span>
                </div>
                <div className="p-4 space-y-3 bg-blue-500/3">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {SENSITIVE_ORGS[task.serviceName].verificationReason}
                  </p>
                  <div className="space-y-2">
                    {SENSITIVE_ORGS[task.serviceName].reassurance.map((item: string) => (
                      <div key={item} className="flex items-start gap-2 text-xs text-foreground/75">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
                <div className="px-4 py-2.5 bg-muted/20 border-t border-border/30">
                  <p className="text-xs text-muted-foreground/50 flex items-center gap-1.5">
                    <Info className="w-3 h-3" />
                    Certaines organisations demandent une confirmation supplémentaire pour protéger vos données.
                    <span className="font-medium text-muted-foreground/60">C'est normal.</span>
                  </p>
                </div>
              </div>
            )}

            {/* Assistance card */}
            <div className={cn("rounded-xl border p-4 space-y-3", profile.modeBg)}>
              <div className="flex items-center gap-2">
                {profile.mode === "prefill"  && <FileText     className={cn("w-4 h-4 flex-shrink-0", profile.modeColor)} />}
                {profile.mode === "redirect" && <ExternalLink className={cn("w-4 h-4 flex-shrink-0", profile.modeColor)} />}
                {profile.mode === "prepared" && <MessageSquare className={cn("w-4 h-4 flex-shrink-0", profile.modeColor)} />}
                {profile.mode === "manual"   && <ListChecks   className={cn("w-4 h-4 flex-shrink-0", profile.modeColor)} />}
                <span className={cn("text-xs font-semibold uppercase tracking-wider", profile.modeColor)}>
                  {profile.modeLabel}
                </span>
              </div>

              {/* Prepared by Serenya */}
              <div>
                <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1.5">
                  <CheckCheck className="w-3.5 h-3.5 text-emerald-400" />
                  Ce que Serenya a préparé pour vous
                </p>
                <ul className="space-y-1.5">
                  {profile.prepared.map(item => (
                    <li key={item} className="flex items-start gap-2 text-xs text-foreground/80">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Required */}
              {!isDone && (
                <div>
                  <p className="text-xs font-medium text-muted-foreground mb-2 flex items-center gap-1.5">
                    <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
                    Ce qui nécessite votre accord
                  </p>
                  <ul className="space-y-1.5">
                    {profile.required.map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-xs text-foreground/80">
                        <div className="w-4 h-4 rounded-full border border-amber-400/40 flex items-center justify-center flex-shrink-0 mt-0.5 text-[9px] font-bold text-amber-400/70">
                          {i + 1}
                        </div>
                        {item}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Pre-filled data preview (mode: prefill) */}
            {profile.mode === "prefill" && profile.prefillData && !isDone && (
              <div className="rounded-xl border border-border/60 overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/40 border-b border-border/40">
                  <Eye className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Données préparées</span>
                  <span className="ml-auto text-xs text-muted-foreground/50">Vous vérifiez avant envoi</span>
                </div>
                <div className="px-4 py-3 space-y-2">
                  {profile.prefillData.map(d => (
                    <div key={d.label} className="flex items-center justify-between gap-3 py-1 border-b border-border/20 last:border-0">
                      <span className="text-xs text-muted-foreground">{d.label}</span>
                      <span className={cn("text-xs font-medium", d.masked ? "text-muted-foreground/50 font-mono" : "text-foreground/80")}>
                        {d.masked ? "••••••••" : d.value}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="px-4 py-2.5 bg-muted/20 border-t border-border/30">
                  <p className="text-xs text-muted-foreground/60 flex items-center gap-1.5">
                    <Lock className="w-3 h-3" />
                    Données chiffrées — jamais stockées en clair
                  </p>
                </div>
              </div>
            )}

            {/* Checklist (mode: manual) */}
            {profile.mode === "manual" && checkItems.length > 0 && !isDone && (
              <div className="rounded-xl border border-border/60 overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/40 border-b border-border/40">
                  <ListChecks className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Checklist de démarche</span>
                  <span className="ml-auto text-xs text-emerald-400">
                    {checks.filter(Boolean).length}/{checkItems.length}
                  </span>
                </div>
                <div className="px-4 py-3 space-y-2">
                  {checkItems.map((item, i) => (
                    <button key={item.label}
                      onClick={() => {
                        const next = [...checks];
                        next[i] = !next[i];
                        setChecklist(next);
                      }}
                      className="w-full flex items-start gap-3 py-1.5 text-left hover:bg-muted/30 rounded-lg px-1 transition-colors group">
                      <div className={cn(
                        "w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all",
                        checks[i] ? "border-emerald-500 bg-emerald-500" : "border-border/60 group-hover:border-primary/40"
                      )}>
                        {checks[i] && <CheckCircle2 className="w-3 h-3 text-white" />}
                      </div>
                      <span className={cn("text-xs leading-relaxed", checks[i] ? "line-through text-muted-foreground/50" : "text-foreground/80")}>
                        {item.label}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Email preview (mode: prepared) */}
            {profile.mode === "prepared" && emailContent && !isDone && (
              <div className="rounded-xl border border-border/60 overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2.5 bg-muted/40 border-b border-border/40">
                  <span className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <SendHorizonal className="w-3.5 h-3.5" /> Email préparé par Serenya
                  </span>
                  <button onClick={handleCopy}
                    className="flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 font-medium transition-colors">
                    {copied ? <CheckCheck className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                    {copied ? "Copié !" : "Copier"}
                  </button>
                </div>
                <pre className="p-4 text-xs text-muted-foreground whitespace-pre-wrap font-mono leading-relaxed max-h-48 overflow-y-auto bg-muted/15">
                  {emailContent}
                </pre>
              </div>
            )}

            {/* Action buttons */}
            {!isDone && (
              <div className="space-y-2">
                <Button
                  className={cn("w-full h-11 font-semibold gap-2 text-sm",
                    profile.mode === "prefill" || profile.mode === "redirect" ? "shadow-lg shadow-primary/20" : ""
                  )}
                  variant={profile.mode === "prefill" || profile.mode === "redirect" ? "default" : "outline"}
                  onClick={profile.mode === "prepared" ? handleCopy : undefined}
                >
                  {profile.mode === "prefill"  && <ExternalLink className="w-4 h-4" />}
                  {profile.mode === "redirect" && <ExternalLink className="w-4 h-4" />}
                  {profile.mode === "prepared" && (copied ? <CheckCheck className="w-4 h-4" /> : <Copy className="w-4 h-4" />)}
                  {profile.mode === "manual"   && <Info className="w-4 h-4" />}
                  {profile.mode === "prepared" && copied ? "Email copié !" : profile.actionLabel}
                </Button>
                <button
                  onClick={() => {
                    // Auto-generate tasks from this org profile via API
                    const generated = generateTasksFromProfile(
                      task.serviceName,
                      profile.required,
                      profile.checklistItems,
                      profile.mode,
                      profile.emailTemplate ? profile.emailTemplate(addressLabel || "Adresse") : undefined,
                      [],
                    );
                    let created = 0;
                    const promises = generated.map(t =>
                      fetch("/api/user-tasks", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          title: t.label,
                          description: t.note || null,
                          category: t.kind,
                          priority: t.priority === "high" ? "high" : t.priority === "low" ? "low" : "medium",
                          orgName: t.serviceName,
                        }),
                      }).then(r => { if (r.ok) created++; }).catch(() => {})
                    );
                    Promise.all(promises).then(() => {
                      if (created > 0) {
                        toast({ title: `${created} tâche${created > 1 ? "s" : ""} générée${created > 1 ? "s" : ""}`, description: "Retrouvez-les dans Tâches" });
                      } else {
                        toast({ title: "Tâches déjà générées", description: "Toutes les actions sont déjà dans votre liste de tâches." });
                      }
                    });
                  }}
                  className="w-full flex items-center justify-center gap-2 h-10 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg border border-border/40 hover:border-border/80 bg-background"
                >
                  <ListChecks className="w-3.5 h-3.5" /> Générer les tâches
                </button>
                <button
                  onClick={() => {
                    const printWindow = window.open("", "_blank");
                    if (!printWindow) return;
                    const emailHtml = profile.emailTemplate
                      ? `<div style="margin-bottom:1.5rem"><p style="font-size:0.75rem;font-weight:600;color:#059669;margin-bottom:0.5rem">Email préparé</p><pre style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:1rem;font-size:0.75rem;white-space:pre-wrap;font-family:Menlo,monospace">${profile.emailTemplate(addressLabel || "Adresse").replace(/</g, "&lt;")}</pre></div>`
                      : "";
                    const prefillHtml = profile.prefillData
                      ? `<div style="margin-bottom:1.5rem"><p style="font-size:0.75rem;font-weight:500;color:#64748b;margin-bottom:0.5rem">Données pré-remplies</p>${profile.prefillData.map(d => `<div style="display:flex;justify-content:space-between;font-size:0.875rem;padding:0.25rem 0"><span style="color:#64748b">${d.label}</span><span style="font-weight:500">${d.masked ? "••••••••" : d.value}</span></div>`).join("")}</div>`
                      : "";
                    const checklistHtml = profile.checklistItems
                      ? `<div style="margin-bottom:1.5rem"><p style="font-size:0.75rem;font-weight:600;color:#64748b;margin-bottom:0.5rem">Checklist</p><ul style="margin:0;padding-left:1.25rem">${profile.checklistItems.map((item, i) => `<li style="margin-bottom:0.375rem;font-size:0.875rem">${i + 1}. ${item.label}</li>`).join("")}</ul></div>`
                      : "";
                    printWindow.document.write(`
<!DOCTYPE html><html><head><meta charset="utf-8"><title>Fiche ${task.serviceName} — Serenya</title>
<style>body{font-family:Inter,system-ui,sans-serif;line-height:1.6;color:#1a1a2e;max-width:680px;margin:40px auto;padding:0 20px}
h1{font-size:1.5rem;margin-bottom:0.25rem}.meta{color:#666;font-size:0.875rem;margin-bottom:1.5rem}
.section{margin-bottom:1.5rem}.section-title{font-size:0.75rem;font-weight:600;text-transform:uppercase;letter-spacing:0.05em;color:#059669;margin-bottom:0.5rem}
.section-title.action{color:#d97706}ul{margin:0;padding-left:1.25rem}li{margin-bottom:0.375rem;font-size:0.875rem}
.box{background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:1rem;margin-bottom:1rem}
.box-title{font-size:0.75rem;font-weight:500;color:#64748b;margin-bottom:0.5rem}
.footer{text-align:center;font-size:0.625rem;color:#94a3b8;margin-top:2rem;padding-top:1rem;border-top:1px solid #e2e8f0}
@media print{body{margin:0;padding:20px}}</style></head><body>
<h1>${task.serviceName}</h1><p class="meta">${profile.modeLabel} · Délai : ${profile.processingTime}</p>
<div class="box"><p class="box-title">Nouvelle adresse</p><p style="font-weight:500">${addressLabel || "Adresse"}</p></div>
<div class="section"><p class="section-title">Préparé par Serenya</p><ul>${profile.prepared.map(p => `<li>${p}</li>`).join("")}</ul></div>
<div class="section"><p class="section-title action">Votre action requise</p><ul>${profile.required.map((r, i) => `<li>${i + 1}. ${r}</li>`).join("")}</ul></div>
${prefillHtml}${emailHtml}${checklistHtml}
<div class="section"><p class="section-title">Prochaines étapes</p><ul>${profile.nextSteps.map((s, i) => `<li>${i + 1}. ${s}</li>`).join("")}</ul></div>
<div class="footer">Document généré par Serenya · ${new Date().toLocaleDateString("fr-FR")}<br>Aucune donnée sensible n'est stockée sans consentement.</div>
</body></html>`);
                    printWindow.document.close();
                    setTimeout(() => printWindow.print(), 300);
                  }}
                  className="w-full flex items-center justify-center gap-2 h-10 text-xs font-medium text-muted-foreground hover:text-foreground transition-colors rounded-lg border border-border/40 hover:border-border/80 bg-background"
                >
                  <Download className="w-3.5 h-3.5" /> Télécharger la fiche (PDF)
                </button>
              </div>
            )}

            {/* Timeline with real knowledge-base steps */}
            <div>
              <div className="flex items-center justify-between mb-3">
                <p className="text-xs font-semibold text-muted-foreground uppercase tracking-widest">Démarche</p>
                {kbSteps.length > 0 && (
                  <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-muted/60 text-muted-foreground">
                    {diffEmoji} {diffLabel} · {kbTime}
                  </span>
                )}
              </div>
              <div className="space-y-3 relative">
                <div className="absolute left-[9px] top-3 bottom-3 w-px bg-border/50" />
                {timelineSteps.map((step: any, idx: number) => (
                  <div key={idx} className="flex items-start gap-3 relative">
                    <div className={cn(
                      "w-[18px] h-[18px] rounded-full border-2 flex items-center justify-center flex-shrink-0 bg-background z-10 transition-all mt-0.5",
                      step.done   ? "border-emerald-500 bg-emerald-500" :
                      step.active ? "border-primary ring-2 ring-primary/20" : "border-border/50"
                    )}>
                      {step.done   && <CheckCircle2 className="w-3 h-3 text-white" />}
                      {step.active && <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <span className={cn("text-xs leading-relaxed block",
                        step.done   ? "text-muted-foreground/50 line-through" :
                        step.active ? "text-foreground font-semibold" : "text-muted-foreground"
                      )}>{step.label}</span>
                      {step.type === "action" && !step.done && (
                        <span className="text-[10px] text-violet-400 mt-0.5 block">Action requise</span>
                      )}
                      {step.type === "warning" && !step.done && (
                        <span className="text-[10px] text-amber-400 mt-0.5 block">⚠ Attention</span>
                      )}
                    </div>
                    {step.active && (
                      <span className="text-xs text-primary/70 font-medium pr-1 flex-shrink-0">{kbTime}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Documents needed */}
            {kbDocs.length > 0 && (
              <div className="rounded-xl border border-border/60 overflow-hidden">
                <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/40 border-b border-border/40">
                  <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                  <span className="text-xs font-medium text-muted-foreground">Documents requis</span>
                </div>
                <div className="px-4 py-3 space-y-1.5">
                  {kbDocs.map((doc: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 text-xs text-foreground/80">
                      <span className="text-emerald-400 flex-shrink-0">✓</span>
                      {doc}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Official URL */}
            {kbUrl && (
              <a href={kbUrl} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-3 rounded-xl border border-primary/20 bg-primary/5 hover:bg-primary/10 transition-colors group">
                <ExternalLink className="w-4 h-4 text-primary/70 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-primary group-hover:text-primary/80">Formulaire officiel</p>
                  <p className="text-[10px] text-muted-foreground truncate">{kbUrl}</p>
                </div>
                <ArrowRight className="w-3.5 h-3.5 text-primary/50 group-hover:text-primary/80 flex-shrink-0" />
              </a>
            )}

            {/* Next steps (always shown) */}
            <div className={cn(
              "rounded-xl border p-4",
              isDone ? "bg-emerald-500/5 border-emerald-500/15" : "bg-muted/30 border-border/40"
            )}>
              <p className="text-xs font-semibold mb-2.5 flex items-center gap-1.5"
                 style={{ color: isDone ? "rgb(110,231,183)" : undefined }}>
                <ArrowRight className="w-3.5 h-3.5" />
                {isDone ? "Ce qui se passe maintenant" : "Prochaines étapes"}
              </p>
              <ul className="space-y-2">
                {profile.nextSteps.map((step, i) => (
                  <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                    <span className={cn("flex-shrink-0 mt-0.5", isDone ? "text-emerald-400" : "text-primary/60")}>
                      {isDone ? "✓" : `${i + 1}.`}
                    </span>
                    {step}
                  </li>
                ))}
              </ul>
            </div>

            {/* Org-specific note */}
            <div className="rounded-xl bg-muted/25 border border-border/35 p-4 flex items-start gap-3">
              <Info className="w-4 h-4 text-primary/50 flex-shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground leading-relaxed">{profile.orgNote}</p>
            </div>

            {/* Security note */}
            <div className="rounded-xl bg-muted/20 border border-border/30 p-4 flex items-start gap-3">
              <Lock className="w-4 h-4 text-muted-foreground/50 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-xs font-medium text-muted-foreground/70 mb-1">Note de sécurité</p>
                <p className="text-xs text-muted-foreground/60 leading-relaxed">{profile.securityNote}</p>
              </div>
            </div>

            {/* Trust footer */}
            <div className="text-center space-y-1.5 pt-1 pb-2">
              <p className="text-xs text-muted-foreground/45">Vous gardez toujours le contrôle.</p>
              <p className="text-xs text-muted-foreground/35">Aucune donnée sensible n'est modifiée sans validation.</p>
            </div>
          </div>
        </div>

        {/* ── Footer ── */}
        <div className="px-5 py-3.5 border-t border-border/35 flex-shrink-0 flex items-center justify-between bg-muted/10">
          <button className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors">
            <HelpCircle className="w-3.5 h-3.5" /> Besoin d'aide ?
          </button>
          {isFailed && onRetry ? (
            <Button size="sm" variant="outline" className="gap-1.5 text-xs h-9 border-amber-500/30 text-amber-400 hover:bg-amber-500/10 hover:text-amber-300" onClick={() => { onRetry(); onClose(); }}>
              <Zap className="w-3 h-3" /> Relancer
            </Button>
          ) : (
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground/40">
              <Shield className="w-3 h-3" /> RGPD · AES-256
            </div>
          )}
        </div>
      </motion.div>
    </>
  );
}

/* ══════════════════════════════════════════════
   PAGE
══════════════════════════════════════════════ */

export default function AutomationsPage() {
  const queryClient = useQueryClient();
  const { toast }   = useToast();
  const [expandedId, setExpandedId]       = useState<number | null>(null);
  const [selectedTask, setSelectedTask]   = useState<TaskItem | null>(null);
  const [selectedAddr, setSelectedAddr]   = useState("");

  const { data: automations, isLoading, isError } = useListAutomations();
  const { data: allTasks }               = useListAutomationTasks();
  const cancel                           = useCancelAutomation();
  const createShare                      = useCreateShareLink();
  const deleteShare                      = useDeleteShareLink();

  type ShareModal = { automationId: number; linkId: number | null; shareUrl: string | null; loading: boolean };
  const [shareModal, setShareModal]      = useState<ShareModal | null>(null);
  const [shareCopied, setShareCopied]    = useState(false);
  const [debriefId, setDebriefId]        = useState<number | null>(null);
  const [debriefAddr, setDebriefAddr]    = useState<string>("");

  const retry = useRetryAutomationTask();
  const seenCompleted = useRef<Set<number>>(new Set());
  const initialLoadDone = useRef<boolean>(false);

  useEffect(() => {
    if (!automations) return;

    // First render: silently mark all non-running automations as "seen" so we
    // don't fire confetti/debrief for pre-existing completions on page load.
    if (!initialLoadDone.current) {
      initialLoadDone.current = true;
      automations.forEach(auto => {
        if (!["running", "queued"].includes(auto.status)) {
          seenCompleted.current.add(auto.id);
        }
      });
      return;
    }

    // Subsequent renders: only trigger for newly-completed automations.
    automations.forEach((auto) => {
      const isTerminal =
        (auto.status === "completed" || auto.status === "partial") &&
        !seenCompleted.current.has(auto.id);

      if (isTerminal) {
        seenCompleted.current.add(auto.id);
        if (auto.status === "completed") {
          confetti({
            particleCount: 120,
            spread: 70,
            origin: { y: 0.55 },
            colors: ["#6366f1", "#8b5cf6", "#22c55e", "#f59e0b", "#ec4899"],
            zIndex: 9999,
          });
          toast({
            title: "Toutes vos démarches sont préparées",
            description: "Serenya a préparé toutes les étapes. Connectez-vous sur chaque site pour finaliser les mises à jour.",
            duration: 5000,
          });
        } else {
          toast({
            title: "Presque terminé",
            description: "Quelques organisations demandent une dernière vérification. Rien d'urgent.",
            duration: 6000,
          });
        }
        // Auto-open debrief 2 seconds after the notification
        const id = auto.id;
        const addr = auto.addressLabel ?? "";
        setTimeout(() => {
          setDebriefId(id);
          setDebriefAddr(addr);
        }, 2000);
      }
    });
  }, [automations]);

  function openShare(automationId: number) {
    setShareModal({ automationId, linkId: null, shareUrl: null, loading: true });
    createShare.mutate(
      { data: { automationId } },
      {
        onSuccess: (link) => setShareModal({ automationId, linkId: link.id, shareUrl: link.shareUrl ?? null, loading: false }),
        onError: (err: any) => {
          setShareModal(null);
          toast({ title: "Erreur de partage", description: err?.response?.data?.error ?? "Impossible de créer le lien." });
        },
      }
    );
  }

  function copyShareUrl(url: string) {
    navigator.clipboard.writeText(url).then(() => {
      setShareCopied(true);
      setTimeout(() => setShareCopied(false), 2000);
    });
  }

  function disableShare() {
    if (!shareModal?.linkId) return;
    deleteShare.mutate({ id: shareModal.linkId }, { onSuccess: () => setShareModal(null) });
  }

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: getListAutomationsQueryKey() });
    queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
  };

  return (
    <AppLayout title="Préparations">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-4xl mx-auto space-y-6">

        {/* Page header */}
        <div>
          <h2 className="text-2xl font-bold">Mes préparations</h2>
          <p className="text-sm text-muted-foreground mt-1 max-w-xl leading-relaxed">
            Serenya prépare chaque démarche à votre place. Cliquez sur un service pour voir le détail et les actions disponibles.
          </p>
        </div>

        {/* Trust banner */}
        <div className="rounded-xl bg-primary/5 border border-primary/15 p-4 flex items-start gap-3">
          <Shield className="w-5 h-5 text-primary/60 flex-shrink-0 mt-0.5" />
          <p className="text-sm text-muted-foreground leading-relaxed">
            <span className="font-semibold text-foreground/80">Vous gardez toujours le contrôle.</span>{" "}
            Serenya prépare les démarches et vous guide — aucune modification sensible n'est effectuée sans votre validation explicite.
          </p>
        </div>

        {isLoading ? (
          <div className="space-y-3">
            {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
          </div>
        ) : isError ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className="py-14 text-center rounded-2xl border border-dashed border-amber-500/20 bg-amber-500/5"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-3">
              <AlertTriangle className="w-4 h-4 text-amber-400/70" />
            </div>
            <p className="text-sm font-medium text-foreground/80">Impossible de charger vos préparations</p>
            <p className="text-xs text-muted-foreground mt-1.5 max-w-xs mx-auto leading-relaxed">
              Un petit souci technique de notre côté. Vos données sont en sécurité — réessayez dans un instant.
            </p>
          </motion.div>
        ) : !automations || automations.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
            className="py-20 text-center border border-dashed border-border/50 rounded-2xl bg-muted/[0.03]"
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.1, type: "spring", stiffness: 300, damping: 20 }}
              className="w-16 h-16 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center mx-auto mb-5"
            >
              <Zap className="w-8 h-8 text-primary/60" />
            </motion.div>
            <h3 className="font-semibold text-base mb-2 text-foreground/90">Vos démarches, organisées</h3>
            <p className="text-sm text-muted-foreground max-w-sm mx-auto mb-2 leading-relaxed">
              Lancez une préparation pour centraliser vos changements d'adresse. Serenya connaît les procédures de 25 organismes français.
            </p>
            <p className="text-xs text-muted-foreground/50 mb-6 max-w-xs mx-auto leading-relaxed">
              Vous gardez le contrôle à chaque étape. Les actions sensibles demandent toujours votre confirmation.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
              <a href="/dashboard">
                <Button className="gap-2 transition-all duration-200 hover:shadow-sm">
                  <Zap className="w-4 h-4" /> Lancer une préparation
                </Button>
              </a>
              <a href="/services">
                <Button variant="outline" className="gap-2 transition-all duration-200 hover:shadow-sm">
                  <ListChecks className="w-4 h-4" /> Connecter mes services
                </Button>
              </a>
            </div>
          </motion.div>
        ) : (
          <div className="space-y-3">
            {automations.map((auto, i) => {
              const st    = AUTO_STATUS_CFG[auto.status as keyof typeof AUTO_STATUS_CFG] ?? AUTO_STATUS_CFG.queued;
              const tasks = allTasks?.filter(t => t.automationId === auto.id) ?? [];
              const isExp = expandedId === auto.id;
              const isAct = ["queued", "running"].includes(auto.status);
              const failedCount = tasks.filter(t => t.status === "failed").length;

              return (
                <motion.div key={auto.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.06 }}>
                  <div className={cn(
                    "border rounded-2xl overflow-hidden bg-card transition-all duration-200",
                    isAct ? "border-primary/30 shadow-lg shadow-primary/5" : "border-border/60 hover:border-border/80 hover:shadow-sm"
                  )}>
                    <div className="p-5">
                      <div className="flex items-start gap-3">
                        <div className={cn("w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0", st.bg)}>
                          {auto.status === "running" ? <Zap className="w-4 h-4 text-blue-500" /> : auto.status === "completed" ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : auto.status === "partial" ? <AlertTriangle className="w-4 h-4 text-amber-500" /> : auto.status === "failed" ? <XCircle className="w-4 h-4 text-red-500" /> : auto.status === "cancelled" ? <Ban className="w-4 h-4" /> : <Clock className="w-4 h-4" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap mb-1">
                            <h3 className="font-semibold text-sm">
                              {auto.addressLabel ?? "Adresse"} — {auto.totalServices} service(s)
                            </h3>
                            <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium", st.bg)}>
                              {st.label}
                            </span>
                            {failedCount > 0 && (
                              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full border border-amber-500/20 bg-amber-500/10 text-amber-400 text-xs font-medium">
                                <AlertTriangle className="w-2.5 h-2.5" />
                                {failedCount} action(s) requise(s)
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-muted-foreground">
                            {new Date(auto.createdAt).toLocaleDateString("fr-FR", {
                              day: "numeric", month: "long", year: "numeric",
                              hour: "2-digit", minute: "2-digit"
                            })}
                          </p>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {/* Debrief IA — only for completed/partial */}
                          {!isAct && (auto.status === "completed" || auto.status === "partial") && (
                            <Button
                              variant="ghost" size="sm"
                              className="h-8 px-2.5 text-xs gap-1.5 text-muted-foreground hover:text-primary hover:bg-primary/10 hidden sm:flex"
                              title="Voir le bilan Sofia"
                              onClick={() => { setDebriefId(auto.id); setDebriefAddr(auto.addressLabel ?? ""); }}
                            >
                              <Sparkles className="w-3 h-3" /> Bilan IA
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground hover:text-primary hover:bg-primary/10"
                            title="Partager l'avancement"
                            onClick={() => openShare(auto.id)}>
                            <Share2 className="w-3.5 h-3.5" />
                          </Button>
                          {isAct && (
                            <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                              onClick={() => cancel.mutate({ id: auto.id }, {
                                onSuccess: () => { invalidate(); toast({ title: "Démarche annulée", description: "La préparation a été interrompue. Vous pouvez la relancer quand vous le souhaitez." }); }
                              })}>
                              <Ban className="w-3.5 h-3.5" />
                            </Button>
                          )}
                          <Button variant="ghost" size="icon" className="w-8 h-8 text-muted-foreground"
                            onClick={() => setExpandedId(isExp ? null : auto.id)}>
                            {isExp ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </Button>
                        </div>
                      </div>

                      {/* Progress */}
                      <div className="mt-3 space-y-1.5">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>{auto.completedServices} préparé(s) · {auto.failedServices} en attente d'action</span>
                          <span className="font-medium">{auto.progressPercent}%</span>
                        </div>
                        <Progress value={auto.progressPercent} className="h-1.5" />
                      </div>

                      {/* Contextual reassurance strip */}
                      {(() => {
                        const msgs: Record<string, { text: string; color: string; bg: string }> = {
                          running: { text: "Serenya prépare vos démarches. Les instructions seront disponibles dans quelques instants.", color: "text-primary/70", bg: "bg-primary/5 border-primary/15" },
                          queued:  { text: "Votre demande est bien enregistrée. Le traitement démarrera très prochainement.", color: "text-muted-foreground", bg: "bg-muted/30 border-border/30" },
                          partial: { text: "Certaines démarches demandent votre attention. Cliquez sur un service pour voir les détails.", color: "text-amber-400/80", bg: "bg-amber-500/5 border-amber-500/15" },
                          completed: { text: "Toutes vos démarches ont été traitées. Vous serez notifié si une confirmation est nécessaire.", color: "text-emerald-400/80", bg: "bg-emerald-500/5 border-emerald-500/15" },
                          failed:  { text: "Certaines organisations ont besoin de votre intervention. Cliquez sur le service concerné pour finaliser.", color: "text-destructive/70", bg: "bg-destructive/5 border-destructive/15" },
                        };
                        const msg = msgs[auto.status];
                        if (!msg) return null;
                        return (
                          <div className={cn("mt-2.5 flex items-start gap-2 px-3 py-2 rounded-lg border text-xs", msg.bg)}>
                            <span className={cn("leading-relaxed", msg.color)}>{msg.text}</span>
                          </div>
                        );
                      })()}
                    </div>

                    {/* Task list */}
                    <AnimatePresence>
                      {isExp && (
                        <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.22 }}>
                          <div className="border-t border-border/40">
                            <p className="text-xs text-muted-foreground/50 px-5 pt-3 pb-1">
                              Cliquez sur un service pour accéder au détail et aux actions disponibles
                            </p>
                            {tasks.length === 0 ? (
                              <div className="px-5 py-6 text-center">
                                <div className="w-10 h-10 rounded-xl bg-muted/30 border border-border/30 flex items-center justify-center mx-auto mb-2.5">
                                  <ListChecks className="w-4 h-4 text-muted-foreground/40" />
                                </div>
                                <p className="text-xs text-muted-foreground/60">Les détails de vos démarches apparaîtront ici.</p>
                                <p className="text-xs text-muted-foreground/40 mt-0.5">Cliquez sur un service pour voir les étapes disponibles.</p>
                              </div>
                            ) : tasks.map(task => {
                              const profile = getProfile(task.serviceName ?? "Service");
                              const tSt = STATUS_CFG[task.status as keyof typeof STATUS_CFG] ?? STATUS_CFG.queued;
                              const isAction = task.status === "failed";
                              return (
                                <div key={task.id}
                                  role="button"
                                  tabIndex={0}
                                  onClick={() => {
                                    setSelectedTask({ id: task.id, serviceName: task.serviceName ?? "Service", status: task.status, errorMessage: task.errorMessage, stepData: task.stepData, createdAt: task.createdAt });
                                    setSelectedAddr(auto.addressLabel ?? "");
                                  }}
                                  onKeyDown={(e) => e.key === "Enter" && setSelectedTask({ id: task.id, serviceName: task.serviceName ?? "Service", status: task.status, errorMessage: task.errorMessage, stepData: task.stepData, createdAt: task.createdAt })}
                                  className={cn(
                                    "w-full flex items-center gap-3 px-5 py-3.5 border-b border-border/25 last:border-0 text-left transition-all group cursor-pointer",
                                    "hover:bg-muted/40",
                                    isAction && "bg-amber-500/4 hover:bg-amber-500/8"
                                  )}
                                >
                                  <ServiceAvatar name={task.serviceName ?? "S"} size="sm" />
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center gap-2 flex-wrap">
                                      <p className="text-sm font-medium">{task.serviceName}</p>
                                      {task.status === "completed" && (
                                        <span className="inline-flex items-center gap-0.5 text-xs font-medium text-emerald-400/70 bg-emerald-500/8 border border-emerald-500/15 px-1.5 py-0.5 rounded-full">
                                          <Sparkles className="w-2.5 h-2.5" />
                                          Prêt
                                        </span>
                                      )}
                                      {(task.status === "queued" || task.status === "running") && (
                                        <span className="inline-flex items-center gap-0.5 text-xs font-medium text-blue-400/70 bg-blue-500/8 border border-blue-500/15 px-1.5 py-0.5 rounded-full">
                                          <Clock className="w-2.5 h-2.5" />
                                          ~{profile.processingTime}
                                        </span>
                                      )}
                                    </div>
                                    <p className={cn("text-xs mt-0.5", isAction ? "text-amber-400/80" : "text-muted-foreground/60")}>
                                      {isAction ? (task.errorMessage ?? "Action requise") : profile.assistanceLabel}
                                    </p>
                                    {/* Tracking timeline for running/completed tasks */}
                                    {(task.status === "running" || task.status === "completed" || task.trackingStatus) && task.trackingSteps && (
                                      <div className="mt-2 pt-2 border-t border-border/20">
                                        <ServiceTrackingTimeline
                                          steps={task.trackingSteps as any[]}
                                          currentStatus={task.trackingStatus ?? task.status}
                                          serviceName={task.serviceName ?? "Service"}
                                        />
                                      </div>
                                    )}
                                  </div>
                                  {isAction ? (
                                    <button
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        retry.mutate({ id: task.id }, {
                                          onSuccess: () => {
                                            queryClient.invalidateQueries({ queryKey: getListAutomationTasksQueryKey() });
                                            queryClient.invalidateQueries({ queryKey: getListAutomationsQueryKey() });
                                            toast({ title: "Tâche relancée", description: "Elle va être re-examinée et préparée à nouveau." });
                                          },
                                        });
                                      }}
                                      disabled={retry.isPending}
                                      className="flex-shrink-0 px-2.5 py-1 rounded-lg bg-amber-500/10 text-amber-400 text-xs font-medium hover:bg-amber-500/20 transition-colors border border-amber-500/20 flex items-center gap-1"
                                    >
                                      <Zap className="w-3 h-3" />
                                      {retry.isPending ? "…" : "Relancer"}
                                    </button>
                                  ) : (
                                    <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full border text-xs font-medium flex-shrink-0 hidden sm:flex", tSt.cls)}>
                                      {tSt.label}
                                    </span>
                                  )}
                                  <ChevronRight className="w-4 h-4 text-muted-foreground/25 flex-shrink-0 group-hover:text-primary/50 transition-colors" />
                                </div>
                              );
                            })}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      {/* Detail panel */}
      <AnimatePresence>
        {selectedTask && (
          <TaskDetailPanel
            task={selectedTask}
            addressLabel={selectedAddr}
            onClose={() => setSelectedTask(null)}
            onRetry={() => retry.mutate({ id: selectedTask.id }, {
              onSuccess: () => {
                queryClient.invalidateQueries({ queryKey: getListAutomationTasksQueryKey() });
                queryClient.invalidateQueries({ queryKey: getListAutomationsQueryKey() });
                toast({ title: "Tâche relancée", description: "Elle va être re-examinée et préparée à nouveau." });
              },
            })}
          />
        )}
      </AnimatePresence>

      {/* Debrief modal */}
      <AnimatePresence>
        {debriefId !== null && (
          <AutomationDebrief
            automationId={debriefId}
            addressLabel={debriefAddr}
            onClose={() => { setDebriefId(null); setDebriefAddr(""); }}
          />
        )}
      </AnimatePresence>

      {/* Share modal */}
      <AnimatePresence>
        {shareModal && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 bg-background/70 backdrop-blur-sm z-50"
              onClick={() => setShareModal(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.96, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.96, y: 8 }}
              transition={{ duration: 0.18 }}
              className="fixed left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-sm px-4"
            >
              <div className="rounded-2xl border border-border/60 bg-card shadow-2xl overflow-hidden">
                {/* Header */}
                <div className="flex items-center justify-between px-5 py-4 border-b border-border/30">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Share2 className="w-3.5 h-3.5 text-primary" />
                    </div>
                    <span className="font-semibold text-sm">Partager l'avancement</span>
                  </div>
                  <button onClick={() => setShareModal(null)}
                    className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground transition-colors">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Body */}
                <div className="px-5 py-5 space-y-4">
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    Partagez ce lien avec votre famille, votre bailleur ou toute personne concernée par votre déménagement.
                    La page ne contient <span className="font-medium text-foreground/70">aucune donnée personnelle sensible</span>.
                  </p>

                  {shareModal.loading ? (
                    <div className="flex items-center justify-center py-4 gap-2 text-muted-foreground">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">Génération du lien…</span>
                    </div>
                  ) : shareModal.shareUrl ? (
                    <div className="space-y-3">
                      {/* URL row */}
                      <div className="flex items-center gap-2 rounded-xl border border-border/50 bg-muted/20 px-3 py-2.5">
                        <LinkIcon className="w-3.5 h-3.5 text-muted-foreground/50 flex-shrink-0" />
                        <span className="text-xs text-muted-foreground truncate flex-1 font-mono">
                          {shareModal.shareUrl.replace(/^https?:\/\//, "")}
                        </span>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2">
                        <Button size="sm" className="flex-1 gap-1.5 h-9"
                          onClick={() => copyShareUrl(shareModal.shareUrl!)}>
                          {shareCopied
                            ? <><CheckCheck className="w-3.5 h-3.5" /> Copié !</>
                            : <><Copy className="w-3.5 h-3.5" /> Copier le lien</>
                          }
                        </Button>
                        <Button size="sm" variant="outline" className="h-9 px-3"
                          onClick={() => window.open(shareModal.shareUrl!, "_blank")}>
                          <ExternalLink className="w-3.5 h-3.5" />
                        </Button>
                      </div>

                      {/* Disable */}
                      <button onClick={disableShare}
                        className="w-full text-xs text-muted-foreground/50 hover:text-destructive/70 transition-colors py-1 text-center">
                        Désactiver ce lien de partage
                      </button>
                    </div>
                  ) : null}
                </div>

                {/* Footer */}
                <div className="px-5 py-3 border-t border-border/25 bg-muted/10">
                  <p className="text-xs text-muted-foreground/40 flex items-center gap-1.5">
                    <Shield className="w-3 h-3" /> Aucune adresse ni donnée sensible n'est exposée
                  </p>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </AppLayout>
  );
}
