import { useState, useEffect } from "react";
import { motion } from "@/lib/motion-compat";
import { Check, Sparkles, ArrowLeft, Zap, Building2, Crown, Shield, ChevronDown, ChevronUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Link, useLocation } from "wouter";
import { useUser } from "@clerk/react";
import { useToast } from "@/hooks/use-toast";

/* ── Plan data ──────────────────────────────────────────────────────────── */
const PLANS = [
  {
    id: "essential",
    name: "Essentiel",
    icon: Shield,
    iconColor: "text-slate-400",
    iconBg: "bg-slate-500/10",
    desc: "Pour tester Serenya sans engagement.",
    priceMonthly: 0,
    priceAnnual: 0,
    priceLabel: "Gratuit",
    cta: "Commencer gratuitement",
    ctaVariant: "outline" as const,
    highlight: false,
    features: [
      "2 préparations par mois",
      "5 services connectés",
      "1 adresse enregistrée",
      "Assistant Sofia (basique)",
      "Support par email",
      "Historique 30 jours",
    ],
    limitations: ["Sans accès API", "Sans tableau de bord équipe"],
  },
  {
    id: "pro",
    name: "Pro",
    icon: Zap,
    iconColor: "text-primary",
    iconBg: "bg-primary/10",
    desc: "Pour les particuliers qui déménagent et veulent tout centraliser.",
    priceMonthly: 9.99,
    priceAnnual: 7.99,
    priceLabel: null,
    cta: "Commencer avec Pro",
    ctaVariant: "default" as const,
    highlight: true,
    badge: "Le plus populaire",
    features: [
      "Préparations illimitées",
      "Tous les services (15+)",
      "Adresses illimitées",
      "Assistant Sofia prioritaire",
      "Support prioritaire < 4h",
      "Historique complet",
      "Partage de rapport",
      "Export RGPD avancé",
    ],
    limitations: [],
  },
  {
    id: "business",
    name: "Business",
    icon: Crown,
    iconColor: "text-amber-400",
    iconBg: "bg-amber-400/10",
    desc: "Pour les agences immobilières et équipes RH qui gèrent des déménagements en volume.",
    priceMonthly: 24.99,
    priceAnnual: 19.99,
    priceLabel: null,
    cta: "Contacter l'équipe",
    ctaVariant: "outline" as const,
    highlight: false,
    features: [
      "Tout ce qui est dans Pro",
      "Jusqu'à 5 comptes membres",
      "Tableau de bord équipe",
      "API access (REST)",
      "SLA 99.9% garanti",
      "Support dédié + téléphone",
      "Onboarding personnalisé",
      "Facturation centralisée",
    ],
    limitations: [],
  },
];

const FAQ = [
  {
    q: "Puis-je changer de plan à tout moment ?",
    a: "Oui, vous pouvez passer à un plan supérieur ou inférieur à n'importe quel moment. La facturation est ajustée au prorata de la période en cours.",
  },
  {
    q: "Que se passe-t-il si je dépasse ma limite de préparations sur le plan Essentiel ?",
    a: "Vous recevrez une notification et pourrez soit attendre le renouvellement mensuel, soit passer au plan Pro pour continuer immédiatement. Aucune préparation en cours ne sera interrompue.",
  },
  {
    q: "Mes données sont-elles sécurisées ?",
    a: "Absolument. Toutes vos données sont chiffrées (AES-256), hébergées en Europe et nous sommes conformes RGPD. Nous ne partageons jamais vos informations avec des tiers.",
  },
  {
    q: "Comment fonctionne l'essai gratuit du plan Pro ?",
    a: "Le plan Essentiel est gratuit pour toujours. Si vous souhaitez tester le plan Pro, contactez-nous — nous offrons 14 jours d'essai sur demande.",
  },
];

/* ── FAQ Item ────────────────────────────────────────────────────────────── */
function FaqItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="border-b border-border/40 last:border-0">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center justify-between py-4 text-left gap-4 hover:text-foreground text-foreground/80 transition-colors"
      >
        <span className="text-sm font-medium">{q}</span>
        {open ? <ChevronUp className="w-4 h-4 flex-shrink-0 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 flex-shrink-0 text-muted-foreground" />}
      </button>
      {open && (
        <motion.p
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: "auto" }}
          className="text-sm text-muted-foreground pb-4 leading-relaxed"
        >
          {a}
        </motion.p>
      )}
    </div>
  );
}

/* ── Main component ──────────────────────────────────────────────────────── */
export default function PricingPage() {
  const [annual, setAnnual] = useState(false);
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [currentPlan, setCurrentPlan] = useState<string>("free");
  const { isSignedIn } = useUser();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  useEffect(() => {
    if (!isSignedIn) return;
    fetch("/api/stripe/subscription", { credentials: "include" })
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data?.plan) setCurrentPlan(data.plan); })
      .catch(() => {});
  }, [isSignedIn]);

  async function handleCta(plan: typeof PLANS[0]) {
    if (plan.id === "business") {
      window.location.href = "mailto:hello@serenya.fr?subject=Plan Business";
      return;
    }
    if (plan.id === "essential") {
      if (isSignedIn) navigate("/dashboard");
      else navigate("/sign-up");
      return;
    }
    // Pro — Stripe checkout
    if (!isSignedIn) { navigate("/sign-up"); return; }
    setLoadingPlan(plan.id);
    try {
      const r = await fetch("/api/stripe/plans", { credentials: "include" });
      if (!r.ok) throw new Error();
      const plans = await r.json();
      const interval = annual ? "year" : "month";
      let priceId: string | undefined;
      for (const p of plans) {
        for (const price of p.prices ?? []) {
          if (price.recurring?.interval === interval) { priceId = price.id; break; }
        }
        if (priceId) break;
      }
      if (!priceId) throw new Error("Plan introuvable");
      const cr = await fetch("/api/stripe/checkout", {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ priceId }),
      });
      const data = await cr.json();
      if (data?.url) window.location.href = data.url;
      else throw new Error();
    } catch {
      toast({ title: "Paiement temporairement indisponible", description: "Nous activons progressivement les paiements. Contactez-nous pour un accès prioritaire.", variant: "default" });
    } finally {
      setLoadingPlan(null);
    }
  }

  const container = { hidden: {}, show: { transition: { staggerChildren: 0.08 } } };
  const item = { hidden: { opacity: 0, y: 20 }, show: { opacity: 1, y: 0 } };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* ── Top bar ── */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-background/80 border-b border-border/40">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center shadow-md shadow-primary/20 group-hover:shadow-primary/40 transition-shadow">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-bold text-sm tracking-tight">Serenya</span>
          </Link>
          <div className="flex items-center gap-3">
            {isSignedIn ? (
              <Link href="/dashboard">
                <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
                  <ArrowLeft className="w-3.5 h-3.5" /> Retour à l'app
                </Button>
              </Link>
            ) : (
              <>
                <Link href="/sign-in">
                  <Button variant="ghost" size="sm" className="text-xs">Se connecter</Button>
                </Link>
                <Link href="/sign-up">
                  <Button size="sm" className="text-xs">Essai gratuit</Button>
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 pb-20">
        {/* ── Hero ── */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center pt-16 pb-12"
        >
          <Badge variant="outline" className="mb-5 text-xs text-primary border-primary/30 bg-primary/5 px-3 py-1">
            Tarifs transparents
          </Badge>
          <h1 className="text-4xl sm:text-5xl font-bold tracking-tight mb-4 leading-tight">
            Un seul abonnement,{" "}
            <span className="bg-gradient-to-r from-primary to-violet-500 bg-clip-text text-transparent">
              zéro prise de tête
            </span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Commencez gratuitement. Passez à Pro quand vous êtes prêt. Annulez à tout moment.
          </p>

          {/* Annual toggle */}
          <div className="flex items-center justify-center gap-3 mt-8">
            <span className={cn("text-sm font-medium transition-colors", !annual ? "text-foreground" : "text-muted-foreground")}>Mensuel</span>
            <button
              onClick={() => setAnnual(!annual)}
              className={cn(
                "relative w-12 h-6 rounded-full transition-colors",
                annual ? "bg-primary" : "bg-muted"
              )}
            >
              <motion.span
                className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow-sm"
                animate={{ x: annual ? 24 : 0 }}
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
              />
            </button>
            <span className={cn("text-sm font-medium transition-colors", annual ? "text-foreground" : "text-muted-foreground")}>
              Annuel
            </span>
            {annual && (
              <motion.span
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-xs font-semibold text-emerald-500 bg-emerald-500/10 px-2 py-0.5 rounded-full"
              >
                −20%
              </motion.span>
            )}
          </div>

          {/* Payment method icons */}
          <div className="flex items-center justify-center gap-4 mt-4 opacity-60">
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.37 0 0 5.37 0 12s5.37 12 12 12 12-5.37 12-12S18.63 0 12 0zm0 22c-5.51 0-10-4.49-10-10S6.49 2 12 2s10 4.49 10 10-4.49 10-10 10z"/></svg>
              <span>Apple Pay</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93 0-.62.08-1.21.21-1.79L9 15v1c0 1.1.9 2 2 2v1.93zm6.9-2.54c-.26-.81-1-1.39-1.9-1.39h-1v-3c0-.55-.45-1-1-1H8v-2h2c.55 0 1-.45 1-1V7h2c1.1 0 2-.9 2-2v-.41c2.93 1.19 5 4.06 5 7.41 0 2.08-.8 3.97-2.1 5.39z"/></svg>
              <span>Google Pay</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><path d="M4 10v10c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V10H4zm12-4c0-1.66-1.34-3-3-3s-3 1.34-3 3H6v4h12V6h-2z"/></svg>
              <span>SEPA</span>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor"><rect x="2" y="5" width="20" height="14" rx="2"/></svg>
              <span>Carte</span>
            </div>
          </div>
        </motion.div>

        {/* ── Plans ── */}
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-16"
        >
          {PLANS.map((plan) => {
            const Icon = plan.icon;
            const isCurrentPlan = (plan.id === "essential" && currentPlan === "free") ||
              (plan.id === "pro" && currentPlan === "pro") ||
              (plan.id === "business" && currentPlan === "business");
            const price = plan.priceLabel ?? (annual ? plan.priceAnnual : plan.priceMonthly);
            const isLoading = loadingPlan === plan.id;
            return (
              <motion.div
                key={plan.id}
                variants={item}
                className={cn(
                  "relative rounded-2xl border p-6 flex flex-col transition-shadow duration-300",
                  plan.highlight
                    ? "border-primary/50 bg-primary/[0.03] shadow-xl shadow-primary/10 ring-1 ring-primary/20"
                    : "border-border/40 bg-card hover:border-border/70 hover:shadow-sm transition-all duration-200"
                )}
              >
                {plan.badge && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                    <Badge className="bg-primary text-primary-foreground text-xs px-3 shadow-lg shadow-primary/20">
                      {plan.badge}
                    </Badge>
                  </div>
                )}

                {isCurrentPlan && isSignedIn && (
                  <div className="absolute -top-3 right-4">
                    <Badge variant="outline" className="text-xs text-emerald-500 border-emerald-500/30 bg-background">
                      Plan actuel
                    </Badge>
                  </div>
                )}

                {/* Header */}
                <div className="mb-5">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center mb-3", plan.iconBg)}>
                    <Icon className={cn("w-5 h-5", plan.iconColor)} />
                  </div>
                  <h2 className="text-lg font-bold">{plan.name}</h2>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{plan.desc}</p>
                </div>

                {/* Price */}
                <div className="mb-6">
                  {typeof price === "number" && price > 0 ? (
                    <div className="flex items-end gap-1">
                      <span className="text-3xl font-bold tracking-tight">{price.toFixed(2).replace(".", ",")} €</span>
                      <span className="text-sm text-muted-foreground mb-1">/{annual ? "mois (annuel)" : "mois"}</span>
                    </div>
                  ) : (
                    <div className="flex items-end gap-1">
                      <span className="text-3xl font-bold tracking-tight">Gratuit</span>
                      <span className="text-sm text-muted-foreground mb-1">pour toujours</span>
                    </div>
                  )}
                  {annual && typeof price === "number" && price > 0 && (
                    <p className="text-xs text-muted-foreground/60 mt-1">
                      soit {(price * 12).toFixed(2).replace(".", ",")} €/an
                    </p>
                  )}
                </div>

                {/* CTA */}
                <Button
                  variant={plan.ctaVariant}
                  className={cn("w-full mb-6", plan.highlight && "shadow-lg shadow-primary/20")}
                  onClick={() => handleCta(plan)}
                  disabled={isLoading || (isCurrentPlan && isSignedIn)}
                >
                  {isLoading ? (
                    <span className="flex items-center gap-2">
                      <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                      Chargement…
                    </span>
                  ) : isCurrentPlan && isSignedIn ? "Plan actuel" : plan.cta}
                </Button>

                {/* Features */}
                <ul className="space-y-2.5 flex-1">
                  {plan.features.map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm">
                      <Check className="w-3.5 h-3.5 text-emerald-500 flex-shrink-0 mt-0.5" />
                      <span className="text-foreground/80">{f}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </motion.div>

        {/* ── Feature comparison table ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mb-16"
        >
          <h2 className="text-xl font-bold text-center mb-8">Comparaison détaillée</h2>
          <div className="border border-border/40 rounded-2xl overflow-x-auto">
            <table className="w-full text-sm min-w-[500px]">
              <thead>
                <tr className="border-b border-border/40 bg-muted/20">
                  <th className="text-left px-5 py-3.5 font-semibold text-muted-foreground">Fonctionnalité</th>
                  <th className="text-center px-4 py-3.5 font-semibold">Essentiel</th>
                  <th className="text-center px-4 py-3.5 font-semibold text-primary">Pro</th>
                  <th className="text-center px-4 py-3.5 font-semibold">Business</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Préparations/mois", "2", "Illimitées", "Illimitées"],
                  ["Services connectés", "5", "15+", "15+"],
                  ["Adresses enregistrées", "1", "Illimitées", "Illimitées"],
                  ["Assistant Sofia", "Basique", "Prioritaire", "Dédié"],
                  ["Partage de rapport", "—", "✓", "✓"],
                  ["API REST", "—", "—", "✓"],
                  ["Comptes équipe", "—", "—", "5"],
                  ["SLA garanti", "—", "—", "99.9%"],
                ].map(([feat, ess, pro, biz], i) => (
                  <tr key={feat} className={cn("border-b border-border/30 last:border-0", i % 2 === 1 && "bg-muted/10")}>
                    <td className="px-5 py-3 text-muted-foreground">{feat}</td>
                    <td className="text-center px-4 py-3">{ess === "—" ? <span className="text-muted-foreground/30">—</span> : ess}</td>
                    <td className="text-center px-4 py-3 text-primary font-medium">{pro === "—" ? <span className="text-muted-foreground/30">—</span> : pro}</td>
                    <td className="text-center px-4 py-3">{biz === "—" ? <span className="text-muted-foreground/30">—</span> : biz}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>

        {/* ── Social proof ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.35 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-16"
        >
          {[
            { stat: "2 min", label: "Temps moyen pour lancer une préparation complète" },
            { stat: "94%", label: "Taux de succès sur les mises à jour préparées" },
            { stat: "12+", label: "Heures économisées en moyenne par déménagement" },
          ].map((item) => (
            <div key={item.stat} className="text-center p-6 rounded-2xl border border-border/30 bg-muted/10">
              <p className="text-3xl font-bold text-primary mb-1">{item.stat}</p>
              <p className="text-xs text-muted-foreground leading-relaxed">{item.label}</p>
            </div>
          ))}
        </motion.div>

        {/* ── FAQ ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="max-w-2xl mx-auto mb-16"
        >
          <h2 className="text-xl font-bold text-center mb-8">Questions fréquentes</h2>
          <div className="border border-border/40 rounded-2xl px-6">
            {FAQ.map((faq) => <FaqItem key={faq.q} {...faq} />)}
          </div>
        </motion.div>

        {/* ── Bottom CTA ── */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.45 }}
          className="text-center p-10 rounded-2xl bg-gradient-to-br from-primary/10 to-violet-500/10 border border-primary/20"
        >
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center mx-auto mb-4 shadow-lg shadow-primary/30">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-xl font-bold mb-2">Prêt à simplifier votre déménagement ?</h3>
          <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto">
            Rejoignez des milliers de personnes qui ont simplifié leur changement d'adresse avec Serenya.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            <Link href={isSignedIn ? "/dashboard" : "/sign-up"}>
              <Button className="gap-2 shadow-lg shadow-primary/20">
                <Sparkles className="w-4 h-4" />
                {isSignedIn ? "Aller au tableau de bord" : "Commencer gratuitement"}
              </Button>
            </Link>
            {!isSignedIn && (
              <Link href="/sign-in">
                <Button variant="outline">J'ai déjà un compte</Button>
              </Link>
            )}
          </div>
          <p className="text-xs text-muted-foreground/50 mt-4">
            Aucune carte bancaire requise pour le plan Essentiel · Annulation à tout moment
          </p>
        </motion.div>
      </main>
    </div>
  );
}
