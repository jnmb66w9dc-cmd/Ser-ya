import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import {
  MapPin, Building2, Zap, CheckCircle2, Clock, ChevronRight,
  ShieldCheck, ArrowRight, Sparkles, ArrowLeft,
  TrendingUp, Activity, Shield, Info, Star, Lock,
  Bot, AlertTriangle, FileText, X, Send, Loader2,
  ChevronDown, ChevronUp
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";

/* ════════════════════════ DEMO DATA ══════════════════════════════════════ */

const DEMO_ADDRESSES = [
  { id: 1, label: "Maison", street: "12 rue de la Paix", city: "Paris", postalCode: "75001", country: "France", isDefault: true },
  { id: 2, label: "Bureau", street: "45 avenue des Champs-Élysées", city: "Paris", postalCode: "75008", country: "France", isDefault: false },
];

const DEMO_SERVICES = [
  { id: 1, name: "Orange", category: "Téléphonie", connected: true, status: "done" as const },
  { id: 2, name: "EDF", category: "Énergie", connected: true, status: "processing" as const },
  { id: 3, name: "BNP Paribas", category: "Banque", connected: true, status: "done" as const },
  { id: 4, name: "AXA", category: "Assurance", connected: true, status: "action" as const },
  { id: 5, name: "La Poste", category: "Postal", connected: true, status: "done" as const },
  { id: 6, name: "SNCF", category: "Transport", connected: false, status: "idle" as const },
];

const DEMO_AUTOMATIONS = [
  {
    id: 101,
    addressLabel: "Maison",
    status: "completed" as const,
    progressPercent: 100,
    completedServices: 4,
    totalServices: 5,
    failedServices: 1,
    summary: "4 sur 5 organismes mis à jour. AXA nécessite un justificatif."
  },
  {
    id: 102,
    addressLabel: "Maison",
    status: "running" as const,
    progressPercent: 60,
    completedServices: 3,
    totalServices: 5,
    failedServices: 0,
    summary: "EDF en cours de traitement — délai estimé 48h."
  },
];

const DEMO_ACTIVITY = [
  { id: 1, text: "Orange — adresse mise à jour avec succès", time: "Aujourd'hui, 14:32", type: "success" as const },
  { id: 2, text: "EDF — notification envoyée, en attente de validation", time: "Aujourd'hui, 11:15", type: "running" as const },
  { id: 3, text: "BNP Paribas — changement d'adresse validé", time: "Hier, 16:45", type: "success" as const },
  { id: 4, text: "AXA — justificatif de domicile requis", time: "Hier, 09:20", type: "warning" as const },
];

const SOFIA_MESSAGES = [
  { type: "bot" as const, text: "Bonjour ! Je suis Sofia, votre assistant Serenya. Je vais vous guider pas à pas dans vos démarches." },
  { type: "bot" as const, text: "J'ai analysé vos 5 organismes connectés. 4 sont prêt à être mis à jour automatiquement." },
  { type: "bot" as const, text: "Seul AXA demande un justificatif de domicile — je vous prépare le formulaire pré-rempli." },
];

/* ═════════════════════════════════════════════════════════════ */

export default function DemoPage() {
  const [activeTab, setActiveTab] = useState<"overview" | "addresses" | "services" | "automations" | "chat">("overview");
  const [chatOpen, setChatOpen] = useState(false);
  const [chatMessages, setChatMessages] = useState<{type: "bot" | "user"; text: string}[]>([]);
  const [chatStep, setChatStep] = useState(0);
  const [chatTyping, setChatTyping] = useState(false);
  const [expandedAuto, setExpandedAuto] = useState<number | null>(101);

  // Auto-play Sofia intro when chat opens
  useEffect(() => {
    if (!chatOpen || chatStep >= SOFIA_MESSAGES.length) return;
    const timer = setTimeout(() => {
      setChatTyping(true);
      setTimeout(() => {
        setChatMessages(prev => [...prev, SOFIA_MESSAGES[chatStep]]);
        setChatTyping(false);
        setChatStep(s => s + 1);
      }, 1200);
    }, chatStep === 0 ? 400 : 800);
    return () => clearTimeout(timer);
  }, [chatOpen, chatStep]);

  function sendDemoReply(text: string) {
    setChatMessages(prev => [...prev, { type: "user", text }]);
    setChatTyping(true);
    setTimeout(() => {
      const reply = text.toLowerCase().includes("comment")
        ? "Je prépare chaque démarche avec les documents exacts requis par chaque organisme. Vous validez avant envoi."
        : text.toLowerCase().includes("sûr") || text.toLowerCase().includes("sécur")
        ? "Vos données sont chiffrées AES-256, hébergées en Europe. Aucun mot de passe n'est stocké chez nous."
        : "Je reste à votre disposition pour toute question. Essayez Serenya gratuitement !";
      setChatMessages(prev => [...prev, { type: "bot", text: reply }]);
      setChatTyping(false);
    }, 1500);
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="sticky top-0 z-40 backdrop-blur-md bg-background/80 border-b border-border/40">
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2.5 group">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center shadow-md shadow-primary/20">
              <Sparkles className="w-3.5 h-3.5 text-white" />
            </div>
            <span className="font-bold text-sm tracking-tight">Serenya</span>
            <Badge variant="outline" className="text-[10px] border-amber-500/30 text-amber-400 bg-amber-500/10 ml-1">
              Démo
            </Badge>
            <span className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-medium bg-amber-500/15 text-amber-400 border border-amber-500/20 ml-2">
              <Info className="w-2.5 h-2.5" /> Données fictives — simulation
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link href="/">
              <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
                <ArrowLeft className="w-3.5 h-3.5" /> Retour
              </Button>
            </Link>
            <Link href="/sign-up">
              <Button size="sm" className="text-xs">Essayer gratuitement</Button>
            </Link>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-10">
        {/* Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="text-center mb-10"
        >
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-3">
            Voyez Serenya en action
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Un tableau de bord interactif avec des données réalistes — même les démarches bloquées.
          </p>
        </motion.div>

        {/* Tabs */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
          {([
            { key: "overview" as const, label: "Vue d'ensemble", icon: Activity },
            { key: "addresses" as const, label: "Adresses", icon: MapPin },
            { key: "services" as const, label: "Services", icon: Building2 },
            { key: "automations" as const, label: "Préparations", icon: Zap },
            { key: "chat" as const, label: "Parler à Sofia", icon: Bot },
          ]).map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.key;
            return (
              <button
                key={tab.key}
                onClick={() => {
                  setActiveTab(tab.key);
                  if (tab.key === "chat" && !chatOpen) setChatOpen(true);
                }}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium transition-all whitespace-nowrap flex items-center gap-2",
                  isActive
                    ? "bg-primary text-white shadow-md shadow-primary/20"
                    : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                <Icon className={cn("w-3.5 h-3.5", isActive ? "text-white" : "text-muted-foreground")} />
                {tab.label}
                {tab.key === "chat" && chatStep < SOFIA_MESSAGES.length && (
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
                )}
              </button>
            );
          })}
        </div>

        {/* Content */}
        <AnimatePresence mode="wait">
          {activeTab === "overview" && (
            <motion.div key="overview" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <OverviewTab />
            </motion.div>
          )}
          {activeTab === "addresses" && (
            <motion.div key="addresses" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <AddressesTab />
            </motion.div>
          )}
          {activeTab === "services" && (
            <motion.div key="services" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <ServicesTab />
            </motion.div>
          )}
          {activeTab === "automations" && (
            <motion.div key="automations" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <AutomationsTab expandedAuto={expandedAuto} setExpandedAuto={setExpandedAuto} />
            </motion.div>
          )}
          {activeTab === "chat" && (
            <motion.div key="chat" initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}>
              <SofiaDemoChat
                messages={chatMessages}
                typing={chatTyping}
                onSend={sendDemoReply}
              />
            </motion.div>
          )}
        </AnimatePresence>

        {/* CTA Footer */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.6 }}
          className="mt-12 text-center p-8 rounded-2xl border border-dashed border-border/40 bg-muted/[0.03]"
        >
          <p className="text-sm text-muted-foreground mb-4">
            Cette démonstration utilise des données fictives. Créez un compte pour lancer de vraies préparations.
          </p>
          <div className="flex items-center justify-center gap-3">
            <Link href="/sign-up">
              <Button className="gap-2">
                <ArrowRight className="w-4 h-4" />
                Essayer gratuitement
              </Button>
            </Link>
            <Link href="/pricing">
              <Button variant="outline">Voir les tarifs</Button>
            </Link>
          </div>
        </motion.div>
      </main>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════════════ */

function OverviewTab() {
  return (
    <div className="space-y-6">
      {/* KPIs — más honestos, no 100% */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Adresses", value: "2", icon: MapPin, color: "bg-blue-500/10 text-blue-400" },
          { label: "Services", value: "5/6", icon: Building2, color: "bg-violet-500/10 text-violet-400" },
          { label: "Préparations", value: "2", icon: Zap, color: "bg-amber-500/10 text-amber-400" },
          { label: "Taux de réussite", value: "80%", icon: TrendingUp, color: "bg-emerald-500/10 text-emerald-400" },
        ].map((kpi) => {
          const Icon = kpi.icon;
          return (
            <motion.div key={kpi.label}>
              <Card className="p-4 border border-card-border hover:border-primary/15 hover:-translate-y-0.5 transition-all duration-200">
              <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center mb-3", kpi.color.split(" ")[0])}>
                <Icon className={cn("w-4 h-4", kpi.color.split(" ")[1])} />
              </div>
              <p className="text-2xl font-bold">{kpi.value}</p>
              <p className="text-xs text-muted-foreground">{kpi.label}</p>
              </Card>
            </motion.div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Activity */}
        <Card className="p-5 border border-card-border">
          <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
            <Activity className="w-4 h-4 text-primary" />
            Activité récente
          </h3>
          <div className="space-y-3">
            {DEMO_ACTIVITY.map((act, i) => (
              <motion.div
                key={act.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.1 }}
                className="flex items-start gap-3"
              >
                <div className={cn(
                  "w-2 h-2 rounded-full mt-1.5 flex-shrink-0",
                  act.type === "success" ? "bg-emerald-400" :
                  act.type === "warning" ? "bg-amber-400" : "bg-blue-400"
                )} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm leading-snug">{act.text}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{act.time}</p>
                </div>
                {act.type === "warning" && (
                  <Badge variant="outline" className="text-[10px] text-amber-400 border-amber-400/30 flex-shrink-0">
                    Action
                  </Badge>
                )}
              </motion.div>
            ))}
          </div>
        </Card>

        {/* Security */}
        <Card className="p-5 border border-card-border">
          <h3 className="text-sm font-semibold mb-4 flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            Sécurité & transparence
          </h3>
          <div className="space-y-3 text-sm text-muted-foreground">
            {[
              { icon: Lock, text: "Chiffrement AES-256 des données" },
              { icon: ShieldCheck, text: "Hébergé en Europe, conforme RGPD" },
              { icon: Info, text: "Aucun mot de passe stocké" },
              { icon: CheckCircle2, text: "Validation requise à chaque étape" },
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.3 + i * 0.1 }}
                className="flex items-center gap-2"
              >
                <item.icon className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>{item.text}</span>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

function AddressesTab() {
  return (
    <div className="space-y-4">
      {DEMO_ADDRESSES.map((addr, i) => (
        <motion.div
          key={addr.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
        >
          <Card className="p-4 flex items-center gap-4 border border-card-border hover:border-primary/15 transition-all">
            <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center flex-shrink-0">
              <MapPin className="w-5 h-5 text-blue-400" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-0.5">
                <p className="text-sm font-medium">{addr.label}</p>
                {addr.isDefault && (
                  <Badge variant="outline" className="text-[10px] px-1.5 py-0">Par défaut</Badge>
                )}
              </div>
              <p className="text-xs text-muted-foreground">{addr.street}, {addr.postalCode} {addr.city}</p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground/40" />
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

function ServicesTab() {
  const connected = DEMO_SERVICES.filter((s) => s.connected);
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-sm font-semibold mb-3">Connectés ({connected.length})</h3>
        <div className="space-y-3">
          {connected.map((svc, i) => (
            <motion.div
              key={svc.id}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.08 }}
            >
              <Card className="p-4 flex items-center gap-4 border border-card-border hover:border-primary/15 transition-all">
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0",
                  svc.status === "done" ? "bg-emerald-500/10" :
                  svc.status === "action" ? "bg-amber-500/10" :
                  svc.status === "processing" ? "bg-blue-500/10" : "bg-muted"
                )}>
                  <Building2 className={cn("w-5 h-5",
                    svc.status === "done" ? "text-emerald-400" :
                    svc.status === "action" ? "text-amber-400" :
                    svc.status === "processing" ? "text-blue-400" : "text-muted-foreground"
                  )} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{svc.name}</p>
                  <p className="text-xs text-muted-foreground">{svc.category}</p>
                </div>
                <Badge className={cn("text-[10px]",
                  svc.status === "done" ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" :
                  svc.status === "action" ? "bg-amber-500/10 text-amber-400 border-amber-500/20" :
                  svc.status === "processing" ? "bg-blue-500/10 text-blue-400 border-blue-500/20" :
                  "bg-muted/60 text-muted-foreground border-border/50"
                )}>
                  {svc.status === "done" ? "Terminé" :
                   svc.status === "action" ? "Action requise" :
                   svc.status === "processing" ? "En cours" : "Non connecté"}
                </Badge>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AutomationsTab({ expandedAuto, setExpandedAuto }: {
  expandedAuto: number | null;
  setExpandedAuto: (id: number | null) => void;
}) {
  return (
    <div className="space-y-4">
      {DEMO_AUTOMATIONS.map((auto) => (
        <motion.div
          key={auto.id}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="p-5 border border-card-border">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-lg flex items-center justify-center",
                  auto.status === "completed" ? "bg-emerald-500/10" : "bg-amber-500/10"
                )}>
                  <Zap className={cn("w-5 h-5",
                    auto.status === "completed" ? "text-emerald-400" : "text-amber-400"
                  )} />
                </div>
                <div>
                  <p className="text-sm font-medium">Préparation #{auto.id}</p>
                  <p className="text-xs text-muted-foreground">{auto.addressLabel}</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge className={cn("text-[10px]",
                  auto.status === "completed"
                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                    : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                )}>
                  {auto.status === "completed" ? "Terminée" : "En cours"}
                </Badge>
                <button
                  onClick={() => setExpandedAuto(expandedAuto === auto.id ? null : auto.id)}
                  className="w-6 h-6 rounded-full hover:bg-muted flex items-center justify-center text-muted-foreground"
                >
                  {expandedAuto === auto.id ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {/* Progress */}
            <div className="mb-3">
              <div className="flex items-center justify-between text-xs mb-1.5">
                <span className="text-muted-foreground">Progression</span>
                <span className="font-medium">{auto.progressPercent}%</span>
              </div>
              <div className="h-2 rounded-full bg-muted overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${auto.progressPercent}%` }}
                  transition={{ duration: 1.2, ease: "easeOut" }}
                  className={cn(
                    "h-full rounded-full",
                    auto.status === "completed" ? "bg-emerald-400" : "bg-amber-400"
                  )}
                />
              </div>
            </div>

            {/* Summary line */}
            <div className="flex items-center gap-3 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                {auto.completedServices}/{auto.totalServices} services
              </span>
              {auto.failedServices > 0 && (
                <span className="flex items-center gap-1 text-amber-400">
                  <AlertTriangle className="w-3 h-3" />
                  {auto.failedServices} en attente
                </span>
              )}
              {auto.status === "running" && (
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-blue-400" />
                  En traitement
                </span>
              )}
            </div>

            {/* Expanded detail — el "fail" realista */}
            <AnimatePresence>
              {expandedAuto === auto.id && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                  transition={{ duration: 0.3 }}
                  className="overflow-hidden"
                >
                  <div className="mt-4 pt-4 border-t border-border/40 space-y-3">
                    {/* AXA fail — honest and realistic */}
                    <div className="p-3 rounded-xl bg-amber-500/5 border border-amber-500/20">
                      <div className="flex items-start gap-2.5">
                        <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-amber-400">AXA — Justificatif requis</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            AXA n'accepte pas les mises à jour en ligne. Un justificatif de domicile
                            (facture EDF ou gaz de moins de 3 mois) est obligatoire. Sofia a préparé
                            le formulaire pré-rempli — il ne vous reste plus qu'à l'imprimer et l'envoyer.
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge variant="outline" className="text-[10px] text-amber-400 border-amber-400/30">
                              <FileText className="w-3 h-3 mr-1" /> Formulaire pré-rempli
                            </Badge>
                            <Badge variant="outline" className="text-[10px]">
                              Délai: 5-7 jours ouvrés
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* EDF processing — realistic timeline */}
                    <div className="p-3 rounded-xl bg-blue-500/5 border border-blue-500/20">
                      <div className="flex items-start gap-2.5">
                        <Clock className="w-4 h-4 text-blue-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-blue-400">EDF — En cours de traitement</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            La demande a été transmise. EDF traite les changements d'adresse
                            en 24-48h. Vous recevrez un e-mail de confirmation.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Success examples */}
                    <div className="p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
                      <div className="flex items-start gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm font-medium text-emerald-400">Orange, BNP, La Poste — Validés</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            3 organismes mis à jour avec succès. Les nouvelles adresses sont
                            actives dès maintenant.
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </Card>
        </motion.div>
      ))}
    </div>
  );
}

/* ═════════════════════ SOFIA MINI-CHAT ══════════════════════════════════════════ */

function SofiaDemoChat({ messages, typing, onSend }: {
  messages: { type: "bot" | "user"; text: string }[];
  typing: boolean;
  onSend: (text: string) => void;
}) {
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (bottomRef.current) bottomRef.current.scrollIntoView({ behavior: "smooth" });
  }, [messages, typing]);

  return (
    <div className="max-w-lg mx-auto">
      <Card className="border border-card-border overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-border/40 bg-gradient-to-r from-primary/5 to-violet-500/5">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center">
              <Bot className="w-4.5 h-4.5 text-white" />
            </div>
            <div>
              <p className="text-sm font-semibold">Sofia</p>
              <p className="text-xs text-muted-foreground">Assistant Serenya · En ligne</p>
            </div>
            <div className="ml-auto flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-[10px] text-emerald-400">En ligne</span>
            </div>
          </div>
        </div>

        {/* Messages */}
        <div className="p-4 h-80 overflow-y-auto space-y-3 bg-muted/20">
          {messages.length === 0 && !typing && (
            <div className="text-center py-12">
              <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-3">
                <Sparkles className="w-6 h-6 text-primary" />
              </div>
              <p className="text-sm text-muted-foreground">Sofia arrive...</p>
            </div>
          )}

          {messages.map((msg, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn(
                "flex gap-2.5",
                msg.type === "user" ? "flex-row-reverse" : "flex-row"
              )}
            >
              {msg.type === "bot" && (
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-3.5 h-3.5 text-white" />
                </div>
              )}
              <div className={cn(
                "px-3 py-2 rounded-2xl text-sm max-w-[80%] leading-relaxed",
                msg.type === "bot"
                  ? "bg-card border border-border/40 rounded-tl-sm"
                  : "bg-primary text-white rounded-tr-sm"
              )}>
                {msg.text}
              </div>
            </motion.div>
          ))}

          {typing && (
            <div className="flex items-center gap-2 px-3 py-2">
              <div className="flex gap-1">
                {[0, 1, 2].map(i => (
                  <motion.div
                    key={i}
                    className="w-1.5 h-1.5 rounded-full bg-primary"
                    animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.1, 0.8] }}
                    transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </div>
              <span className="text-xs text-primary/60">Sofia écrit...</span>
            </div>
          )}
          <div ref={bottomRef} />
        </div>

        {/* Input */}
        <div className="p-3 border-t border-border/40 bg-card">
          <div className="flex gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && input.trim()) {
                  onSend(input.trim());
                  setInput("");
                }
              }}
              placeholder="Posez une question à Sofia..."
              className="flex-1 px-3 py-2 rounded-xl bg-muted/50 border border-border/40 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20"
            />
            <Button
              size="sm"
              className="gap-1"
              disabled={!input.trim() || typing}
              onClick={() => {
                if (input.trim()) {
                  onSend(input.trim());
                  setInput("");
                }
              }}
            >
              <Send className="w-3.5 h-3.5" />
            </Button>
          </div>
          <p className="text-[10px] text-muted-foreground/50 mt-2 text-center">
            Cette démo utilise des réponses prédéfinies. Le vrai Sofia est bien plus intelligent.
          </p>
        </div>
      </Card>
    </div>
  );
}
