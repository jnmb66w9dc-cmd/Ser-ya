import AppLayout from "@/components/AppLayout";
import TaskCenter from "@/components/TaskCenter";
import { ListChecks, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { motion } from "@/lib/motion-compat";

export default function TasksPage() {
  return (
    <AppLayout title="Tâches">
      <div className="max-w-3xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
              <ArrowLeft className="w-3.5 h-3.5" /> Retour
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Tâches administratives</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              Toutes les actions à réaliser pour finaliser vos démarches de changement d&apos;adresse.
            </p>
          </div>
        </motion.div>

        <TaskCenter />
      </div>
    </AppLayout>
  );
}
