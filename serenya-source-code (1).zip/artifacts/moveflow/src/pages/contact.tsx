import { Link } from "wouter";
import { ArrowLeft, Mail, MessageCircle, Clock, Shield, Send, ArrowUpRight, HelpCircle, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { useAutoSave, clearAutoSave } from "@/hooks/useAutoSave";
import { useBeforeUnload } from "@/hooks/useBeforeUnload";

const FAQS = [
  {
    q: "Qu'est-ce que Serenya exactement ?",
    a: "Serenya est un assistant administratif qui prépare et guide vos démarches de changement d'adresse. Vous saisissez votre nouvelle adresse une fois, sélectionnez vos organismes, et Serenya génère les démarches personnalisées pour chacun. Vous validez chaque étape.",
  },
  {
    q: "Comment puis-je commencer ?",
    a: "Créez un compte gratuit, ajoutez votre nouvelle adresse, connectez vos organismes (banque, assurance, opérateur…) et lancez votre première préparation depuis le tableau de bord. L'assistant Sofia vous guide étape par étape.",
  },
  {
    q: "Serenya est-il vraiment gratuit ?",
    a: "Oui, le plan Essentiel est gratuit à vie avec 2 préparations par mois et 5 services connectés. Le plan Pro (9.99 €/mois) offre des préparations illimitées et l'assistant Sofia prioritaire.",
  },
  {
    q: "Mes données sont-elles sécurisées ?",
    a: "Absolument. Vos données sont chiffrées (AES-256), hébergées en Europe, et nous sommes conformes RGPD. Nous ne stockons jamais vos mots de passe et ne partageons aucune donnée avec des tiers.",
  },
  {
    q: "Puis-je annuler une préparation en cours ?",
    a: "Oui, à tout moment. Depuis la page Préparations, vous pouvez interrompre une préparation en cours. Les démarches déjà transmises restent chez l'organisme concerné.",
  },
  {
    q: "Quels organismes sont pris en charge ?",
    a: "Serenya couvre 25 organismes français : banques (BNP, Société Générale, Crédit Mutuel...), assurances, opérateurs (Orange, SFR, Free, Bouygues), e-commerce (Amazon, Cdiscount), et services publics (CPAM, CAF, impôts...).",
  },
];

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [draftRecovered, setDraftRecovered] = useState(false);

  // Auto-save draft every 500ms of inactivity
  useAutoSave({
    key: "contact_form",
    data: { name, email, subject, message },
    onRestore: (saved) => {
      setName(saved.name as string ?? "");
      setEmail(saved.email as string ?? "");
      setSubject(saved.subject as string ?? "");
      setMessage(saved.message as string ?? "");
      setDraftRecovered(true);
    },
  });

  // Warn before closing with unsaved changes
  const hasUnsaved = !submitted && Boolean(name.trim() || email.trim() || subject.trim() || message.trim());
  useBeforeUnload(hasUnsaved);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !message.trim()) return;
    setSubmitted(true);
    clearAutoSave("contact_form");
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="max-w-5xl mx-auto px-5 sm:px-8 h-14 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Accueil
          </Link>
          <div className="h-4 w-px bg-border" />
          <span className="text-sm font-medium">Contact & Support</span>
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-5 sm:px-8 py-12 sm:py-16">
        {/* Draft recovery banner */}
        {draftRecovered && (
          <div className="mb-6 p-3 rounded-xl bg-primary/8 border border-primary/15 flex items-center gap-3 text-sm">
            <Shield className="w-4 h-4 text-primary flex-shrink-0" />
            <span className="text-primary/80">
              Vos modifications ont été automatiquement sauvegardées. Vous pouvez continuer où vous vous étiez arrêté.
            </span>
            <button
              onClick={() => { clearAutoSave("contact_form"); setDraftRecovered(false); setName(""); setEmail(""); setSubject(""); setMessage(""); }}
              className="ml-auto text-xs text-muted-foreground hover:text-foreground underline"
            >
              Effacer
            </button>
          </div>
        )}

        {/* Header */}
        <div className="text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted border border-border/50 text-muted-foreground text-xs font-medium mb-5">
            <MessageCircle className="w-3.5 h-3.5" />
            À votre écoute
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight mb-4">
            Comment pouvons-nous vous aider ?
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto leading-relaxed">
            Notre équipe répond en moins de 4 heures en semaine. Pour une réponse immédiate, consultez la FAQ ci-dessous.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 lg:gap-12">
          {/* Contact info cards */}
          <div className="lg:col-span-2 space-y-4">
            <div className="p-5 rounded-2xl bg-card/40 border border-border/40">
              <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center mb-3">
                <Mail className="w-4 h-4 text-primary" />
              </div>
              <h3 className="font-semibold text-sm mb-1">Email</h3>
              <p className="text-xs text-muted-foreground mb-2">Réponse garantie sous 4h (lu-ve)</p>
              <a href="mailto:bonjour@serenya.fr" className="text-sm text-primary hover:underline inline-flex items-center gap-1">
                bonjour@serenya.fr <ArrowUpRight className="w-3 h-3" />
              </a>
            </div>

            <div className="p-5 rounded-2xl bg-card/40 border border-border/40">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-3">
                <Clock className="w-4 h-4 text-emerald-400" />
              </div>
              <h3 className="font-semibold text-sm mb-1">Disponibilité</h3>
              <p className="text-xs text-muted-foreground">
                Lun–Ven 9h–18h (CET)<br />
                Week-end : support automatique via l'assistant Sofia
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-card/40 border border-border/40">
              <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center mb-3">
                <Shield className="w-4 h-4 text-violet-400" />
              </div>
              <h3 className="font-semibold text-sm mb-1">Confidentialité</h3>
              <p className="text-xs text-muted-foreground mb-2">
                Vos messages sont chiffrés et lus uniquement par notre équipe interne.
              </p>
              <Link href="/confidentialite" className="text-xs text-primary hover:underline inline-flex items-center gap-1">
                Notre politique <ArrowUpRight className="w-3 h-3" />
              </Link>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3">
            {submitted ? (
              <div className="p-8 rounded-2xl bg-card/40 border border-border/40 text-center">
                <div className="w-14 h-14 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto mb-4">
                  <Send className="w-6 h-6 text-emerald-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Message envoyé</h3>
                <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto leading-relaxed">
                  Merci de nous avoir contactés. Notre équipe vous répondra dans les meilleurs délais — en général sous 2 heures en semaine.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <Button variant="outline" onClick={() => setSubmitted(false)}>
                    Nouveau message
                  </Button>
                  <Link href="/dashboard">
                    <Button>Aller au tableau de bord</Button>
                  </Link>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="p-6 sm:p-8 rounded-2xl bg-card/40 border border-border/40 space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">Nom (optionnel)</label>
                    <Input
                      value={name}
                      onChange={e => setName(e.target.value)}
                      placeholder="Votre nom"
                      className="h-11 bg-background/50"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <label className="text-xs font-medium text-muted-foreground">Email <span className="text-red-400">*</span></label>
                    <Input
                      type="email"
                      value={email}
                      onChange={e => setEmail(e.target.value)}
                      placeholder="votre@email.com"
                      required
                      className="h-11 bg-background/50"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Sujet</label>
                  <Input
                    value={subject}
                    onChange={e => setSubject(e.target.value)}
                    placeholder="Pourquoi nous écrivez-vous ?"
                    className="h-11 bg-background/50"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground">Message <span className="text-red-400">*</span></label>
                  <Textarea
                    value={message}
                    onChange={e => setMessage(e.target.value)}
                    placeholder="Décrivez votre question ou problème en détail..."
                    required
                    rows={5}
                    className="bg-background/50 resize-none"
                  />
                </div>
                <Button type="submit" className="w-full h-11" disabled={!email.trim() || !message.trim()}>
                  <Send className="w-4 h-4 mr-2" />
                  Envoyer le message
                </Button>
                <p className="text-[11px] text-muted-foreground/50 text-center">
                  En envoyant ce message, vous acceptez que nous utilisions votre email pour vous répondre. Voir notre{" "}
                  <Link href="/confidentialite" className="underline hover:text-foreground">politique de confidentialité</Link>.
                </p>
              </form>
            )}
          </div>
        </div>

        {/* FAQ */}
        <div className="mt-16 sm:mt-20">
          <div className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-muted border border-border/50 text-muted-foreground text-xs font-medium mb-4">
              <HelpCircle className="w-3.5 h-3.5" />
              Questions fréquentes
            </div>
            <h2 className="text-2xl font-bold">Réponses rapides</h2>
          </div>

          <div className="max-w-2xl mx-auto space-y-3">
            {FAQS.map((faq, i) => (
              <div
                key={i}
                className="rounded-xl border border-border/40 bg-card/30 overflow-hidden transition-all duration-200"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === i ? null : i)}
                  className="w-full flex items-center justify-between px-5 py-4 text-left hover:bg-muted/20 transition-colors"
                >
                  <span className="text-sm font-medium pr-4">{faq.q}</span>
                  <span className={`text-muted-foreground transition-transform duration-200 flex-shrink-0 ${openFaq === i ? "rotate-180" : ""}`}>
                    <ChevronDown className="w-4 h-4" />
                  </span>
                </button>
                {openFaq === i && (
                  <div className="px-5 pb-4 text-sm text-muted-foreground leading-relaxed border-t border-border/30 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* Simple footer */}
      <footer className="border-t border-border/20 py-8 px-5 sm:px-8">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-muted-foreground/50">
          <p>© 2025 Serenya. Tous droits réservés.</p>
          <div className="flex items-center gap-4">
            <Link href="/confidentialite" className="hover:text-muted-foreground transition-colors">Confidentialité</Link>
            <Link href="/cgu" className="hover:text-muted-foreground transition-colors">CGU</Link>
            <Link href="/" className="hover:text-muted-foreground transition-colors">Accueil</Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
