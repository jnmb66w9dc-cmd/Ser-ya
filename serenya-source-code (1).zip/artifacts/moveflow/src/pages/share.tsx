import { useState, useEffect, useCallback } from "react";
import { useParams } from "wouter";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import {
  Sparkles, CheckCircle2, Loader2, Clock, XCircle,
  Minus, Shield, RefreshCw, ExternalLink, Lock,
} from "lucide-react";
import { cn } from "@/lib/utils";

type ShareTask = {
  serviceName: string;
  logoUrl: string | null;
  status: "queued" | "running" | "completed" | "failed" | "skipped";
  completedAt: string | null;
};

type ShareProgress = {
  token: string;
  firstName: string | null;
  status: "queued" | "running" | "completed" | "partial" | "failed" | "cancelled";
  progressPercent: number;
  totalServices: number;
  completedServices: number;
  failedServices: number;
  tasks: ShareTask[];
  createdAt: string;
  completedAt: string | null;
};

function ProgressRing({ percent, size = 148, stroke = 11 }: { percent: number; size?: number; stroke?: number }) {
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percent / 100) * circumference;
  return (
    <svg width={size} height={size} className="-rotate-90" aria-hidden>
      <circle cx={size / 2} cy={size / 2} r={radius} fill="none"
        stroke="currentColor" strokeWidth={stroke} className="text-muted/40" />
      <motion.circle cx={size / 2} cy={size / 2} r={radius} fill="none"
        stroke="hsl(var(--primary))" strokeWidth={stroke} strokeLinecap="round"
        strokeDasharray={circumference}
        initial={{ strokeDashoffset: circumference }}
        animate={{ strokeDashoffset: offset }}
        transition={{ duration: 1.4, ease: "easeOut" }} />
    </svg>
  );
}

const STATUS_CONFIG = {
  queued:    { label: "En file d'attente",                         color: "text-muted-foreground", bar: "bg-muted/40 border-border/30",    dot: "bg-muted-foreground" },
  running:   { label: "En cours de traitement",                    color: "text-primary",           bar: "bg-primary/8 border-primary/20",  dot: "bg-primary animate-pulse" },
  completed: { label: "Toutes les démarches sont prêtes",       color: "text-emerald-400",       bar: "bg-emerald-500/8 border-emerald-500/20", dot: "bg-emerald-500" },
  partial:   { label: "Certaines démarches nécessitent attention", color: "text-amber-400",         bar: "bg-amber-500/8 border-amber-500/20",     dot: "bg-amber-500" },
  failed:    { label: "Des démarches ont rencontré un problème",   color: "text-red-400",           bar: "bg-red-500/8 border-red-500/20",         dot: "bg-red-500" },
  cancelled: { label: "Préparation annulée",                    color: "text-muted-foreground",  bar: "bg-muted/20 border-border/20",           dot: "bg-muted-foreground" },
} as const;

const TASK_CONFIG = {
  completed: { Icon: CheckCircle2, color: "text-emerald-400",       label: "Prêt",                  spin: false },
  running:   { Icon: Loader2,      color: "text-blue-400",          label: "En cours",              spin: true  },
  queued:    { Icon: Clock,        color: "text-muted-foreground",  label: "En attente",            spin: false },
  failed:    { Icon: XCircle,      color: "text-red-400",           label: "Intervention requise",  spin: false },
  skipped:   { Icon: Minus,        color: "text-muted-foreground/40", label: "Ignoré",              spin: false },
} as const;

export default function SharePage() {
  const params = useParams<{ token: string }>();
  const token = params.token ?? "";

  const [data, setData]       = useState<ShareProgress | null>(null);
  const [error, setError]     = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshed, setRefreshed] = useState<Date>(new Date());

  const fetchData = useCallback(async () => {
    try {
      const base = (import.meta.env.BASE_URL ?? "").replace(/\/$/, "");
      const res  = await fetch(`${base}/api/share/public/${token}`);
      if (!res.ok) {
        setError(res.status === 404
          ? "Ce lien de partage n'existe plus ou a été désactivé."
          : "Une erreur est survenue. Réessayez plus tard.");
        return;
      }
      setData(await res.json());
      setError(null);
      setRefreshed(new Date());
    } catch {
      setError("Impossible de charger les données. Vérifiez votre connexion.");
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    if (!data || (data.status !== "running" && data.status !== "queued")) return;
    const id = setInterval(fetchData, 10_000);
    return () => clearInterval(id);
  }, [data, fetchData]);

  const isLive   = data?.status === "running" || data?.status === "queued";
  const statusCfg = data ? STATUS_CONFIG[data.status] : null;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* ── Header ────────────────────────────────── */}
      <header className="flex items-center justify-between px-6 py-4 border-b border-border/30 flex-shrink-0">
        <a href="/" className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center shadow-lg shadow-primary/30">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold text-base tracking-tight">Serenya</span>
        </a>
        {isLive && (
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground/50">
            <RefreshCw className="w-3 h-3 animate-spin" />
            Actualisation automatique
          </div>
        )}
      </header>

      {/* ── Main ──────────────────────────────────── */}
      <main className="flex-1 flex items-start justify-center px-4 py-10">
        <div className="w-full max-w-md">
          <AnimatePresence mode="wait">

            {/* Loading */}
            {loading && (
              <motion.div key="loading"
                initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="flex flex-col items-center py-24 gap-3">
                <Loader2 className="w-8 h-8 text-primary/40 animate-spin" />
                <p className="text-sm text-muted-foreground">Chargement…</p>
              </motion.div>
            )}

            {/* Error */}
            {!loading && error && (
              <motion.div key="error"
                initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
                className="rounded-2xl border border-border/40 bg-card p-10 text-center space-y-3">
                <Shield className="w-10 h-10 text-muted-foreground/25 mx-auto" />
                <p className="font-semibold">Lien introuvable</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{error}</p>
                <a href="/"
                  className="inline-flex items-center gap-1.5 text-xs text-primary hover:text-primary/80 transition-colors mt-2">
                  <ExternalLink className="w-3.5 h-3.5" /> Découvrir Serenya
                </a>
              </motion.div>
            )}

            {/* Data */}
            {!loading && data && statusCfg && (
              <motion.div key="data"
                initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }}
                className="space-y-3">

                {/* Title */}
                <div className="text-center mb-1">
                  <h1 className="text-xl font-bold">
                    {data.firstName ? `Déménagement de ${data.firstName}` : "Suivi de déménagement"}
                  </h1>
                  <p className="text-xs text-muted-foreground/50 mt-1">
                    Mis à jour à {refreshed.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                </div>

                {/* Progress card */}
                <div className="rounded-2xl border border-border/40 bg-card overflow-hidden">
                  {/* Status banner */}
                  <div className={cn("flex items-center gap-2.5 px-5 py-3 border-b border-border/30", statusCfg.bar)}>
                    <div className={cn("w-2 h-2 rounded-full flex-shrink-0", statusCfg.dot)} />
                    <span className={cn("text-sm font-medium", statusCfg.color)}>{statusCfg.label}</span>
                  </div>

                  {/* Ring */}
                  <div className="flex flex-col items-center py-8 gap-3">
                    <div className="relative">
                      <ProgressRing percent={data.progressPercent} />
                      <div className="absolute inset-0 flex flex-col items-center justify-center">
                        <span className="text-3xl font-bold tabular-nums">{data.progressPercent}%</span>
                        <span className="text-xs text-muted-foreground/50">complété</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground text-center">
                      <span className="font-semibold text-foreground">{data.completedServices}</span>
                      {" "}sur{" "}
                      <span className="font-semibold text-foreground">{data.totalServices}</span>
                      {" "}services mis à jour
                    </p>
                    {data.failedServices > 0 && (
                      <p className="text-xs text-amber-400/80">
                        {data.failedServices} service(s) nécessitent une intervention directe
                      </p>
                    )}
                  </div>
                </div>

                {/* Tasks list */}
                {data.tasks.length > 0 && (
                  <div className="rounded-2xl border border-border/40 bg-card overflow-hidden">
                    <div className="px-5 py-3.5 border-b border-border/25">
                      <h2 className="text-sm font-semibold">Services</h2>
                    </div>
                    <div className="divide-y divide-border/20">
                      {data.tasks.map((task, i) => {
                        const cfg = TASK_CONFIG[task.status];
                        return (
                          <motion.div key={i}
                            initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                            transition={{ delay: i * 0.04 }}
                            className="flex items-center gap-3 px-5 py-3.5">
                            {task.logoUrl ? (
                              <img src={task.logoUrl} alt={task.serviceName}
                                className="w-7 h-7 rounded-lg object-contain bg-white/5 flex-shrink-0" />
                            ) : (
                              <div className="w-7 h-7 rounded-lg bg-muted/30 flex-shrink-0" />
                            )}
                            <span className="text-sm font-medium flex-1 truncate">{task.serviceName}</span>
                            <div className="flex items-center gap-1.5 flex-shrink-0">
                              <cfg.Icon className={cn("w-3.5 h-3.5", cfg.color, cfg.spin && "animate-spin")} />
                              <span className={cn("text-xs", cfg.color)}>{cfg.label}</span>
                            </div>
                          </motion.div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Privacy notice */}
                <div className="flex items-start gap-3 px-4 py-3.5 rounded-xl bg-muted/10 border border-border/25">
                  <Lock className="w-3.5 h-3.5 text-muted-foreground/40 flex-shrink-0 mt-0.5" />
                  <p className="text-xs text-muted-foreground/50 leading-relaxed">
                    <span className="font-medium text-muted-foreground/70">Données protégées.</span>{" "}
                    Cette page ne contient aucune adresse, aucun identifiant ni aucun document personnel sensible.
                  </p>
                </div>

                {/* Reassurance */}
                <p className="text-center text-xs text-muted-foreground/30 pb-2">
                  Aucune action n'est effectuée sans l'accord explicite de la personne concernée.
                </p>
              </motion.div>
            )}

          </AnimatePresence>
        </div>
      </main>

      {/* ── Footer ────────────────────────────────── */}
      <footer className="px-6 py-4 border-t border-border/20 text-center">
        <p className="text-xs text-muted-foreground/30">
          Propulsé par{" "}
          <a href="/" className="hover:text-muted-foreground/60 transition-colors">Serenya</a>
          {" "}· Assistant administratif IA
        </p>
      </footer>
    </div>
  );
}
