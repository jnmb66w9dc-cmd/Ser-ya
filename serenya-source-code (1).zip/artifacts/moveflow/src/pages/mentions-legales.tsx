import { Link } from "wouter";
import { ArrowLeft, Building2, Mail, Globe, Server, Scale, Shield } from "lucide-react";

export default function MentionsLegalesPage() {
  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-6 h-14 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Retour
          </Link>
          <div className="h-4 w-px bg-border" />
          <span className="text-sm font-medium">Mentions légales</span>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-16">
        <div className="mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/10 text-amber-400 text-xs font-medium mb-6 border border-amber-400/20">
            <Scale className="w-3.5 h-3.5" />
            Conforme LCEN n°2004-575
          </div>
          <h1 className="text-4xl font-bold tracking-tight mb-4">Mentions légales</h1>
          <p className="text-muted-foreground text-lg leading-relaxed max-w-2xl">
            Informations obligatoires concernant l'éditeur et l'hébergeur du service Serenya, conformément à l'article 6 de la loi pour la confiance dans l'économie numérique (LCEN).
          </p>
          <p className="text-xs text-muted-foreground/50 mt-4">
            Dernière mise à jour : 25 mai 2026
          </p>
        </div>

        <div className="space-y-10">
          {/* Editeur */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Building2 className="w-4 h-4 text-primary" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Éditeur du service</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p><strong className="text-foreground">Serenya</strong> — Application de gestion de changement d'adresse</p>
                  <p>Le service est actuellement en phase de test bêta publique.</p>
                  <p>Contact : <a href="mailto:contact@serenya.replit.app" className="text-primary hover:underline">contact@serenya.replit.app</a></p>
                </div>
              </div>
            </div>
            <div className="mt-8 border-b border-border/30" />
          </section>

          {/* Hebergeur */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Server className="w-4 h-4 text-violet-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Hébergeur</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p><strong className="text-foreground">Replit, Inc.</strong></p>
                  <p>548 Market Street, Suite 47382, San Francisco, CA 94104, États-Unis</p>
                  <p>Site web : <a href="https://replit.com" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">replit.com</a></p>
                  <p className="text-xs text-muted-foreground/60 mt-2">
                    L'infrastructure est hébergée sur des serveurs cloud gérés par Replit, avec des mesures de sécurité et de confidentialité conformes au RGPD (Clauses Contractuelles Types / Standard Contractual Clauses).
                  </p>
                </div>
              </div>
            </div>
            <div className="mt-8 border-b border-border/30" />
          </section>

          {/* Directeur publication */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Shield className="w-4 h-4 text-emerald-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Directeur de la publication</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p>Responsable de la publication : <strong className="text-foreground">L'équipe Serenya</strong></p>
                  <p>Contact : <a href="mailto:contact@serenya.replit.app" className="text-primary hover:underline">contact@serenya.replit.app</a></p>
                </div>
              </div>
            </div>
            <div className="mt-8 border-b border-border/30" />
          </section>

          {/* Propriete intellectuelle */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Scale className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Propriété intellectuelle</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p>L'ensemble du contenu du site Serenya (textes, graphismes, logiciels, bases de données, marques, logos) est la propriété exclusive de Serenya.</p>
                  <p>Toute reproduction, représentation, modification, publication, adaptation de tout ou partie des éléments du site, quel que soit le moyen ou le procédé utilisé, est interdite, sauf autorisation écrite préalable.</p>
                  <p>Toute exploitation non autorisée du site ou de l'un des éléments qu'il contient sera considérée comme constitutive d'une contrefaçon et poursuivie conformément aux dispositions des articles L.335-2 et suivants du Code de la propriété intellectuelle.</p>
                </div>
              </div>
            </div>
            <div className="mt-8 border-b border-border/30" />
          </section>

          {/* Donnees personnelles */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Globe className="w-4 h-4 text-blue-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Données personnelles</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p>Serenya collecte et traite des données personnelles dans le respect du RGPD et de la loi Informatique et Libertés.</p>
                  <p>Pour plus d'informations, consultez notre <Link href="/confidentialite" className="text-primary hover:underline">Politique de confidentialité</Link>.</p>
                  <p>Pour exercer vos droits (accès, rectification, suppression, portabilité) : <a href="mailto:contact@serenya.replit.app" className="text-primary hover:underline">contact@serenya.replit.app</a></p>
                </div>
              </div>
            </div>
            <div className="mt-8 border-b border-border/30" />
          </section>

          {/* Cookies */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-pink-500/10 border border-pink-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Mail className="w-4 h-4 text-pink-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Cookies et traceurs</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p>Serenya utilise uniquement des cookies strictement nécessaires au fonctionnement du service (authentification, préférences, sécurité).</p>
                  <p>Aucun cookie publicitaire ni tracker tiers n'est utilisé.</p>
                  <p>Vous pouvez gérer vos préférences depuis les <Link href="/settings" className="text-primary hover:underline">Paramètres</Link> de l'application.</p>
                </div>
              </div>
            </div>
            <div className="mt-8 border-b border-border/30" />
          </section>

          {/* Litiges */}
          <section className="group">
            <div className="flex items-start gap-4">
              <div className="w-9 h-9 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                <Scale className="w-4 h-4 text-red-400" />
              </div>
              <div>
                <h2 className="text-lg font-semibold mb-3">Règlement des litiges</h2>
                <div className="text-sm text-muted-foreground leading-relaxed space-y-2">
                  <p>Conformément à l'article L.616-1 du Code de la consommation, en cas de litige, vous pouvez recourir gratuitement au médiateur de la consommation compétent :</p>
                  <p><a href="https://www.cnil.fr" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">CNIL — cnil.fr</a> (pour les questions de données personnelles)</p>
                  <p>Vous pouvez également soumettre votre réclamation via la plateforme de règlement en ligne des litiges de l'UE : <a href="https://ec.europa.eu/consumers/odr" target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">ec.europa.eu/consumers/odr</a></p>
                </div>
              </div>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
