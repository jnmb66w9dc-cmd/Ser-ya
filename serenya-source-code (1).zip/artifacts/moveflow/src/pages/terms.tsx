import { Link } from "wouter";
import { ArrowLeft, FileText } from "lucide-react";

const ARTICLES = [
  {
    number: "1",
    title: "Objet et acceptation",
    content: `Les présentes Conditions Générales d'Utilisation (CGU) régissent l'accès et l'utilisation du service Serenya, accessible à l'adresse serenya.fr, édité par Serenya SAS.

En créant un compte ou en utilisant le service, vous acceptez sans réserve les présentes CGU. Si vous n'acceptez pas ces conditions, vous ne pouvez pas utiliser le service.`,
  },
  {
    number: "2",
    title: "Description du service",
    content: `Serenya est un assistant administratif qui prépare et guide les démarches de changement d'adresse auprès de vos organismes (banques, assurances, opérateurs télécom, e-commerce, services gouvernementaux, etc.).

Le service est disponible en mode SaaS (Software as a Service) via abonnement mensuel ou annuel. Serenya propose une offre gratuite avec fonctionnalités limitées et des offres payantes avec des capacités étendues.`,
  },
  {
    number: "3",
    title: "Création de compte et conditions d'accès",
    content: `Pour utiliser Serenya, vous devez :
• Avoir au moins 18 ans ou la majorité légale dans votre pays de résidence
• Fournir des informations exactes et à jour lors de votre inscription
• Maintenir la confidentialité de vos identifiants de connexion
• Disposer d'une adresse e-mail valide

Vous êtes responsable de toutes les activités réalisées depuis votre compte. Toute utilisation frauduleuse devra être immédiatement signalée à support@serenya.fr.`,
  },
  {
    number: "4",
    title: "Abonnements et facturation",
    content: `Les abonnements payants sont facturés d'avance, mensuellement ou annuellement selon votre choix. Les tarifs sont indiqués TTC sur la page Tarifs.

L'abonnement est automatiquement renouvelé à chéance sauf résiliation préalable. Vous pouvez résilier à tout moment depuis les Paramètres → Abonnement. La résiliation prend effet à la fin de la période en cours.

Conformément à l'article L221-28 du Code de la consommation, en raison de la nature des services numériques, le droit de rétractation de 14 jours ne s'applique pas une fois l'accès au service activé.`,
  },
  {
    number: "5",
    title: "Utilisation acceptable",
    content: `Vous vous engagez à utiliser Serenya uniquement pour vos propres démarches administratives légitimes. Il est notamment interdit de :

• Utiliser le service au nom d'une tierce personne sans mandat légal
• Fournir des informations d'adresse fausses ou trompeuses
• Tenter de contourner les mécanismes de sécurité du service
• Effectuer des actes de phishing, fraude ou usurpation d'identité
• Scraper, extraire ou reproduire le service par des moyens automatisés non autorisés`,
  },
  {
    number: "6",
    title: "Responsabilité et limitation",
    content: `Serenya s'efforce de fournir un service de haute qualité avec un taux de succès cible de 90%. Cependant, certains organismes peuvent rejeter ou ignorer des demandes préparées indépendamment de notre volonté.

La responsabilité de Serenya est limitée au montant des sommes versées par l'utilisateur au cours des 12 derniers mois précédant l'incident. Serenya ne saurait être tenu responsable des délais de traitement propres à chaque organisme.`,
  },
  {
    number: "7",
    title: "Propriété intellectuelle",
    content: `Tous les éléments du service Serenya (interface, code, marques, logos, contenus, bases de données, algorithmes) sont la propriété exclusive de Serenya et sont protégés par le droit de la propriété intellectuelle.

Toute reproduction, représentation, modification, adaptation ou exploitation totale ou partielle, par quelque procédé que ce soit, sans autorisation écrite préalable, est interdite et pourra faire l'objet de poursuites judiciaires conformément aux articles L.335-2 et suivants du Code de la propriété intellectuelle.`,
  },
  {
    number: "8",
    title: "Résiliation et suspension",
    content: `Serenya se réserve le droit de suspendre ou résilier votre accès en cas de violation des présentes CGU, avec notification préalable sauf cas de fraude avérée.

En cas de résiliation, vos données sont conservées 90 jours pour vous permettre d'en demander l'export (RGPD Art. 20), puis définitivement supprimées conformément à notre politique de confidentialité.

Vous pouvez résilier votre compte à tout moment depuis les Paramètres → Zone de danger → Supprimer mon compte.`,
  },
  {
    number: "9",
    title: "Droit applicable et litiges",
    content: `Les présentes CGU sont soumises au droit français. En cas de litige, les parties s'engagent à rechercher une solution amiable avant toute action judiciaire.

À défaut d'accord amiable, tout litige sera soumis aux tribunaux compétents de Paris, France.

Conformément à l'article L616-1 du Code de la consommation, vous pouvez recourir gratuitement au médiateur de la consommation. Pour toute question : contact@serenya.replit.app.`,
  },
  {
    number: "10",
    title: "Force majeure",
    content: `Serenya ne pourra être tenu responsable en cas d'inexécution ou de retard dans l'exécution de ses obligations résultant d'un événement de force majeure au sens de l'article 1218 du Code civil (grèves, catastrophes naturelles, pandémie, interruption des services Internet, attaques informatiques majeures, etc.).

En cas de survenance d'un événement de force majeure, Serenya informera les utilisateurs dans les meilleurs délais et mettra tout en œuvre pour rétablir le service.`,
  },
  {
    number: "11",
    title: "Modification des CGU",
    content: `Serenya se réserve le droit de modifier les présentes CGU à tout moment. Les modifications entrent en vigueur dès leur publication sur le site.

Les utilisateurs seront informés des modifications substantielles par e-mail ou notification in-app. L'utilisation continue du service après modification vaut acceptation des nouvelles CGU.`,
  },
  {
    number: "12",
    title: "Sous-traitance et traitement des données",
    content: `Serenya peut faire appel à des sous-traitants pour l'hébergement, l'authentification, le paiement et le traitement des données. Les principaux sous-traitants sont :

• Replit (hébergement cloud)
• Clerk (authentification et gestion des utilisateurs)
• Stripe (paiement sécurisé)
• Anthropic (traitement IA des demandes)

Tous les sous-traitants respectent le RGPD et disposent de contrats de traitement des données conformes.`,
  },
  {
    number: "13",
    title: "Cession des droits",
    content: `Serenya se réserve le droit de céder, transférer ou novier tout ou partie des droits et obligations découlant des présentes CGU à un tiers, notamment dans le cadre d'une fusion, acquisition, restructuration ou vente d'actifs, sous réserve que le cessionnaire s'engage à respecter les présentes CGU et la politique de confidentialité.`,
  },
  {
    number: "14",
    title: "Droits RGPD de l'utilisateur",
    content: `Conformément au Règlement Général sur la Protection des Données (RGPD), vous disposez des droits suivants :

• Droit d'accès (Art. 15) : obtenir une copie de vos données personnelles
• Droit de rectification (Art. 16) : corriger des données inexactes
• Droit à l'effacement (Art. 17) : demander la suppression de vos données via Paramètres → Supprimer mon compte
• Droit à la portabilité (Art. 20) : exporter vos données au format CSV ou JSON
• Droit d'opposition (Art. 21) : vous opposer au traitement de vos données
• Droit à la limitation du traitement (Art. 18)
• Droit de ne pas faire l'objet d'une décision automatisée (Art. 22)

Pour exercer vos droits : contact@serenya.replit.app. Réponse sous 30 jours maximum.`,
  },
];

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-6 h-14 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Retour
          </Link>
          <div className="h-4 w-px bg-border" />
          <span className="text-sm font-medium">Conditions Générales d'Utilisation</span>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-16">
        {/* Header */}
        <div className="mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-muted border border-border/50 text-muted-foreground text-xs font-medium mb-6">
            <FileText className="w-3.5 h-3.5" />
            Document légal
          </div>
          <h1 className="text-4xl font-bold tracking-tight mb-4">Conditions Générales d'Utilisation</h1>
          <p className="text-muted-foreground text-lg leading-relaxed max-w-2xl">
            En utilisant Serenya, vous acceptez les présentes conditions. Prenez le temps de les lire attentivement.
          </p>
          <p className="text-xs text-muted-foreground/50 mt-4">
            Dernière mise à jour : 1er janvier 2025 · Version 2.0
          </p>
        </div>

        {/* Table of contents */}
        <div className="mb-12 p-5 rounded-2xl bg-muted/20 border border-border/40">
          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground/60 mb-3">Sommaire</p>
          <ol className="space-y-1">
            {ARTICLES.map((a) => (
              <li key={a.number}>
                <a href={`#art-${a.number}`} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
                  <span className="text-muted-foreground/40 mr-2">Art. {a.number}</span>
                  {a.title}
                </a>
              </li>
            ))}
          </ol>
        </div>

        {/* Articles */}
        <div className="space-y-10">
          {ARTICLES.map((article) => (
            <section key={article.number} id={`art-${article.number}`}>
              <h2 className="text-lg font-semibold mb-3 flex items-baseline gap-2">
                <span className="text-primary/60 text-sm font-mono">Art. {article.number}</span>
                {article.title}
              </h2>
              <div className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                {article.content}
              </div>
              <div className="mt-8 border-b border-border/30" />
            </section>
          ))}
        </div>

        {/* Footer */}
        <div className="mt-14 p-6 rounded-2xl bg-muted/30 border border-border/40">
          <p className="text-sm text-muted-foreground">
            <strong className="text-foreground font-medium">Serenya</strong> — Service en phase bêta<br />
            Contact : <a href="mailto:contact@serenya.replit.app" className="text-primary hover:underline">contact@serenya.replit.app</a><br />
            Hébergeur : Replit, Inc. (548 Market Street, San Francisco, CA 94104, États-Unis)<br />
            Données hébergées en Europe avec clauses contractuelles types RGPD.
          </p>
        </div>
      </main>
    </div>
  );
}
