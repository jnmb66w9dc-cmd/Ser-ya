import AppLayout from "@/components/AppLayout";
import DocumentCenter, { type DocProfile } from "@/components/DocumentCenter";
import { getProfile } from "@/components/automations/OrgProfiles";
import { useListAutomations, useListAutomationTasks, useListAddresses } from "@workspace/api-client-react";
import { FileText, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from "@/lib/motion-compat";

/* Build DocProfile list from automations + tasks + org profiles */
function buildDocs(
  automations: any[] | undefined,
  tasks: any[] | undefined,
  addresses: any[] | undefined,
): DocProfile[] {
  if (!automations || !tasks || !addresses) return [];
  const docs: DocProfile[] = [];
  for (const auto of automations) {
    const addr = addresses.find((a: any) => a.id === auto.addressId);
    const addrLabel = addr
      ? `${addr.street}, ${addr.postalCode} ${addr.city}, ${addr.country}`
      : (auto.addressLabel ?? "Adresse");
    const autoTasks = tasks.filter((t: any) => t.automationId === auto.id);
    for (const t of autoTasks) {
      const sName = t.serviceName ?? "Service";
      const profile = getProfile(sName);
      docs.push({
        serviceName: sName,
        mode: profile.mode,
        status: t.status === "completed" ? "completed" : t.status === "failed" ? "failed" : auto.status === "running" ? "in_progress" : "pending",
        processingTime: profile.processingTime,
        prepared: profile.prepared,
        required: profile.required,
        nextSteps: profile.nextSteps,
        orgNote: profile.orgNote,
        prefillData: profile.prefillData,
        checklistItems: profile.checklistItems,
        emailTemplate: profile.emailTemplate ? profile.emailTemplate(addrLabel) : undefined,
        addressLabel: addrLabel,
        completedAt: t.completedAt ?? undefined,
      });
    }
  }
  return docs;
}

export default function DocumentsPage() {
  const { data: automations, isLoading: autoLoading } = useListAutomations();
  const { data: tasks, isLoading: tasksLoading } = useListAutomationTasks();
  const { data: addresses, isLoading: addrLoading } = useListAddresses();

  const docs = buildDocs(automations, tasks, addresses);
  const isLoading = autoLoading || tasksLoading || addrLoading;

  return (
    <AppLayout title="Documents">
      <div className="max-w-3xl mx-auto space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-4"
        >
          <Link href="/dashboard">
            <Button variant="ghost" size="sm" className="gap-1.5 text-xs">
              <ArrowLeft className="w-3.5 h-3.5" /> Retour
            </Button>
          </Link>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Documents préparés</h1>
            <p className="text-xs text-muted-foreground mt-0.5">
              Toutes les fiches administratives générées par Serenya pour votre déménagement.
            </p>
          </div>
        </motion.div>

        {isLoading ? (
          <div className="space-y-3">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        ) : (
          <>
            {docs.length === 0 ? (
              <div className="text-center py-16 rounded-2xl border border-dashed border-border/40 bg-muted/10">
                <FileText className="w-12 h-12 text-muted-foreground/20 mx-auto mb-4" />
                <h3 className="text-sm font-semibold text-muted-foreground">Aucun document pour l&apos;instant</h3>
                <p className="text-xs text-muted-foreground/60 mt-1 max-w-xs mx-auto">
                  Lancez une préparation depuis le tableau de bord pour générer vos fiches administratives.
                </p>
                <Link href="/dashboard">
                  <Button size="sm" className="mt-4 gap-1.5">
                    <ArrowLeft className="w-3.5 h-3.5" /> Aller au tableau de bord
                  </Button>
                </Link>
              </div>
            ) : (
              <DocumentCenter docs={docs} />
            )}
          </>
        )}
      </div>
    </AppLayout>
  );
}
