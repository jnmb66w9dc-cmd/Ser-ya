import AppLayout from "@/components/AppLayout";
import AIInsights from "@/components/AIInsights";
import EmptyState from "@/components/EmptyState";
import { useState, useEffect, useRef, useCallback } from "react";
import confetti from "canvas-confetti";
import { useUser } from "@clerk/react";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import {
  MapPin, Building2, Zap, CheckCircle2, Clock, TrendingUp, Plus,
  Wifi, Cpu, Bot, Terminal, Loader2, XCircle, Star, ChevronRight,
  Sparkles, ArrowUpRight, ShieldCheck, Send, Activity, RefreshCw,
  AlertTriangle, ListChecks, Shield, Info, FileText,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useAutoSave, clearAutoSave } from "@/hooks/useAutoSave";
import { useBeforeUnload } from "@/hooks/useBeforeUnload";
import DraftRecoveryBanner from "@/components/DraftRecoveryBanner";
import { TaskHubWidget, generateTasksFromProfile } from "@/components/TaskCenter";
import { getProfile } from "@/components/automations/OrgProfiles";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import AddressAutocomplete from "@/components/AddressAutocomplete";
import {
  useGetDashboardSummary,
  useGetRecentActivity,
  useListAddresses,
  useListUserServices,
  useListAutomations,
  useCreateAutomation,
  useCreateAddress,
  getListAutomationsQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetRecentActivityQueryKey,
  getListAddressesQueryKey,
} from "@workspace/api-client-react";

/* ── Extracted dashboard components ── */
import StatsBar from "@/components/dashboard/StatsBar";
import ControlCenter from "@/components/dashboard/ControlCenter";
import ActivityTimeline from "@/components/dashboard/ActivityTimeline";
import MoveChecklist from "@/components/dashboard/MoveChecklist";

/* ═══════════════════ Simulation Types & Engine ════════════════════ */

type AIMsgType = "system" | "info" | "action" | "success" | "error" | "highlight" | "warning";
type SvcStatus  = "queued" | "connecting" | "detecting" | "updating" | "done" | "failed";

interface AIMsg {
  id: number;
  type: AIMsgType;
  text: string;
  ts: string;
}
interface SimSvc {
  serviceId: number;
  serviceName: string;
  category: string;
  status: SvcStatus;
}
interface Sim {
  addressLabel: string;
  services: SimSvc[];
  messages: AIMsg[];
  status: "running" | "done" | "partial";
  progress: number;
  isTyping: boolean;
}

let _msgId = 0;
const mkMsg = (type: AIMsgType, text: string): AIMsg => ({
  id: ++_msgId,
  type,
  text,
  ts: new Date().toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
});

const MSG_STYLES: Record<AIMsgType, { bar: string; text: string; icon: string }> = {
  system:    { bar: "bg-slate-600",   text: "text-slate-400",   icon: "⬡" },
  info:      { bar: "bg-blue-500",    text: "text-blue-300",    icon: "◈" },
  action:    { bar: "bg-violet-500",  text: "text-slate-200",   icon: "◎" },
  success:   { bar: "bg-emerald-500", text: "text-emerald-300", icon: "✓" },
  error:     { bar: "bg-red-500",     text: "text-red-300",     icon: "✗" },
  warning:   { bar: "bg-amber-500",   text: "text-amber-200",   icon: "⚠" },
  highlight: { bar: "bg-amber-500",   text: "text-amber-200",   icon: "★" },
};

const SVC_STATUS_CONFIG: Record<SvcStatus, { label: string; color: string; bg: string; border: string }> = {
  queued:     { label: "En attente",  color: "text-slate-400",   bg: "bg-slate-500/10",   border: "border-slate-500/20" },
  connecting: { label: "Connexion…",  color: "text-blue-400",    bg: "bg-blue-500/10",    border: "border-blue-500/30" },
  detecting:  { label: "Détection…",  color: "text-violet-400",  bg: "bg-violet-500/10",  border: "border-violet-500/30" },
  updating:   { label: "Mise à jour…",color: "text-amber-400",   bg: "bg-amber-500/10",   border: "border-amber-500/30" },
  done:       { label: "Confirmé ✓",  color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/30" },
  failed:     { label: "Échec ✗",     color: "text-red-400",     bg: "bg-red-500/10",     border: "border-red-500/30" },
};

/* ═══════════════════ Sub-components ════════════════════════════════ */

function TypingDots() {
  return (
    <div className="flex items-center gap-1 px-3 py-2">
      <div className="flex gap-1">
        {[0, 1, 2].map(i => (
          <motion.div
            key={i}
            className="w-1.5 h-1.5 rounded-full bg-blue-400"
            animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.1, 0.8] }}
            transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.2 }}
          />
        ))}
      </div>
      <span className="text-xs text-blue-400/60 ml-1">IA en train d'analyser…</span>
    </div>
  );
}

function AIMessageRow({ msg }: { msg: AIMsg }) {
  const style = MSG_STYLES[msg.type];
  return (
    <motion.div
      initial={{ opacity: 0, x: -12, filter: "blur(4px)" }}
      animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
      transition={{ duration: 0.28, ease: "easeOut" }}
      className="flex items-start gap-2.5 group"
    >
      <div className={cn("w-0.5 h-full min-h-[1.25rem] rounded-full flex-shrink-0 mt-0.5", style.bar)} />
      <div className="flex-1 min-w-0">
        <p className={cn("text-xs leading-relaxed font-mono", style.text)}>{msg.text}</p>
      </div>
      <span className="text-xs text-slate-600 flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity font-mono">{msg.ts}</span>
    </motion.div>
  );
}

function PulsingDot({ color = "bg-blue-500" }: { color?: string }) {
  return (
    <span className="relative flex h-2 w-2 flex-shrink-0">
      <span className={cn("animate-ping absolute inline-flex h-full w-full rounded-full opacity-60", color)} />
      <span className={cn("relative inline-flex rounded-full h-2 w-2", color)} />
    </span>
  );
}

function ProgressRing({ value, size = 80, stroke = 6 }: { value: number; size?: number; stroke?: number }) {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  return (
    <svg width={size} height={size} className="rotate-[-90deg]">
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" strokeWidth={stroke} className="stroke-white/5" />
      <motion.circle
        cx={size / 2} cy={size / 2} r={r} fill="none"
        strokeWidth={stroke} strokeLinecap="round"
        stroke="url(#dash-grad)"
        strokeDasharray={circ}
        initial={{ strokeDashoffset: circ }}
        animate={{ strokeDashoffset: circ - (value / 100) * circ }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      />
      <defs>
        <linearGradient id="dash-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="50%" stopColor="#8b5cf6" />
          <stop offset="100%" stopColor="#10b981" />
        </linearGradient>
      </defs>
    </svg>
  );
}

function AnimatedStat({ rawValue, suffix }: { rawValue: number | undefined; suffix: string }) {
  const [display, setDisplay] = useState<string>("—");
  const prevRef = useRef<number | undefined>(undefined);

  useEffect(() => {
    if (rawValue === undefined) { setDisplay("—"); return; }
    const target = rawValue;
    const prev   = prevRef.current ?? 0;
    prevRef.current = target;
    if (target === prev) { setDisplay(`${target}${suffix}`); return; }
    const start = Date.now();
    const dur   = 700;
    const tick  = () => {
      const t = Math.min(1, (Date.now() - start) / dur);
      const eased = 1 - (1 - t) * (1 - t);
      setDisplay(`${Math.round(prev + eased * (target - prev))}${suffix}`);
      if (t < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [rawValue, suffix]);

  return <p className="text-lg font-bold leading-none tabular-nums">{display}</p>;
}

/* ═══════════════════ Shared helpers ════════════════════════════════ */

function relativeTime(dateStr: string): string {
  const diff = Date.now() - new Date(dateStr).getTime();
  const min = Math.floor(diff / 60000);
  const hr = Math.floor(diff / 3600000);
  const day = Math.floor(diff / 86400000);
  if (min < 2) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  if (hr < 24) return `il y a ${hr}h`;
  if (day < 7) return `il y a ${day}j`;
  return new Date(dateStr).toLocaleDateString("fr-FR", { day: "numeric", month: "short" });
}

/* ═══════════════════ Address Form Schema ════════════════════════════ */

const addrSchema = z.object({
  label:      z.string().min(1, "Requis"),
  street:     z.string().min(1, "Requis"),
  complement: z.string().optional(),
  city:       z.string().min(1, "Requis"),
  postalCode: z.string().min(1, "Requis").regex(/^\d{5}$/, "Le code postal doit contenir 5 chiffres"),
  country:    z.string().default("France"),
});
type AddrForm = z.infer<typeof addrSchema>;

/* ═══════════════════ Main Dashboard ════════════════════════════════ */

export default function DashboardPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const feedRef = useRef<HTMLDivElement>(null);
  const { user } = useUser();

  const { data: summary, isLoading: summaryLoading }         = useGetDashboardSummary();
  const { data: activity, isLoading: activityLoading }         = useGetRecentActivity();
  const { data: addresses, isLoading: addressesLoading }     = useListAddresses();
  const { data: userServices, isLoading: userServicesLoading } = useListUserServices();
  const { data: automations, isLoading: automationsLoading }   = useListAutomations();
  const createAutomation = useCreateAutomation();
  const createAddress    = useCreateAddress();

  const pageLoading = summaryLoading || activityLoading || addressesLoading || userServicesLoading || automationsLoading;

  const [sim, setSim] = useState<Sim | null>(null);
  const simTimersRef = useRef<ReturnType<typeof setTimeout>[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<number | null>(null);
  const [selectedServiceIds, setSelectedServiceIds] = useState<number[]>([]);
  const [showAddrForm, setShowAddrForm] = useState(false);
  const [addrSuccess, setAddrSuccess] = useState(false);
  const [mobileTab, setMobileTab] = useState<"ai" | "setup" | "history">("ai");
  const [draftRecovered, setDraftRecovered] = useState(false);

  // Auto-save dashboard selection state
  useAutoSave({
    key: "dashboard_selection",
    data: { selectedAddressId, selectedServiceIds },
    onRestore: (saved) => {
      if (saved.selectedAddressId) setSelectedAddressId(saved.selectedAddressId as number);
      if (saved.selectedServiceIds && (saved.selectedServiceIds as number[]).length > 0) {
        setSelectedServiceIds(saved.selectedServiceIds as number[]);
      }
      setDraftRecovered(true);
    },
  });

  // Auto-scroll feed
  useEffect(() => {
    if (feedRef.current) {
      feedRef.current.scrollTop = feedRef.current.scrollHeight;
    }
  }, [sim?.messages.length, sim?.isTyping]);

  // Post-sim invalidation
  useEffect(() => {
    if (sim?.status === "done" || sim?.status === "partial") {
      queryClient.invalidateQueries({ queryKey: getListAutomationsQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
      queryClient.invalidateQueries({ queryKey: getGetRecentActivityQueryKey() });
    }
  }, [sim?.status, queryClient]);

  /* ── Real AI Automation Runner ── */
  const runSim = useCallback(async (
    services: { serviceId: number; serviceName: string; category: string }[],
    addressLabel: string,
    addressId: number,
    serviceIds: number[],
  ) => {
    // Initialise sim state
    const initial: Sim = {
      addressLabel,
      services: services.map(s => ({ ...s, status: "queued" as SvcStatus })),
      messages: [],
      status: "running",
      progress: 0,
      isTyping: false,
    };
    setSim(initial);

    const addMsg = (type: AIMsgType, text: string) =>
      setSim(p => p ? { ...p, messages: [...p.messages.slice(-30), mkMsg(type, text)], isTyping: false } : p);
    const setTyping = (on: boolean) =>
      setSim(p => p ? { ...p, isTyping: on } : p);
    const setSvcStatus = (id: number, status: SvcStatus) =>
      setSim(p => p ? { ...p, services: p.services.map(s => s.serviceId === id ? { ...s, status } : s) } : p);
    const setProgress = (pct: number) =>
      setSim(p => p ? { ...p, progress: pct } : p);

    // Boot sequence (kept for visual impact)
    const timeline: Array<{ at: number; fn: () => void }> = [];
    let cursor = 0;
    const after = (delay: number, fn: () => void) => { cursor += delay; timeline.push({ at: cursor, fn }); };

    after(0,   () => setTyping(true));
    after(500, () => addMsg("system", "⬡  Serenya — Préparation de vos démarches administratives…"));
    after(200, () => setTyping(true));
    after(600, () => addMsg("info", "◈  Analyse des démarches nécessaires auprès de vos organismes…"));
    after(200, () => setTyping(true));
    after(500, () => addMsg("success", `✓  ${services.length} organisme(s) prêt(s) — préparation en cours`));
    after(200, () => setTyping(true));
    after(400, () => addMsg("highlight", `★  Adresse cible : ${addressLabel}`));

    // Fire boot sequence
    simTimersRef.current.forEach(id => clearTimeout(id));
    simTimersRef.current = [];
    timeline.forEach(({ at, fn }) => simTimersRef.current.push(setTimeout(fn, at)));

    // Call real AI
    let plan: any = null;
    try {
      const res = await fetch("/api/ai/automation-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ addressId, serviceIds }),
      });
      if (res.ok) plan = await res.json();
    } catch { /* ignore */ }

    // Phase 1…N — Per service with real knowledge-base steps
    let doneCount = 0;
    const steps: Array<{ at: number; fn: () => void }> = [];
    let stepCursor = cursor + 500;
    const stepAfter = (delay: number, fn: () => void) => { stepCursor += delay; steps.push({ at: stepCursor, fn }); };

    services.forEach((svc) => {
      const svcPlan = plan?.plan?.find((p: any) => p.serviceId === svc.serviceId || p.serviceName === svc.serviceName);
      const hasPlan = !!svcPlan;
      const steps_ = svcPlan?.steps ?? [];
      const failed = hasPlan ? svcPlan.difficulty === "difficile" : Math.random() < 0.08;
      const diffLabel = svcPlan?.difficulty ?? "moyen";
      const diffColor = diffLabel === "facile" ? "🟢" : diffLabel === "moyen" ? "🟡" : "🔴";

      // Header for this service
      stepAfter(400, () => setTyping(true));
      stepAfter(500, () => {
        addMsg("action", `◎  ${svc.serviceName} (${svc.category}) — difficulté ${diffColor} ${diffLabel}`);
        setSvcStatus(svc.serviceId, "connecting");
      });

      // Show each real step from the knowledge base
      steps_.forEach((stepItem: any, idx: number) => {
        const delayMs = 400 + idx * 350;
        stepAfter(delayMs, () => setTyping(true));
        stepAfter(delayMs + 300, () => {
          const typeMap: Record<string, AIMsgType> = {
            info: "info", action: "action", success: "success", warning: "warning",
          };
          addMsg(typeMap[stepItem.type] ?? "info", `${idx + 1}. ${stepItem.message}`);
        });
      });

      // Documents
      stepAfter(200 + steps_.length * 350, () => setTyping(true));
      stepAfter(500 + steps_.length * 350, () => {
        if (svcPlan?.documentsNeeded?.length) {
          addMsg("info", `◈  Documents requis : ${svcPlan.documentsNeeded.join(", ")}`);
        }
      });

      // URL
      stepAfter(200, () => setTyping(true));
      stepAfter(400, () => {
        const url = svcPlan?.url || "";
        if (url) {
          addMsg("action", `↗  Formulaire officiel : ${url}`);
        }
        setSvcStatus(svc.serviceId, "detecting");
      });

      // Estimated time
      stepAfter(200, () => setTyping(true));
      stepAfter(400, () => {
        if (svcPlan?.estimatedTime) {
          addMsg("info", `⏱  Délai estimé : ${svcPlan.estimatedTime}`);
        }
      });

      // Preparation completion
      stepAfter(200, () => setTyping(true));
      stepAfter(500, () => addMsg("info", "◈  Préparation terminée — voici les prochaines étapes à suivre"));
      setSvcStatus(svc.serviceId, "updating");

      // Result
      if (failed) {
        stepAfter(200, () => setTyping(true));
        stepAfter(700, () => {
          addMsg("error", `✗  ${svc.serviceName} — Validation CAPTCHA requise (sécurité)`);
          setSvcStatus(svc.serviceId, "failed");
          doneCount++;
          setProgress(Math.round((doneCount / services.length) * 100));
          toast({ title: `${svc.serviceName}`, description: "Fiche préparée — consultez Documents" });
        });
      } else {
        stepAfter(200, () => setTyping(true));
        stepAfter(600, () => {
          addMsg("success", `✓  ${svc.serviceName} — Adresse mise à jour`);
          setSvcStatus(svc.serviceId, "done");
          doneCount++;
          setProgress(Math.round((doneCount / services.length) * 100));
          toast({ title: `${svc.serviceName} ✓`, description: "Fiche administrative préparée" });
        });
      }
      stepAfter(300, () => {});
    });

    // Phase Final — Summary with real data
    const failedCount = services.filter((_, i) => {
      const svcPlan = plan?.plan?.find((p: any) => p.serviceId === services[i].serviceId || p.serviceName === services[i].serviceName);
      return svcPlan?.difficulty === "difficile";
    }).length;
    const allDone = failedCount === 0;
    const totalDocs = plan?.summary?.totalDocuments ?? 0;
    const totalTime = plan?.summary?.estimatedTotalTime ?? "N/A";

    stepAfter(600, () => setTyping(true));
    stepAfter(700, () => addMsg("highlight",
      `★  Rapport : ${services.length - failedCount}/${services.length} organismes • ${totalDocs} documents • ${totalTime}`));
    stepAfter(200, () => setTyping(true));
    stepAfter(600, () => {
      if (plan?.summary?.tips?.length) {
        plan.summary.tips.slice(0, 3).forEach((tip: string) => addMsg("info", `💡  ${tip}`));
      }
      addMsg(
        allDone ? "success" : "error",
        allDone
          ? "✓  Terminé — Toutes les fiches sont prêtes dans Documents"
          : "⚠  Terminé — Certaines démarches nécessitent votre action"
      );
      setSim(p => p ? { ...p, status: allDone ? "done" : "partial", isTyping: false } : p);
    });

    // Fire all steps
    steps.forEach(({ at, fn }) => simTimersRef.current.push(setTimeout(fn, at)));
  }, [toast]);

  /* ── Confetti on sim completion ── */
  const prevSimStatus = useRef<string | null>(null);
  useEffect(() => {
    if (sim?.status === "done" && prevSimStatus.current === "running") {
      confetti({
        particleCount: 120,
        spread: 75,
        origin: { y: 0.5 },
        colors: ["#6366f1", "#8b5cf6", "#22c55e", "#f59e0b", "#ec4899"],
        zIndex: 9999,
      });
    }
    prevSimStatus.current = sim?.status ?? null;
  }, [sim?.status]);

  // Warn before closing with pending selection
  const hasPendingSelection = !sim && (selectedAddressId !== null || selectedServiceIds.length > 0);
  useBeforeUnload(hasPendingSelection);

  /* ── Launch handler ── */
  function handleLaunch() {
    if (!selectedAddressId || selectedServiceIds.length === 0) return;
    const addr = addresses?.find(a => a.id === selectedAddressId);
    const svcs = userServices?.filter(s => selectedServiceIds.includes(s.serviceId)) ?? [];
    createAutomation.mutate(
      { data: { addressId: selectedAddressId, serviceIds: selectedServiceIds } },
      {
        onSuccess: () => {
          clearAutoSave("dashboard_selection");
          setDraftRecovered(false);
          runSim(
            svcs.map(s => ({ serviceId: s.serviceId, serviceName: s.serviceName, category: s.serviceCategory ?? "" })),
            addr?.label ?? "Adresse",
            selectedAddressId,
            selectedServiceIds,
          );
          // Auto-generate administrative tasks for each selected service via API
          svcs.forEach(s => {
            const profile = getProfile(s.serviceName);
            const generated = generateTasksFromProfile(
              s.serviceName, profile.required, profile.checklistItems,
              profile.mode, profile.emailTemplate ? profile.emailTemplate(addr?.label ?? "Adresse") : undefined,
              [],
            );
            generated.forEach(t => {
              fetch("/api/user-tasks", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  title: t.label,
                  description: t.note || null,
                  category: t.kind,
                  priority: t.priority === "high" ? "high" : t.priority === "low" ? "low" : "medium",
                  orgName: t.serviceName,
                }),
              }).catch(() => {});
            });
          });
          setSelectedAddressId(null);
          setSelectedServiceIds([]);
          setMobileTab("ai");
        },
        onError: (err: any) => {
          const msg = err?.response?.data?.error ?? err?.message ?? "Impossible de lancer la préparation.";
          toast({ title: "Erreur", description: msg, variant: "destructive" });
        },
      }
    );
  }

  /* ── Address form ── */
  const addrForm = useForm<AddrForm>({ resolver: zodResolver(addrSchema), defaultValues: { country: "France" } });
  const { watch: addrWatch, setValue: addrSetValue } = addrForm;
  function handleAddAddress(data: AddrForm) {
    createAddress.mutate({ data }, {
      onSuccess: () => {
        addrForm.reset({ country: "France" });
        setShowAddrForm(false);
        setAddrSuccess(true);
        setTimeout(() => setAddrSuccess(false), 3500);
        queryClient.invalidateQueries({ queryKey: getListAddressesQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        toast({ title: "Adresse ajoutée avec succès" });
      },
      onError: (err: any) => {
        const msg = err?.response?.data?.error ?? err?.message ?? "Impossible d'ajouter l'adresse.";
        toast({ title: "Adresse invalide", description: msg, variant: "destructive" });
      },
    });
  }

  const stats = [
    { icon: MapPin,     label: "Adresses",       rawValue: summary?.totalAddresses,    suffix: "",  dot: "bg-blue-500" },
    { icon: Building2,  label: "Services",        rawValue: summary?.connectedServices, suffix: "",  dot: "bg-violet-500" },
    { icon: Zap,        label: "Préparations", rawValue: summary?.automationsRun,    suffix: "",  dot: "bg-amber-500" },
    { icon: TrendingUp, label: "Taux de succès",  rawValue: summary?.successRate,       suffix: "%", dot: "bg-emerald-500" },
  ];

  const isRunning = sim?.status === "running";
  const canLaunch = !!selectedAddressId && selectedServiceIds.length > 0 && !isRunning;

  /* ── AI Panel ── */
  const AIPanel = (
    <div className={cn(
      "relative flex flex-col rounded-2xl border overflow-hidden transition-all duration-500",
      "bg-[#070b14]",
      isRunning
        ? "border-blue-500/40 shadow-xl shadow-blue-500/10"
        : sim?.status === "done"
        ? "border-emerald-500/30 shadow-lg shadow-emerald-500/8"
        : sim?.status === "partial"
        ? "border-amber-500/30"
        : "border-white/[0.06]"
    )}
      style={{ minHeight: 340 }}
    >
      {/* Dot-grid background */}
      <div className="absolute inset-0 opacity-30 pointer-events-none"
        style={{ backgroundImage: "radial-gradient(circle, rgba(99,102,241,0.15) 1px, transparent 1px)", backgroundSize: "24px 24px" }} />
      {/* Top glow when running */}
      {isRunning && (
        <div className="absolute top-0 inset-x-0 h-32 pointer-events-none"
          style={{ background: "linear-gradient(180deg, rgba(59,130,246,0.08) 0%, transparent 100%)" }} />
      )}

      {/* Header */}
      <div className="relative flex items-center gap-3 px-5 py-4 border-b border-white/[0.06]">
        <div className={cn(
          "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all",
          isRunning ? "bg-blue-500/20" : "bg-white/5"
        )}>
          {isRunning
            ? <Bot className="w-[18px] h-[18px] text-blue-400 animate-pulse" />
            : sim?.status === "done"
            ? <ShieldCheck className="w-[18px] h-[18px] text-emerald-400" />
            : <Bot className="w-[18px] h-[18px] text-slate-400" />
          }
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-sm font-semibold text-white">Préparation en cours</span>
            {isRunning && <PulsingDot color="bg-blue-500" />}
            {sim?.status === "done"    && <Badge className="text-xs bg-emerald-500/15 text-emerald-400 border-emerald-500/25 h-5">Succès</Badge>}
            {sim?.status === "partial" && <Badge className="text-xs bg-amber-500/15 text-amber-400 border-amber-500/25 h-5">Partiel</Badge>}
          </div>
          <p className="text-xs text-slate-500 truncate">
            {sim
              ? `${sim.addressLabel} — ${sim.services.length} organisme(s)`
              : "Prêt à centraliser vos changements d'adresse"}
          </p>
        </div>
        {sim && (
          <div className="flex items-center gap-3 flex-shrink-0">
            <div className="relative">
              <ProgressRing value={sim.progress} size={52} stroke={5} />
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xs font-bold text-white tabular-nums">{sim.progress}%</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Message feed */}
      <div
        ref={feedRef}
        className="relative flex-1 overflow-y-auto px-5 py-4 space-y-2.5 scroll-smooth"
        style={{ minHeight: 160 }}
      >
        <AnimatePresence mode="popLayout">
          {!sim ? (
            /* Idle state */
            <motion.div
              key="idle"
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center h-full min-h-[200px] text-center"
            >
              <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/[0.06] flex items-center justify-center mb-4">
                <Bot className="w-8 h-8 text-slate-500" />
              </div>
              <p className="text-sm font-medium text-slate-300 mb-1">Prêt à préparer vos démarches</p>
              <p className="text-xs text-slate-600 max-w-xs">
                Sélectionnez une adresse et vos organismes, puis lancez la préparation. Serenya analysera les démarches nécessaires.
              </p>
              <div className="flex flex-wrap justify-center gap-2 mt-5">
                {["Connexion sécurisée", "Préparation guidée", "Vous validez"].map(tag => (
                  <span key={tag} className="text-xs px-3 py-1 rounded-full bg-white/5 text-slate-500 border border-white/[0.05]">{tag}</span>
                ))}
              </div>
            </motion.div>
          ) : (
            sim.messages.map(msg => <AIMessageRow key={msg.id} msg={msg} />)
          )}
        </AnimatePresence>
        {sim?.isTyping && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
            <TypingDots />
          </motion.div>
        )}
      </div>

      {/* Service pipeline */}
      {sim && (
        <div className="relative border-t border-white/[0.06] px-5 py-3">
          <p className="text-xs text-slate-600 mb-2.5 font-mono uppercase tracking-wider">Préparation par organisme</p>
          <div className="flex flex-wrap gap-2">
            {sim.services.map(svc => {
              const cfg = SVC_STATUS_CONFIG[svc.status];
              const isActive = svc.status === "connecting" || svc.status === "detecting" || svc.status === "updating";
              return (
                <div
                  key={svc.serviceId}
                  className={cn(
                    "flex items-center gap-2 px-3 py-1.5 rounded-lg border text-xs font-mono transition-all",
                    cfg.bg, cfg.border
                  )}
                >
                  <div className={cn("w-1.5 h-1.5 rounded-full flex-shrink-0", cfg.color.replace("text-", "bg-"), isActive && "animate-pulse")} />
                  <span className="text-slate-300">{svc.serviceName}</span>
                  <span className={cn("hidden sm:inline", cfg.color)}>{cfg.label}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Reset button when done */}
      {sim && !isRunning && (
        <div className="relative border-t border-white/[0.06] px-5 py-3 flex justify-end">
          <Button
            variant="ghost" size="sm"
            className="text-xs text-slate-500 hover:text-slate-300 gap-2 h-8"
            onClick={() => setSim(null)}
          >
            <RefreshCw className="w-3.5 h-3.5" /> Nouvelle préparation
          </Button>
        </div>
      )}
    </div>
  );

  /* ── Sidebar ── */
  const Sidebar = (
    <div className="space-y-4">

      {/* Address selector */}
      <Card className="p-4 border border-card-border bg-card hover:border-primary/15 transition-all duration-200">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-blue-400" />
            <span className="font-semibold text-sm">1. Adresse cible</span>
          </div>
          <Button variant="ghost" size="icon" className="w-8 h-8" onClick={() => { setShowAddrForm(v => !v); setAddrSuccess(false); }}>
            <Plus className="w-3.5 h-3.5" />
          </Button>
        </div>

        <AnimatePresence>
          {addrSuccess && (
            <motion.div
              initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-3 flex items-center gap-2 p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span className="text-xs text-emerald-400">Adresse ajoutée avec succès !</span>
            </motion.div>
          )}
        </AnimatePresence>

        <AnimatePresence>
          {showAddrForm && (
            <motion.form
              initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.22 }}
              onSubmit={addrForm.handleSubmit(handleAddAddress)}
              className="overflow-hidden mb-4 space-y-2.5"
            >
              <div>
                <Label className="text-xs text-muted-foreground">Libellé <span className="text-red-400">*</span></Label>
                <Input {...addrForm.register("label")} placeholder="Domicile, Bureau…" className="mt-1 h-8 text-sm" />
                {addrForm.formState.errors.label && (
                  <p className="text-[11px] text-red-400 mt-0.5">{addrForm.formState.errors.label.message}</p>
                )}
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Rue <span className="text-red-400">*</span></Label>
                <AddressAutocomplete
                  value={addrWatch("street") || ""}
                  onChange={(val) => addrSetValue("street", val, { shouldValidate: true })}
                  onSelect={(s) => {
                    addrSetValue("postalCode", s.postalCode, { shouldValidate: true });
                    addrSetValue("city", s.city, { shouldValidate: true });
                  }}
                  placeholder="12 rue de la Paix"
                  disabled={createAddress.isPending}
                />
                {addrForm.formState.errors.street && (
                  <p className="text-[11px] text-red-400 mt-0.5">{addrForm.formState.errors.street.message}</p>
                )}
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label className="text-xs text-muted-foreground">Code postal <span className="text-red-400">*</span></Label>
                  <Input {...addrForm.register("postalCode")} placeholder="75001" className="mt-1 h-8 text-sm" inputMode="numeric" maxLength={5} />
                  {addrForm.formState.errors.postalCode && (
                    <p className="text-[11px] text-red-400 mt-0.5">{addrForm.formState.errors.postalCode.message}</p>
                  )}
                </div>
                <div>
                  <Label className="text-xs text-muted-foreground">Ville <span className="text-red-400">*</span></Label>
                  <Input {...addrForm.register("city")} placeholder="Paris" className="mt-1 h-8 text-sm" />
                  {addrForm.formState.errors.city && (
                    <p className="text-[11px] text-red-400 mt-0.5">{addrForm.formState.errors.city.message}</p>
                  )}
                </div>
              </div>
              <div className="flex gap-2 pt-1">
                <Button type="button" variant="outline" size="sm" className="flex-1 h-8 text-xs"
                  onClick={() => { setShowAddrForm(false); addrForm.reset({ country: "France" }); }}>Annuler</Button>
                <Button type="submit" size="sm" className="flex-1 h-8 text-xs" disabled={createAddress.isPending}>
                  {createAddress.isPending ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "Ajouter"}
                </Button>
              </div>
            </motion.form>
          )}
        </AnimatePresence>

        {!addresses || addresses.length === 0 ? (
          <div className="py-6">
            <EmptyState
              icon={MapPin}
              iconColor="text-primary/60"
              iconBg="bg-primary/10"
              iconBorder="border-primary/20"
              title="Votre adresse, le point de départ"
              description="Ajoutez une adresse pour lancer vos premières démarches. Une seule saisie suffit."
              action={{
                label: "Ajouter une adresse",
                onClick: () => setShowAddrForm(true),
              }}
              className="py-8"
            />
          </div>
        ) : (
          <div className="space-y-2">
            {addresses.slice(0, 4).map(a => (
              <button
                key={a.id}
                type="button"
                onClick={() => setSelectedAddressId(a.id === selectedAddressId ? null : a.id)}
                className={cn(
                  "w-full flex items-center gap-2.5 p-3 rounded-xl border text-left transition-all",
                  selectedAddressId === a.id
                    ? "border-primary/60 bg-primary/5 shadow-sm shadow-primary/10"
                    : "border-border/50 hover:border-border hover:bg-muted/20"
                )}
              >
                <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0",
                  selectedAddressId === a.id ? "bg-primary/15" : "bg-muted")}>
                  <MapPin className={cn("w-4 h-4", selectedAddressId === a.id ? "text-primary" : "text-muted-foreground")} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-semibold truncate">{a.label}</p>
                  <p className="text-xs text-muted-foreground truncate">{a.postalCode} {a.city}</p>
                </div>
                <div className="flex items-center gap-1 flex-shrink-0">
                  {a.isDefault && <Star className="w-3 h-3 text-amber-400" />}
                  {selectedAddressId === a.id && <CheckCircle2 className="w-3.5 h-3.5 text-primary" />}
                </div>
              </button>
            ))}
            {addresses.length > 4 && (
              <Link href="/addresses">
                <p className="text-xs text-center text-muted-foreground hover:text-primary transition-colors cursor-pointer pt-1">
                  +{addresses.length - 4} autre(s) adresse(s)
                </p>
              </Link>
            )}
          </div>
        )}
      </Card>

      {/* Service selector */}
      <Card className="p-4 border border-card-border bg-card hover:border-primary/15 transition-all duration-200">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-violet-400" />
            <span className="font-semibold text-sm">2. Services</span>
            {selectedServiceIds.length > 0 && (
              <Badge variant="secondary" className="text-xs h-4 px-1.5">{selectedServiceIds.length}</Badge>
            )}
          </div>
          {userServices && userServices.length > 0 && (
            <Button variant="ghost" size="sm" className="h-6 text-xs text-muted-foreground px-2"
              onClick={() =>
                setSelectedServiceIds(selectedServiceIds.length === userServices.length
                  ? []
                  : userServices.map(s => s.serviceId))}>
              {selectedServiceIds.length === userServices.length ? "Tout désélect." : "Tout sélect."}
            </Button>
          )}
        </div>

        {!userServices || userServices.length === 0 ? (
          <div className="py-6">
            <EmptyState
              icon={Building2}
              iconColor="text-violet-400/70"
              iconBg="bg-violet-500/10"
              iconBorder="border-violet-500/20"
              title="Vos services, vos interlocuteurs"
              description="Sélectionnez les organismes à mettre à jour. Serenya connaît les démarches de 25 organismes français."
              hint="EDF, Orange, CAF, La Poste, votre banque… tous les services courants sont disponibles."
              action={{
                label: "Parcourir les services",
                href: "/services",
              }}
              className="py-8"
            />
          </div>
        ) : (
          <div className="space-y-1.5 max-h-52 overflow-y-auto pr-1">
            {userServices.map(s => {
              const sel = selectedServiceIds.includes(s.serviceId);
              return (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setSelectedServiceIds(
                    sel ? selectedServiceIds.filter(id => id !== s.serviceId) : [...selectedServiceIds, s.serviceId]
                  )}
                  className={cn(
                    "w-full flex items-center gap-3 p-2.5 rounded-xl border text-left transition-all",
                    sel ? "border-violet-500/40 bg-violet-500/5" : "border-border/40 hover:border-border hover:bg-muted/20"
                  )}
                >
                  <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold flex-shrink-0 transition-colors",
                    sel ? "bg-violet-500 text-white" : "bg-muted text-muted-foreground")}>
                    {s.serviceName[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium truncate">{s.serviceName}</p>
                    <p className="text-xs text-muted-foreground/60 truncate">{s.serviceCategory}</p>
                  </div>
                  {sel && <CheckCircle2 className="w-3.5 h-3.5 text-violet-400 flex-shrink-0" />}
                </button>
              );
            })}
          </div>
        )}
      </Card>

      {/* Launch button */}
      <div className="space-y-2">
        {!selectedAddressId && addresses && addresses.length > 0 && (
          <p className="text-xs text-amber-500/80 text-center">Sélectionnez une adresse ci-dessus</p>
        )}
        {selectedServiceIds.length === 0 && userServices && userServices.length > 0 && (
          <p className="text-xs text-amber-500/80 text-center">Sélectionnez au moins un service</p>
        )}
        <button
          type="button"
          onClick={handleLaunch}
          disabled={!canLaunch || createAutomation.isPending}
          className={cn(
            "w-full relative overflow-hidden rounded-xl px-5 py-4 flex items-center justify-center gap-3 font-semibold text-sm transition-all duration-300",
            canLaunch
              ? "bg-gradient-to-r from-blue-600 to-violet-600 text-white shadow-lg shadow-blue-500/25 hover:shadow-xl hover:shadow-blue-500/35 hover:scale-[1.01] active:scale-[0.99]"
              : "bg-muted text-muted-foreground cursor-not-allowed"
          )}
        >
          {canLaunch && (
            <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 to-transparent animate-pulse rounded-xl" />
          )}
          {createAutomation.isPending
            ? <><Loader2 className="w-4 h-4 animate-spin" /> Initialisation…</>
            : isRunning
            ? <><PulsingDot color="bg-white" /> Préparation en cours…</>
            : <><Send className="w-4 h-4" /> Lancer la préparation Serenya</>
          }
        </button>
      </div>

      <ActivityTimeline activity={activity as any} isRunning={isRunning} />



      {/* Document Hub — quick access */}
      <Card className="p-4 border border-card-border bg-card hover:border-primary/15 transition-all duration-200 cursor-pointer">
        <Link href="/documents">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-sm">Documents préparés</h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                {automations && automations.length > 0
                  ? `Vos fiches administratives et checklists — cliquez pour consulter`
                  : "Aucun document encore — lancez une préparation"}
              </p>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground/30" />
          </div>
        </Link>
      </Card>

      {/* Task Hub — quick access */}
      <TaskHubWidget onOpen={() => window.location.href = "/tasks"} />

      <MoveChecklist />
    </div>
  );

  /* ══════════════════════════ Render ════════════════════════════════ */
  return (
    <AppLayout title="Tableau de bord">
      <div className="px-4 sm:px-6 py-6 max-w-7xl mx-auto space-y-5">

        {/* Draft recovery banner */}
        <DraftRecoveryBanner
          storageKey="dashboard_selection"
          onRestore={() => { setDraftRecovered(true); }}
          onClear={() => { setSelectedAddressId(null); setSelectedServiceIds([]); setDraftRecovered(false); clearAutoSave("dashboard_selection"); }}
          label="votre sélection"
        />

        {/* Greeting */}
        {user && (
          <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35, ease: "easeOut" }}>
            <h1 className="text-xl font-semibold tracking-tight">
              Bonjour{user.firstName ? `, ${user.firstName}` : ""}
            </h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              Voici l'état de vos démarches — tout est sous contrôle.
            </p>
          </motion.div>
        )}

        {/* Loading skeleton */}
        {pageLoading && (
          <div className="space-y-5 animate-pulse">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="rounded-xl border border-border/30 bg-card p-4 space-y-2">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-muted/60" />
                    <div className="space-y-1.5 flex-1">
                      <div className="h-5 w-12 bg-muted/80 rounded" />
                      <div className="h-3 w-16 bg-muted/50 rounded" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              <div className="lg:col-span-7 rounded-2xl border border-border/30 bg-card h-[340px]" />
              <div className="lg:col-span-5 space-y-4">
                <div className="rounded-xl border border-border/30 bg-card h-40" />
                <div className="rounded-xl border border-border/30 bg-card h-40" />
                <div className="rounded-xl border border-border/30 bg-card h-32" />
              </div>
            </div>
          </div>
        )}

        {/* Real content — hidden during loading to prevent EmptyState flash */}
        {!pageLoading && (
          <div className="space-y-5">

        <StatsBar stats={stats} />

        {/* ── AI Insights ─────────────────────────────── */}
        <AIInsights />

        <ControlCenter automations={automations as any} />



        {/* Mobile tab switcher */}
        <div className="flex lg:hidden gap-1 p-1 rounded-xl bg-muted/50 border border-border/50">
          {(["ai", "setup", "history"] as const).map(tab => (
            <button
              key={tab}
              type="button"
              onClick={() => setMobileTab(tab)}
              className={cn(
                "flex-1 py-2.5 rounded-lg text-xs font-medium transition-all duration-200 select-none",
                mobileTab === tab ? "bg-card shadow-sm text-foreground" : "text-muted-foreground active:bg-muted"
              )}
            >
              {tab === "ai" ? "🤖 Préparation" : tab === "setup" ? "⚡ Lancer" : "📋 Historique"}
            </button>
          ))}
        </div>

        {/* Desktop: 2 columns. Mobile: tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* AI panel */}
          <div className={cn("lg:col-span-7", mobileTab !== "ai" && "hidden lg:block")}>
            {AIPanel}
          </div>
          {/* Sidebar */}
          <div className={cn("lg:col-span-5", mobileTab === "ai" && "hidden lg:block")}>
            {Sidebar}
          </div>
        </div>
      </div>
    )}

    </div>
  </AppLayout>
  );
}
