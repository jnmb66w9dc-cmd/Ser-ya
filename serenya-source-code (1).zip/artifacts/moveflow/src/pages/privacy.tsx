import { Link } from "wouter";
import { ArrowLeft, Shield, Lock, Eye, Database, Globe, Mail, Cookie, HardDrive } from "lucide-react";

const SECTIONS = [
  {
    icon: Database,
    title: "Donnees collectees",
    content: `Nous collectons uniquement les informations necessaires au fonctionnement du service :

• **Informations d'identite** : nom, prenom, adresse e-mail (via votre compte d'authentification Clerk)
• **Adresses postales** : vos adresses actuelles et nouvelles que vous saisissez volontairement
• **Services connectes** : la liste des organismes que vous choisissez de mettre a jour
• **Donnees de navigation anonymisees** : logs techniques anonymises pour assurer la stabilite du service

**Nous ne collectons JAMAIS** : vos mots de passe, codes d'acces aux organismes, donnees bancaires completes (IBAN), ni numero de securite sociale.`,
  },
  {
    icon: Shield,
    title: "Protection des donnees",
    content: `Votre securite est notre priorite absolue :

• **Chiffrement AES-256** de toutes les donnees personnelles au repos dans la base de donnees PostgreSQL
• **Transport TLS 1.3** pour toutes les communications entre votre navigateur et nos serveurs
• **Hebergement en Europe** via Replit (infrastructure Cloud sous contrat DPA conforme RGPD)
• **Aucun mot de passe** n'est jamais stocke ni transmis — nous utilisons Clerk pour l'authentification securisee
• **Acces aux donnees** strictement limite a l'equipe technique Serenya (pas de tiers externes)
• **Sauvegardes chiffrees** avec retention limitee a 30 jours pour les logs techniques`,
  },
  {
    icon: Eye,
    title: "Utilisation des donnees",
    content: `Vos donnees sont utilisees EXCLUSIVEMENT pour :

• Executer les preparations de changement d'adresse que vous initiez
• Vous envoyer des notifications sur l'avancement de vos demandes
• Ameliorer la qualite et la fiabilite de notre service
• Respecter nos obligations legales et reglementaires

**Nous ne vendons, ne louons et ne partageons jamais vos donnees personnelles** a des tiers a des fins commerciales.

**Traitement IA** : Vos conversations avec l'assistant IA sont transmises a Anthropic (Claude) pour generer des reponses. Anthropic ne conserve pas ces donnees pour entrainer ses modeles. Voir Article 10 des CGU pour plus de details.`,
  },
  {
    icon: Cookie,
    title: "Cookies et traceurs",
    content: `Serenya utilise uniquement des cookies strictement necessaires :

• **Cookies fonctionnels** : authentification (Clerk), preferences theme, session
• **Cookies de mesure** : Plausible Analytics (respectueux de la vie privee, pas de cookies tiers, donnees anonymisees)

**Nous n'utilisons AUCUN** : cookie publicitaire, tracker tiers (Google Analytics, Facebook Pixel), ni fingerprinting.

Vous pouvez desactiver les cookies de mesure depuis les Parametres. Les cookies fonctionnels sont indispensables au service.`,
  },
  {
    icon: Globe,
    title: "Base legale (RGPD)",
    content: `Conformement au Reglement General sur la Protection des Donnees (RGPD), notre traitement repose sur :

• **Execution du contrat** (Art. 6(1)(b)) : traitement necessaire a la fourniture du service de changement d'adresse
• **Consentement explicite** (Art. 6(1)(a)) : pour les communications marketing optionnelles (case a cocher non pre-coche)
• **Interet legitime** (Art. 6(1)(f)) : pour la securite, la prevention de la fraude et l'analyse anonymisee d'usage

**Duree de conservation** :
• Donnees actives : pendant la duree de votre compte + 90 jours
• Donnees supprimees : effacement definitif apres la periode de retention
• Factures : 10 ans (obligation legale fiscale)
• Logs techniques anonymises : 30 jours`,
  },
  {
    icon: Lock,
    title: "Vos droits",
    content: `Conformement au RGPD, vous disposez des droits suivants :

• **Droit d'acces** : obtenir une copie de vos donnees personnelles
• **Droit de rectification** : corriger vos donnees inexactes
• **Droit a l'effacement** : demander la suppression de vos donnees ("droit a l'oubli")
• **Droit a la portabilite** : recevoir vos donnees dans un format structure (JSON) via Parametres → Exporter mes donnees
• **Droit d'opposition** : vous opposer a certains traitements
• **Droit de limitation** : restreindre le traitement de vos donnees
• **Droit de retrait du consentement** : a tout moment pour les communications marketing

Pour exercer ces droits, contactez-nous a **contact@serenya.replit.app**. Delai de reponse : sous 30 jours calendaires.`,
  },
  {
    icon: HardDrive,
    title: "Sous-traitants et hebergeurs",
    content: `Serenya fait appel aux sous-traitants suivants, tous situes dans l'Union Europeenne ou sous contrat DPA conforme RGPD :

• **Replit** : hebergement de l'application et des bases de donnees (infrastructure Cloud)
• **Clerk** : authentification et gestion des utilisateurs (heberge aux USA avec certification Privacy Shield/SCC)
• **Anthropic** : traitement des conversations IA (heberge aux USA avec certification SOC 2 et DPA conforme)
• **Stripe** : traitement des paiements (certifie PCI DSS niveau 1)

Tous ces sous-traitants sont contractuellement lies par des clauses de protection des donnees (DPA/SSC) conformes aux exigences du RGPD.`,
  },
  {
    icon: Mail,
    title: "Contact & reclamations",
    content: `Pour toute question relative a la protection de vos donnees personnelles :

• **Email** : contact@serenya.replit.app
• **Delai de reponse** : sous 30 jours calendaires

Si vous estimez que vos droits ne sont pas respectes, vous pouvez contacter la **CNIL** (Commission Nationale de l'Informatique et des Libertes) :
• Site web : cnil.fr
• Voie postale : 3 Place de Fontenoy, TSA 80715, 75334 Paris Cedex 07
• Tel : 01.53.73.22.22`,
  },
];

function parseMarkdown(text: string) {
  const parts = text.split(/\*\*(.+?)\*\*/g);
  return parts.map((part, i) =>
    i % 2 === 1 ? <strong key={i} className="text-foreground font-medium">{part}</strong> : part
  );
}

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-background">
      <nav className="sticky top-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="max-w-4xl mx-auto px-6 h-14 flex items-center gap-4">
          <Link href="/" className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors">
            <ArrowLeft className="w-4 h-4" />
            Retour
          </Link>
          <div className="h-4 w-px bg-border" />
          <span className="text-sm font-medium">Politique de confidentialite</span>
        </div>
      </nav>

      <main className="max-w-4xl mx-auto px-6 py-16">
        <div className="mb-14">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium mb-6 border border-primary/20">
            <Shield className="w-3.5 h-3.5" />
            Conforme RGPD
          </div>
          <h1 className="text-4xl font-bold tracking-tight mb-4">Politique de confidentialite</h1>
          <p className="text-muted-foreground text-lg leading-relaxed max-w-2xl">
            Chez Serenya, la protection de vos donnees personnelles est fondamentale. Cette politique explique comment nous collectons, utilisons et protegeons vos informations.
          </p>
          <p className="text-xs text-muted-foreground/50 mt-4">
            Derniere mise a jour : 25 mai 2026 · Version 3.0
          </p>
        </div>

        <div className="space-y-10">
          {SECTIONS.map((section) => (
            <section key={section.title} className="group">
              <div className="flex items-start gap-4">
                <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center flex-shrink-0 mt-0.5 group-hover:bg-primary/15 transition-colors">
                  <section.icon className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h2 className="text-lg font-semibold mb-3">{section.title}</h2>
                  <div className="text-sm text-muted-foreground leading-relaxed space-y-1 whitespace-pre-line">
                    {section.content.split("\n").map((line, i) => (
                      <p key={i}>{parseMarkdown(line)}</p>
                    ))}
                  </div>
                </div>
              </div>
              <div className="mt-8 border-b border-border/30" />
            </section>
          ))}
        </div>

        <div className="mt-14 p-6 rounded-2xl bg-muted/30 border border-border/40">
          <p className="text-sm text-muted-foreground leading-relaxed">
            Cette politique de confidentialite est susceptible d'etre mise a jour. En cas de modification substantielle, nous vous en informerons par e-mail ou via une notification dans l'application au moins 30 jours avant l'entree en vigueur des changements.
          </p>
        </div>
      </main>
    </div>
  );
}
