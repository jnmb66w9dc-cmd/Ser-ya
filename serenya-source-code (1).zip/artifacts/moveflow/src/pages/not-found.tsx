import { Link } from "wouter";
import { motion } from "@/lib/motion-compat";
import { Sparkles, ArrowLeft, LayoutDashboard, MapPin, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-4 text-center">
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-primary/5 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative space-y-8 max-w-md"
      >
        <Link href="/" className="inline-flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center shadow-lg shadow-primary/30 group-hover:shadow-primary/50 transition-shadow">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <span className="font-bold tracking-tight">Serenya</span>
        </Link>

        <div className="space-y-3">
          <motion.div
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.1, type: "spring", stiffness: 200 }}
            className="text-[7rem] font-black leading-none tracking-tighter bg-gradient-to-b from-foreground/80 to-foreground/10 bg-clip-text text-transparent select-none"
          >
            404
          </motion.div>
          <h1 className="text-xl font-bold">Page introuvable</h1>
          <p className="text-sm text-muted-foreground leading-relaxed">
            Cette page n'existe pas ou a été déplacée. Pas d'inquiétude — vos adresses et préparations sont en sécurité.
          </p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {[
            { href: "/dashboard",   label: "Tableau de bord", icon: LayoutDashboard },
            { href: "/addresses",   label: "Mes adresses",    icon: MapPin },
            { href: "/automations", label: "Préparations", icon: Zap },
          ].map((item) => (
            <Link key={item.href} href={item.href}>
              <div className="flex flex-col items-center gap-2 p-3 rounded-xl border border-border/40 bg-muted/20 hover:bg-muted/40 hover:border-border/70 transition-all duration-200 cursor-pointer group">
                <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/15 transition-colors">
                  <item.icon className="w-4 h-4 text-primary" />
                </div>
                <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground transition-colors leading-tight text-center">{item.label}</span>
              </div>
            </Link>
          ))}
        </div>

        <div className="flex items-center justify-center gap-3">
          <Button variant="outline" onClick={() => window.history.back()} className="gap-2">
            <ArrowLeft className="w-3.5 h-3.5" /> Retour
          </Button>
          <Link href="/">
            <Button className="gap-2">
              <Sparkles className="w-3.5 h-3.5" /> Accueil
            </Button>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
