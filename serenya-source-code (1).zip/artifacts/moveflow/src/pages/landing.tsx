import { Link } from "wouter";
import {
  Sparkles, Shield, ArrowRight, CheckCircle2, Building2, Lock, Zap,
  FileText, Star, ChevronDown, Menu, X, Clock, Globe, Users, Bell,
  MapPin, Mail, ArrowUpRight, Heart, Rocket, Send, Quote, TrendingUp,
  Check, Loader2, Crown, Smartphone, ShoppingCart, Truck, Briefcase
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { motion, AnimatePresence } from "@/lib/motion-compat";
import { useState, useEffect, useRef } from "react";
import { useTranslation } from "react-i18next";
import LanguageSelector from "@/components/LanguageSelector";

type PublicStats = { waitlistCount: number; automationCount: number; successRate: number };
function usePublicStats() {
  const [stats, setStats] = useState<PublicStats>({ waitlistCount: 0, automationCount: 0, successRate: 0 });
  useEffect(() => {
    const base = (import.meta.env.BASE_URL ?? "").replace(/\/$/, "");
    fetch(`${base}/api/waitlist/stats`).then(r => r.ok ? r.json() : null).then(d => d && setStats(d));
  }, []);
  return stats;
}
import { cn } from "@/lib/utils";

/* ══════════════════════════════════════════════
   ANIMATION PRESETS
══════════════════════════════════════════════ */
const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: { opacity: 1, y: 0 },
};
const fadeIn = {
  hidden: { opacity: 0 },
  visible: { opacity: 1 },
};
const stagger = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};
const scaleIn = {
  hidden: { opacity: 0, scale: 0.9 },
  visible: { opacity: 1, scale: 1 },
};

/* ══════════════════════════════════════════════
   DATA
══════════════════════════════════════════════ */
const steps = [
  {
    num: "01",
    title: "Ajoutez votre nouvelle adresse",
    desc: "Saisissez simplement votre nouvelle adresse. Serenya valide le format et prépare les mises à jour.",
    icon: MapPin,
  },
  {
    num: "02",
    title: "Sélectionnez vos organisations",
    desc: "Banques, assurances, opérateurs, e-commerce — choisissez ceux que vous souhaitez mettre à jour.",
    icon: Building2,
  },
  {
    num: "03",
    title: "Serenya prépare et suit",
    desc: "L'assistant Serenya prépare chaque demande, suit l'avancement et vous guide étape par étape.",
    icon: FileText,
  },
  {
    num: "04",
    title: "Confirmez en toute sécurité",
    desc: "Vous validez toujours les actions sensibles. Rien ne se fait sans votre accord explicite.",
    icon: Shield,
  },
];

const trustPoints = [
  {
    icon: Lock,
    title: "Vous gardez le contrôle",
    desc: "Chaque action sensible nécessite votre confirmation. Serenya prépare, vous validez.",
  },
  {
    icon: Shield,
    title: "Aucun mot de passe stocké",
    desc: "Vos identifiants ne quittent jamais votre appareil. Nous ne conservons rien de sensible.",
  },
  {
    icon: CheckCircle2,
    title: "Transparence totale",
    desc: "Chaque étape est visible et traçable. Un journal complet de toutes vos démarches.",
  },
  {
    icon: Zap,
    title: "Traitement rapide et fiable",
    desc: "En moyenne moins de 5 minutes pour tout mettre à jour, avec un suivi en temps réel.",
  },
];

const previewFeatures = [
  { label: "Tableau de bord calme",    desc: "Vue d'ensemble claire de vos démarches en cours" },
  { label: "Timeline visuelle",         desc: "Suivez chaque étape avec des indicateurs de progrès" },
  { label: "Notifications douces",    desc: "Alertes discrètes pour chaque mise à jour réussie" },
  { label: "Gestion multi-adresses",  desc: "Plusieurs adresses, un seul endroit pour tout gérer" },
];

/* Social proof metrics — real data from API */
const staticStats = {
  organizations: "50+",
  organizationsLabel: "organisations supportées",
};

/* User stories & testimonials */
const userStories = [
    {
      quote: `On emmenageait ensemble pour la premiere fois. Entre les deux banques, l'assurance, l'electricite et internet, on ne savait plus ou on en etait. Serenya nous a accompagnes etape par etape. On n'a rien oublie.`,
      name: "Thomas & Camille",
      role: "Couple · Lyon",
      avatar: "TC",
      color: "from-rose-500/15 to-pink-500/15",
      context: "Premier appartement en couple",
    },
    {
      quote: `Avec trois enfants, changer d'adresse c'est un cauchemar. L'ecole, la banque, la mutuelle, la CAF... J'avais deja oublie le veterinaire l'annee derniere. Cette fois, tout etait centralise. Je me suis sentie accompagnee, pas seule face a la paperasse.`,
      name: "Aicha Benali",
      role: "Mere de famille · Toulouse",
      avatar: "AB",
      color: "from-emerald-500/15 to-teal-500/15",
      context: "Demenagement en famille",
    },
    {
      quote: `Premier appartement seul, premieres demarches administratives sans mes parents. J'etais perdu. Serenya m'a montre exactement quoi faire, quand, et pour qui. J'ai gagne en confiance.`,
      name: "Lucas Moreau",
      role: "Etudiant · Nantes",
      avatar: "LM",
      color: "from-sky-500/15 to-blue-500/15",
      context: "Premier appartement seul",
    },
    {
      quote: `A 67 ans, tout ce qui est digital me stresse. Mais la, c'etait different. Pas de jargon, pas de pression. Juste une liste claire de ce qu'il fallait faire. Meme moi j'y suis arrive. Et j'ai tout valide moi-meme.`,
      name: "Jean-Pierre Rousseau",
      role: "Retraite · Nice",
      avatar: "JR",
      color: "from-amber-500/15 to-orange-500/15",
      context: "Premiere experience digitale",
    },
    {
      quote: `Je voyage toute la semaine pour le travail. Le weekend dernier, j'ai du demenager. Je n'avais pas une heure a perdre. En 8 minutes, tout etait lance. Le lundi, j'ai recu la confirmation de ma banque.`,
      name: "Ines Durand",
      role: "Avocate · Paris",
      avatar: "ID",
      color: "from-violet-500/15 to-purple-500/15",
      context: "Pas de temps a perdre",
    },
  ];

/* ══════════════════════════════════════════════
   NAVBAR
══════════════════════════════════════════════ */
function Navbar({ scrolled }: { scrolled: boolean }) {
  const [mobileOpen, setMobileOpen] = useState(false);

  function scrollTo(id: string) {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
    setMobileOpen(false);
  }

  return (
    <>
      <nav className={cn(
        "fixed top-0 inset-x-0 z-30 transition-all duration-500",
        scrolled
          ? "bg-background/80 backdrop-blur-xl border-b border-border/30"
          : "bg-transparent"
      )}>
        <div className="max-w-6xl mx-auto px-5 sm:px-8 h-16 flex items-center justify-between">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="font-semibold text-sm tracking-tight">Serenya</span>
          </Link>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8 text-sm text-muted-foreground">
            <button onClick={() => scrollTo("pourquoi")} className="hover:text-foreground transition-colors duration-200">Pourquoi</button>
            <button onClick={() => scrollTo("fonctionnement")} className="hover:text-foreground transition-colors duration-200">Comment ça marche</button>
            <button onClick={() => scrollTo("cas-usages")} className="hover:text-foreground transition-colors duration-200">Cas d'usage</button>
            <button onClick={() => scrollTo("confiance")} className="hover:text-foreground transition-colors duration-200">Confiance</button>
            <button onClick={() => scrollTo("apercu")} className="hover:text-foreground transition-colors duration-200">Aperçu</button>
          </div>

          <div className="flex items-center gap-3">
            <LanguageSelector />
            <Link href="/sign-in" className="hidden sm:block text-sm text-muted-foreground hover:text-foreground transition-colors duration-200">
              Connexion
            </Link>
            <button onClick={() => scrollTo("liste-attente")}
              className="hidden sm:inline-flex h-9 px-4 rounded-full bg-foreground text-background text-sm font-medium items-center gap-1.5 hover:opacity-90 transition-opacity active:scale-[0.97] duration-150">
              S'inscrire <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button onClick={() => setMobileOpen(true)} className="md:hidden w-9 h-9 rounded-lg hover:bg-muted flex items-center justify-center text-muted-foreground active:bg-muted/80 transition-colors">
              <Menu className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
              onClick={() => setMobileOpen(false)}
            />
            <motion.div
              initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 300 }}
              className="fixed right-0 top-0 bottom-0 z-50 w-72 bg-background border-l border-border/50 p-6"
            >
              <div className="flex items-center justify-between mb-8">
                <span className="font-semibold">Menu</span>
                <button onClick={() => setMobileOpen(false)} className="w-8 h-8 rounded-lg hover:bg-muted flex items-center justify-center active:bg-muted/80 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="space-y-1">
                {[
                  { id: "pourquoi", label: "Pourquoi Serenya" },
                  { id: "fonctionnement", label: "Comment ça marche" },
                  { id: "cas-usages", label: "Cas d'usage" },
                  { id: "confiance", label: "Confiance & sécurité" },
                  { id: "apercu", label: "Aperçu de l'app" },
                  { id: "liste-attente", label: "Liste d'attente" },
                ].map(item => (
                  <button key={item.id} onClick={() => scrollTo(item.id)}
                    className="w-full text-left px-3 py-3 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-200">
                    {item.label}
                  </button>
                ))}
              </div>
              <div className="mt-6 pt-6 border-t border-border/20 space-y-3">
                <div className="flex items-center justify-center">
                  <LanguageSelector />
                </div>
                <Link href="/sign-in"
                  className="w-full block text-center px-4 py-2.5 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-all duration-200">
                  Se connecter
                </Link>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/* ══════════════════════════════════════════════
   SOCIAL PROOF STRIP
══════════════════════════════════════════════ */
function SocialProofStrip({ stats }: { stats: PublicStats }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-40px" }}
      transition={{ duration: 0.6, delay: 0.2 }}
      className="py-10 px-5 sm:px-8 border-y border-border/10"
    >
      <div className="max-w-4xl mx-auto">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-8 text-center">
          {[
            { value: staticStats.organizations, label: staticStats.organizationsLabel, icon: Building2 },
            { value: stats.waitlistCount.toLocaleString("fr-FR"), label: "personnes sur la liste d'attente", icon: Users },
            { value: stats.automationCount.toLocaleString("fr-FR"), label: "préparations lancées", icon: Heart },
            { value: stats.successRate + "%", label: "de taux de réussite", icon: TrendingUp },
          ].map((item, i) => (
            <motion.div key={item.label}
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.4 }}
              className="flex flex-col items-center"
            >
              <item.icon className="w-4 h-4 text-primary/40 mb-2" />
              <p className="text-2xl sm:text-3xl font-semibold tracking-tight">{item.value}</p>
              <p className="text-[11px] text-muted-foreground/60 mt-0.5">{item.label}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

/* ══════════════════════════════════════════════
   MOCKUP DASHBOARD
══════════════════════════════════════════════ */
function DashboardMockup() {
  return (
    <div className="relative rounded-2xl border border-border/40 bg-card/50 backdrop-blur-sm overflow-hidden shadow-2xl">
      {/* Browser chrome */}
      <div className="flex items-center gap-2 px-4 py-2.5 bg-background/80 border-b border-border/30">
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-400/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-amber-400/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-400/50" />
        </div>
        <div className="flex-1 text-center">
          <span className="text-[10px] text-muted-foreground/50 font-mono">serenya.fr/dashboard</span>
        </div>
        <div className="w-16" />
      </div>

      <div className="p-5 sm:p-6 space-y-4">
        {/* Header row */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-lg font-semibold">Mon déménagement</p>
            <p className="text-xs text-muted-foreground">3 démarches en cours</p>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <Bell className="w-3.5 h-3.5 text-primary" />
            </div>
            <div className="w-8 h-8 rounded-full bg-emerald-500/15 flex items-center justify-center">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
            </div>
          </div>
        </div>

        {/* Progress cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {[
            { label: "EDF", status: "Terminé", color: "text-emerald-400", bg: "bg-emerald-500/10", border: "border-emerald-500/20", done: true },
            { label: "Orange", status: "En cours", color: "text-blue-400", bg: "bg-blue-500/10", border: "border-blue-500/20", done: false },
            { label: "BNP Paribas", status: "En attente", color: "text-amber-400", bg: "bg-amber-500/10", border: "border-amber-500/20", done: false },
          ].map(item => (
            <div key={item.label} className={cn("rounded-xl border p-3.5", item.border, item.bg)}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-foreground/80">{item.label}</span>
                {item.done && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
              </div>
              <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
                <div className={cn("h-full rounded-full transition-all", item.done ? "bg-emerald-400 w-full" : item.status === "En cours" ? "bg-blue-400 w-2/3" : "bg-amber-400 w-0")} />
              </div>
              <p className={cn("text-[10px] mt-1.5", item.color)}>{item.status}</p>
            </div>
          ))}
        </div>

        {/* Address card */}
        <div className="rounded-xl border border-border/40 bg-background/50 p-3.5 flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
            <MapPin className="w-4 h-4 text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-muted-foreground">Nouvelle adresse</p>
            <p className="text-sm font-medium truncate">12 rue de la Paix, 75001 Paris</p>
          </div>
          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full flex-shrink-0">Active</span>
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════════
   PREMIUM WAITLIST SECTION
══════════════════════════════════════════════ */
function WaitlistSection({ stats }: { stats: PublicStats }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "submitting" | "success">("idle");
  const inputRef = useRef<HTMLInputElement>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !email.includes("@")) return;
    setState("submitting");
    try {
      const res = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), source: "landing" }),
      });
      if (res.ok || res.status === 200) {
        setState("success");
      } else {
        setState("idle");
      }
    } catch {
      setState("idle");
    }
  }

  function reset() {
    setState("idle");
    setEmail("");
    setTimeout(() => inputRef.current?.focus(), 100);
  }

  return (
    <section id="liste-attente" className="py-24 sm:py-32 px-5 sm:px-8 border-y border-border/20 relative overflow-hidden">
      {/* Subtle background glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[400px] bg-primary/[0.03] rounded-full blur-[120px]" />
      </div>

      <div className="max-w-xl mx-auto text-center relative">
        <motion.div
          initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
          variants={stagger}
        >
          {/* Icon */}
          <motion.div variants={fadeUp} className="w-14 h-14 rounded-2xl bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center mx-auto mb-6 shadow-xl shadow-primary/20">
            <Mail className="w-6 h-6 text-white" />
          </motion.div>

          {/* Heading */}
          <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
            Inscrivez-vous{" "}
            <span className="gradient-text">gratuitement</span>
          </motion.h2>

          <motion.p variants={fadeUp} className="text-muted-foreground mb-2 leading-relaxed max-w-md mx-auto">
            Créez votre compte gratuitement. L'accès beta est ouvert — vous commencez immédiatement.
          </motion.p>

          <motion.p variants={fadeUp} className="text-xs text-muted-foreground/50 mb-6">
            <Users className="w-3 h-3 inline-block mr-1 -mt-0.5" />
            {stats.waitlistCount.toLocaleString("fr-FR")} personnes nous font déjà confiance
          </motion.p>

          <motion.p variants={fadeUp} className="text-[11px] text-muted-foreground/40 mb-8 max-w-sm mx-auto leading-relaxed">
            Version bêta publique : les préparations sont en déploiement progressif.
            Votre retour est précieux — utilisez le widget en bas à droite une fois connecté.
          </motion.p>
        </motion.div>

        {/* Form / Success states */}
        <AnimatePresence mode="wait">
          {state === "success" ? (
            <motion.div
              key="success"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4, ease: "easeOut" }}
              className="max-w-md mx-auto"
            >
              {/* Success animation */}
              <div className="w-16 h-16 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto mb-5">
                <motion.div
                  initial={{ scale: 0 }} animate={{ scale: 1 }}
                  transition={{ type: "spring", damping: 12, stiffness: 200, delay: 0.1 }}
                >
                  <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                </motion.div>
              </div>

              <h3 className="text-xl font-semibold mb-2">Vous êtes inscrit(e)</h3>
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                Votre compte est prêt — connectez-vous pour commencer à centraliser vos démarches de changement d'adresse.
              </p>

              {/* Next steps */}
              <div className="space-y-3 mb-6 text-left">
                {[
                  { icon: Mail, text: "Email de confirmation envoyé" },
                  { icon: Rocket, text: "Accès immédiat — commencez maintenant" },
                  { icon: Rocket, text: "Accès gratuit à vie pour les premiers inscrits" },
                ].map((step, i) => (
                  <motion.div key={step.text}
                    initial={{ opacity: 0, x: -12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + i * 0.12, duration: 0.3 }}
                    className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-card/40 border border-border/30"
                  >
                    <step.icon className="w-4 h-4 text-primary/60 flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">{step.text}</span>
                  </motion.div>
                ))}
              </div>

              <button onClick={reset}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors duration-200">
                Inscrire une autre adresse
              </button>
            </motion.div>
          ) : (
            <motion.form
              key="form"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            >
              <Input
                ref={inputRef}
                type="email"
                placeholder="votre@email.com"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="h-12 rounded-full px-5 bg-card/60 border-border/50 text-sm focus-visible:ring-primary/20 focus-visible:border-primary/30 transition-all"
                required
                disabled={state === "submitting"}
                autoComplete="email"
              />
              <Button type="submit" className="h-12 rounded-full px-7 font-medium min-w-[160px]" disabled={state === "submitting" || !email.includes("@")}>
                <AnimatePresence mode="wait">
                  {state === "submitting" ? (
                    <motion.span key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="flex items-center gap-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Inscription...
                    </motion.span>
                  ) : (
                    <motion.span key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                      className="flex items-center gap-2">
                      <Send className="w-4 h-4" />
                      S'inscrire
                    </motion.span>
                  )}
                </AnimatePresence>
              </Button>
            </motion.form>
          )}
        </AnimatePresence>

        {state !== "success" && (
          <motion.p
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            className="text-xs text-muted-foreground/40 mt-5"
          >
            Aucun spam. Désinscription en un clic. Votre email ne sera jamais partagé.
          </motion.p>
        )}
      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════
   USER STORIES & TESTIMONIALS SECTION
══════════════════════════════════════════════ */
function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);

  return (
    <section className="py-24 sm:py-32 px-5 sm:px-8 border-y border-border/10">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <motion.div
          initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
          variants={stagger}
          className="text-center mb-16"
        >
          <motion.p variants={fadeUp} className="text-xs text-muted-foreground/60 uppercase tracking-[0.2em] mb-4">
            Ils ont testé Serenya
          </motion.p>
          <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
            Des histoires vraies,{" "}
            <span className="gradient-text">des vrais soulagements</span>
          </motion.h2>
          <motion.p variants={fadeUp} className="text-muted-foreground max-w-lg mx-auto leading-relaxed">
            Chaque témoignage vient d'une personne qui a vécu les mêmes galères administratives que vous.
          </motion.p>
        </motion.div>

        {/* Desktop: 3+2 grid */}
        <div className="hidden sm:grid grid-cols-3 gap-4 mb-4">
          {userStories.slice(0, 3).map((story, i) => (
            <motion.div key={story.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.5 }}
              className="group relative p-6 rounded-2xl border border-border/40 bg-card/30 hover:bg-card/50 transition-all duration-300"
            >
              <div className={cn("absolute inset-0 rounded-2xl bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none", story.color)} />
              <div className="relative">
                <span className="inline-block text-[10px] uppercase tracking-wider text-muted-foreground/50 font-medium mb-3">
                  {story.context}
                </span>
                <Quote className="w-5 h-5 text-primary/15 mb-3" />
                <p className="text-sm text-foreground/80 leading-[1.7] mb-5">
                  {story.quote}
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-border/20">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/20 to-violet-500/20 flex items-center justify-center text-xs font-medium text-primary/80">
                    {story.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{story.name}</p>
                    <p className="text-xs text-muted-foreground">{story.role}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
        <div className="hidden sm:grid grid-cols-2 gap-4 max-w-3xl mx-auto">
          {userStories.slice(3, 5).map((story, i) => (
            <motion.div key={story.name}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
              className="group relative p-6 rounded-2xl border border-border/40 bg-card/30 hover:bg-card/50 transition-all duration-300"
            >
              <div className={cn("absolute inset-0 rounded-2xl bg-gradient-to-br opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none", story.color)} />
              <div className="relative">
                <span className="inline-block text-[10px] uppercase tracking-wider text-muted-foreground/50 font-medium mb-3">
                  {story.context}
                </span>
                <Quote className="w-5 h-5 text-primary/15 mb-3" />
                <p className="text-sm text-foreground/80 leading-[1.7] mb-5">
                  {story.quote}
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-border/20">
                  <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/20 to-violet-500/20 flex items-center justify-center text-xs font-medium text-primary/80">
                    {story.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{story.name}</p>
                    <p className="text-xs text-muted-foreground">{story.role}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Mobile: horizontal scrollable cards */}
        <div className="sm:hidden">
          <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory pb-4 -mx-5 px-5 scrollbar-hide"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}>
            {userStories.map((story, i) => (
              <motion.div key={story.name}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08, duration: 0.4 }}
                className="flex-shrink-0 w-[85vw] max-w-[340px] snap-center p-5 rounded-2xl border border-border/40 bg-card/30"
              >
                <span className="inline-block text-[10px] uppercase tracking-wider text-muted-foreground/50 font-medium mb-2">
                  {story.context}
                </span>
                <Quote className="w-5 h-5 text-primary/15 mb-2" />
                <p className="text-sm text-foreground/80 leading-[1.7] mb-4">
                  {story.quote}
                </p>
                <div className="flex items-center gap-3 pt-3 border-t border-border/20">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-primary/20 to-violet-500/20 flex items-center justify-center text-[11px] font-medium text-primary/80">
                    {story.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{story.name}</p>
                    <p className="text-xs text-muted-foreground">{story.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
          {/* Mobile pagination dots */}
          <div className="flex items-center justify-center gap-1.5 mt-3">
            {userStories.map((_, i) => (
              <button
                key={i}
                onClick={() => setActiveIndex(i)}
                className={cn(
                  "w-1.5 h-1.5 rounded-full transition-all duration-300",
                  i === activeIndex ? "bg-primary w-4" : "bg-primary/20"
                )}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ══════════════════════════════════════════════
   EARLY ACCESS BADGE
══════════════════════════════════════════════ */
function EarlyAccessBadge() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.4, duration: 0.5 }}
      className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-primary/8 border border-primary/15 text-xs text-primary/80 mb-8"
    >
      <span className="relative flex h-2 w-2">
        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
      </span>
      Disponible maintenant · Accès gratuit
    </motion.div>
  );
}

/* ══════════════════════════════════════════════
   MAIN PAGE
══════════════════════════════════════════════ */
export default function LandingPage() {
  const stats = usePublicStats();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", fn, { passive: true });
    return () => window.removeEventListener("scroll", fn);
  }, []);

  // Scroll to hash on mount (e.g. /#liste-attente)
  useEffect(() => {
    const hash = window.location.hash.slice(1);
    if (hash) {
      const el = document.getElementById(hash);
      if (el) {
        const t = setTimeout(() => el.scrollIntoView({ behavior: "smooth", block: "start" }), 400);
        return () => clearTimeout(t);
      }
    }
    return undefined;
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden scroll-smooth">
      <Navbar scrolled={scrolled} />

      {/* ═══════ HERO ═══════ */}
      <section className="relative pt-28 pb-16 sm:pt-40 sm:pb-24 px-5 sm:px-8">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[500px] bg-primary/5 rounded-full blur-[140px]" />
          <div className="absolute top-20 right-1/4 w-[300px] h-[300px] bg-violet-500/3 rounded-full blur-[100px]" />
        </div>

        <div className="max-w-3xl mx-auto text-center relative">
          <motion.div variants={stagger} initial="hidden" animate="visible">
            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}>
              <EarlyAccessBadge />
            </motion.div>

            <motion.h1 variants={fadeUp} transition={{ duration: 0.6 }}
              className="text-4xl sm:text-5xl md:text-6xl font-semibold tracking-tight leading-[1.1] mb-7">
              Fini le stress des<br />
              <span className="gradient-text">changements d'adresse.</span>
            </motion.h1>

            <motion.p variants={fadeUp} transition={{ duration: 0.6 }}
              className="text-lg sm:text-xl text-muted-foreground max-w-xl mx-auto mb-10 leading-relaxed">
              Serenya centralise et prépare toutes vos démarches de changement d'adresse.
              Une seule saisie, zéro oubli, un accompagnement complet.
            </motion.p>

            <motion.div variants={fadeUp} transition={{ duration: 0.5 }}
              className="flex flex-col sm:flex-row gap-3 justify-center mb-12">
              <button onClick={() => document.getElementById("liste-attente")?.scrollIntoView({ behavior: "smooth" })}
                className="h-12 sm:h-14 px-7 sm:px-8 rounded-full bg-foreground text-background text-sm font-medium inline-flex items-center justify-center gap-2 hover:opacity-90 transition-all shadow-lg active:scale-[0.97] duration-150">
                <Rocket className="w-4 h-4" />
                Créer un compte gratuit
              </button>
              <Link href="/demo">
                <button className="h-12 sm:h-14 px-7 sm:px-8 rounded-full border border-border/60 text-sm font-medium inline-flex items-center justify-center gap-2 hover:bg-muted/50 transition-all active:scale-[0.97] duration-150">
                  Essayer gratuitement <ArrowUpRight className="w-4 h-4" />
                </button>
              </Link>
            </motion.div>

            <motion.div variants={fadeUp} transition={{ duration: 0.4 }}
              className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-muted-foreground/60">
              <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3 h-3 text-emerald-500/70" /> Gratuit</span>
              <span className="flex items-center gap-1.5"><Shield className="w-3 h-3 text-emerald-500/70" /> RGPD conforme</span>
              <span className="flex items-center gap-1.5"><Lock className="w-3 h-3 text-emerald-500/70" /> Sans engagement</span>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ═══════ SOCIAL PROOF ═══════ */}
      <SocialProofStrip stats={stats} />

      {/* ═══════ DASHBOARD PREVIEW ═══════ */}
      <section id="apercu" className="px-5 sm:px-8 pb-20 sm:pb-24 pt-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-100px" }} transition={{ duration: 0.7 }}
          >
            <DashboardMockup />
          </motion.div>
          <motion.p
            initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-center text-xs text-muted-foreground/40 mt-5"
          >
            Aperçu du tableau de bord Serenya · Données fictives
          </motion.p>
        </div>
      </section>

      {/* ═══════ VALUE PROP ═══════ */}
      <section id="pourquoi" className="py-24 sm:py-28 px-5 sm:px-8 border-y border-border/20">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="text-center mb-16"
          >
            <motion.p variants={fadeUp} className="text-xs text-muted-foreground/60 uppercase tracking-[0.2em] mb-4">
              Pourquoi Serenya
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
              Un déménagement,{" "}
              <span className="gradient-text">pas une charge mentale</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground max-w-lg mx-auto leading-relaxed">
              Changer d'adresse signifie contacter des dizaines d'organisations. Serenya fait tout à votre place — proprement, calmement, et avec votre accord à chaque étape.
            </motion.p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              { icon: Clock,    title: "Gagnez des heures",        desc: "Ce qui prenait une journée entière se fait maintenant en quelques minutes." },
              { icon: Shield,   title: "Restez serein",             desc: "Plus d'oubli, plus de stress. Chaque démarche est suivie et confirmée." },
              { icon: Zap,      title: "Gardez le contrôle",        desc: "Vous validez chaque action sensible. L'IA assiste, elle ne décide pas." },
            ].map((item, i) => (
              <motion.div key={item.title}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1, duration: 0.5 }}
                className="text-center"
              >
                <div className="w-12 h-12 rounded-2xl bg-primary/8 border border-primary/15 flex items-center justify-center mx-auto mb-5">
                  <item.icon className="w-5 h-5 text-primary/80" />
                </div>
                <h3 className="font-medium text-base mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════ HOW IT WORKS ═══════ */}
      <section id="fonctionnement" className="py-24 sm:py-28 px-5 sm:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="text-center mb-16"
          >
            <motion.p variants={fadeUp} className="text-xs text-muted-foreground/60 uppercase tracking-[0.2em] mb-4">
              Comment ça marche
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
              Quatre étapes,{" "}
              <span className="gradient-text">zéro complication</span>
            </motion.h2>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((step, i) => (
              <motion.div key={step.num}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1, duration: 0.5 }}
                className="relative"
              >
                <span className="absolute -top-3 -left-1 text-5xl font-bold text-primary/5 select-none">
                  {step.num}
                </span>
                <div className="pt-4">
                  <div className="w-10 h-10 rounded-xl bg-primary/8 border border-primary/15 flex items-center justify-center mb-4">
                    <step.icon className="w-4 h-4 text-primary/80" />
                  </div>
                  <h3 className="font-medium text-sm mb-2">{step.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{step.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════ USE CASES ═══════ */}
      <section id="cas-usages" className="py-24 sm:py-28 px-5 sm:px-8 border-y border-border/20">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger} className="text-center mb-16"
          >
            <motion.p variants={fadeUp} className="text-xs text-muted-foreground/60 uppercase tracking-[0.2em] mb-4">
              Pour qui
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
              Trois profils,{" "}
              <span className="gradient-text">un même soulagement</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground max-w-lg mx-auto leading-relaxed">
              Particuliers, professionnels, e-commerçants — chacun a ses organisations à notifier. Serenya s'adapte à votre situation.
            </motion.p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
            {[
              { icon: ShoppingCart, title: "E-commerce", desc: "Amazon, Cdiscount, Zalando, FNAC, Darty — mettez à jour votre adresse de livraison partout. Fini les colis envoyés chez l'ancien proprio.", color: "from-orange-500/20 to-amber-500/10", iconColor: "text-orange-500/80" },
              { icon: Truck, title: "Logistique & Livraison", desc: "Chronopost, La Poste, Colissimo, DHL — synchronisez votre nouvelle adresse chez tous vos transporteurs. Les factures suivent.", color: "from-blue-500/20 to-cyan-500/10", iconColor: "text-blue-500/80" },
              { icon: Briefcase, title: "Professionnels & CRM", desc: "Banques, assurances, mutuelles, impôts, énergie, internet — tous vos organismes administratifs mis à jour en une seule session.", color: "from-emerald-500/20 to-teal-500/10", iconColor: "text-emerald-500/80" },
            ].map((item, i) => (
              <motion.div key={item.title}
                initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1, duration: 0.5 }}
                className="group p-6 rounded-2xl border border-border/40 bg-card/30 hover:bg-card/50 hover:border-border/60 transition-all duration-300"
              >
                <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${item.color} flex items-center justify-center mb-4`}>
                  <item.icon className={`w-5 h-5 ${item.iconColor}`} />
                </div>
                <h3 className="font-medium text-base mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════ TRUST ═══════ */}
      <section id="confiance" className="py-24 sm:py-28 px-5 sm:px-8 border-y border-border/20 bg-card/[0.02]">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="text-center mb-16"
          >
            <motion.p variants={fadeUp} className="text-xs text-muted-foreground/60 uppercase tracking-[0.2em] mb-4">
              Confiance & Sécurité
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
              Vos données vous appartiennent{" "}
              <span className="gradient-text">et personne d'autre</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground max-w-lg mx-auto leading-relaxed">
              La confiance ne se décrète pas. Elle se construit avec transparence, respect et sécurité à chaque instant.
            </motion.p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {trustPoints.map((item, i) => (
              <motion.div key={item.title}
                initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.08, duration: 0.5 }}
                className="flex gap-4 p-5 rounded-2xl border border-border/40 bg-card/40 hover:border-border/60 transition-colors duration-300"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/8 flex items-center justify-center flex-shrink-0">
                  <item.icon className="w-4 h-4 text-primary/70" />
                </div>
                <div>
                  <h3 className="font-medium text-sm mb-1">{item.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ═══════ PREVIEW ═══════ */}
      <section id="experience" className="py-24 sm:py-28 px-5 sm:px-8">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-80px" }}
            variants={stagger}
            className="text-center mb-16"
          >
            <motion.p variants={fadeUp} className="text-xs text-muted-foreground/60 uppercase tracking-[0.2em] mb-4">
              L'expérience
            </motion.p>
            <motion.h2 variants={fadeUp} className="text-3xl sm:text-4xl font-semibold mb-5">
              Un tableau de bord{" "}
              <span className="gradient-text">calme et clair</span>
            </motion.h2>
            <motion.p variants={fadeUp} className="text-muted-foreground max-w-lg mx-auto leading-relaxed">
              Pas d'information superflue. Pas d'alerte agressive. Juste ce dont vous avez besoin, présenté avec soin.
            </motion.p>
          </motion.div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            {previewFeatures.map((item, i) => (
              <motion.div key={item.label}
                initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.08, duration: 0.4 }}
                className="p-5 rounded-2xl border border-border/40 bg-card/30 hover:bg-card/50 transition-colors duration-300"
              >
                <h3 className="font-medium text-sm mb-1.5">{item.label}</h3>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }} transition={{ duration: 0.6 }}
          >
            <DashboardMockup />
          </motion.div>
        </div>
      </section>

      {/* ═══════ TESTIMONIALS ═══════ */}
      <TestimonialsSection />

      {/* ═══════ WAITLIST ═══════ */}
      <WaitlistSection stats={stats} />

      {/* ═══════ FOOTER ═══════ */}
      <footer className="py-14 px-5 sm:px-8">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-6 mb-8">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-primary to-violet-600 flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold text-sm">Serenya</span>
            </div>
            <div className="flex items-center gap-6 text-xs text-muted-foreground/50">
              <Link href="/mentions-legales" className="hover:text-muted-foreground transition-colors duration-200">Mentions légales</Link>
              <Link href="/confidentialite" className="hover:text-muted-foreground transition-colors duration-200">Confidentialité</Link>
              <Link href="/cgu" className="hover:text-muted-foreground transition-colors duration-200">CGU</Link>
              <Link href="/contact" className="hover:text-muted-foreground transition-colors duration-200">Contact</Link>
            </div>
          </div>
          <div className="border-t border-border/20 pt-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground/30">
            <p>© 2026 Serenya. Tous droits réservés.</p>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1"><Globe className="w-3 h-3" /> Hébergé en Europe</span>
              <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> RGPD</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
