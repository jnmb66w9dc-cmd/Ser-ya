import AppLayout from "@/components/AppLayout";
import { User, Bell, Shield, LogOut, Moon, Sun, CheckCircle2, Zap, ShieldCheck, Building2, AlertTriangle, Download, Loader2, CreditCard, Crown, ArrowUpRight, ExternalLink, FileSpreadsheet, Trash2 } from "lucide-react";
import DeleteAccountDialog from "@/components/DeleteAccountDialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useUser, useClerk } from "@clerk/react";
import { useTheme } from "next-themes";
import { useState, useEffect, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { motion } from "@/lib/motion-compat";
import { cn } from "@/lib/utils";

const PREFS_KEY = "serenya_notif_prefs";

interface NotifPrefs {
  importantUpdates: boolean;
  allProgress: boolean;
  securityConfirm: boolean;
  orgCompletions: boolean;
  verificationRequests: boolean;
}

const DEFAULT_PREFS: NotifPrefs = {
  importantUpdates: true,
  allProgress: false,
  securityConfirm: true,
  orgCompletions: true,
  verificationRequests: true,
};

function loadPrefs(): NotifPrefs {
  try {
    const raw = localStorage.getItem(PREFS_KEY);
    if (!raw) return DEFAULT_PREFS;
    return { ...DEFAULT_PREFS, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PREFS;
  }
}

export default function SettingsPage() {
  const { user } = useUser();
  const { signOut, openUserProfile } = useClerk();
  const { theme, setTheme } = useTheme();
  const { toast } = useToast();
  const [prefs, setPrefs] = useState<NotifPrefs>(loadPrefs);
  const [isExporting, setIsExporting] = useState(false);
  const [subPlan, setSubPlan] = useState<string | null>(null);
  const [subLoading, setSubLoading] = useState(true);
  const [portalLoading, setPortalLoading] = useState(false);

  const loadSubscription = useCallback(async () => {
    try {
      const r = await fetch("/api/stripe/subscription", { credentials: "include" });
      if (r.ok) { const d = await r.json(); setSubPlan(d?.plan ?? "free"); }
      else setSubPlan("free");
    } catch { setSubPlan("free"); }
    finally { setSubLoading(false); }
  }, []);

  useEffect(() => { loadSubscription(); }, [loadSubscription]);

  async function handlePortal() {
    setPortalLoading(true);
    try {
      const r = await fetch("/api/stripe/portal", { method: "POST", credentials: "include" });
      const d = await r.json();
      if (d?.url) window.location.href = d.url;
    } catch { /* silent */ }
    finally { setPortalLoading(false); }
  }

  async function handleExport(format: "json" | "csv") {
    setIsExporting(true);
    try {
      const url = format === "csv" ? "/api/user/export-csv" : "/api/user/export";
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Export failed");
      const blob = await res.blob();
      const objUrl = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = objUrl;
      a.download = `serenya-export-${new Date().toISOString().split("T")[0]}.${format}`;
      a.click();
      URL.revokeObjectURL(objUrl);
      toast({ title: `Export ${format.toUpperCase()} téléchargé`, description: "Vos démarches et organismes sont dans le fichier." });
    } catch {
      toast({ variant: "destructive", title: "Export impossible", description: "Un petit souci technique. Réessayez dans quelques secondes — vos données sont en sécurité." });
    } finally {
      setIsExporting(false);
    }
  }

  useEffect(() => {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  }, [prefs]);

  const setPref = (key: keyof NotifPrefs) => (value: boolean) => {
    setPrefs((p) => ({ ...p, [key]: value }));
  };

  const notifCategories: {
    key: keyof NotifPrefs;
    icon: React.ElementType;
    iconColor: string;
    label: string;
    desc: string;
    badge?: string;
    badgeColor?: string;
  }[] = [
    {
      key: "importantUpdates",
      icon: AlertTriangle,
      iconColor: "text-amber-400",
      label: "Mises à jour importantes",
      desc: "Recevoir une alerte lorsqu'une action est requise de votre part.",
      badge: "Recommandé",
      badgeColor: "text-primary border-primary/30 bg-primary/5",
    },
    {
      key: "allProgress",
      icon: Zap,
      iconColor: "text-blue-400",
      label: "Toutes les progressions",
      desc: "Être notifié à chaque étape de traitement, même intermédiaire.",
    },
    {
      key: "orgCompletions",
      icon: Building2,
      iconColor: "text-emerald-400",
      label: "Validation par organisme",
      desc: "Recevoir une confirmation dès qu'un organisme valide votre adresse.",
      badge: "Recommandé",
      badgeColor: "text-primary border-primary/30 bg-primary/5",
    },
    {
      key: "verificationRequests",
      icon: CheckCircle2,
      iconColor: "text-violet-400",
      label: "Demandes de vérification",
      desc: "Être alerté lorsqu'un organisme demande une pièce justificative.",
    },
    {
      key: "securityConfirm",
      icon: ShieldCheck,
      iconColor: "text-rose-400",
      label: "Confirmations de sécurité",
      desc: "Notifications liées à votre compte (connexion, modification de profil).",
      badge: "Sécurité",
      badgeColor: "text-rose-400 border-rose-400/30 bg-rose-400/5",
    },
  ];

  const activeCount = Object.values(prefs).filter(Boolean).length;

  return (
    <AppLayout title="Paramètres">
      <div className="px-4 sm:px-6 lg:px-8 py-6 max-w-2xl mx-auto space-y-6">
        <div>
          <h2 className="text-2xl font-bold">Paramètres</h2>
          <p className="text-sm text-muted-foreground mt-0.5">Gérez votre compte et vos préférences.</p>
        </div>

        {/* Profile */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="p-5 border border-card-border hover:border-primary/15 transition-all duration-200">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <User className="w-4 h-4 text-primary" /> Profil
            </h3>
            <div className="flex items-center gap-4 mb-4">
              <Avatar className="w-14 h-14">
                <AvatarImage src={user?.imageUrl} />
                <AvatarFallback className="text-lg font-bold bg-primary/10 text-primary">
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold">{user?.firstName} {user?.lastName}</p>
                <p className="text-sm text-muted-foreground truncate">{user?.emailAddresses[0]?.emailAddress}</p>
                <Badge variant="outline" className="mt-1 text-xs text-green-500 border-green-500/30 bg-green-500/5">
                  Compte vérifié
                </Badge>
              </div>
            </div>
            <Button variant="outline" size="sm" className="gap-2" onClick={() => openUserProfile()}>
              <User className="w-3.5 h-3.5" /> Modifier le profil
            </Button>
          </Card>
        </motion.div>

        {/* Subscription */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.04 }}>
          <Card className="p-5 border border-card-border hover:border-primary/15 transition-all duration-200">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <CreditCard className="w-4 h-4 text-primary" /> Abonnement & Facturation
            </h3>
            {subLoading ? (
              <div className="flex items-center gap-3 py-2">
                <div className="w-8 h-8 rounded-xl bg-muted/50 animate-pulse" />
                <div className="space-y-1.5 flex-1">
                  <div className="h-3 bg-muted/50 rounded animate-pulse w-24" />
                  <div className="h-2.5 bg-muted/30 rounded animate-pulse w-36" />
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/30 border border-border/40">
                  <div className={cn(
                    "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0",
                    subPlan === "pro" || subPlan === "business" ? "bg-amber-400/10" : "bg-muted/50"
                  )}>
                    {subPlan === "pro" || subPlan === "business"
                      ? <Crown className="w-[18px] h-[18px] text-amber-400" />
                      : <Zap className="w-[18px] h-[18px] text-muted-foreground/50" />
                    }
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold">
                        Plan {subPlan === "pro" ? "Pro" : subPlan === "business" ? "Business" : "Essentiel"}
                      </p>
                      <Badge
                        variant="outline"
                        className={cn("text-xs h-4 px-1.5",
                          subPlan === "pro" || subPlan === "business"
                            ? "text-amber-400 border-amber-400/30 bg-amber-400/5"
                            : "text-muted-foreground border-border/60"
                        )}
                      >
                        {subPlan === "pro" || subPlan === "business" ? "Actif" : "Gratuit"}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {subPlan === "pro"
                        ? "Préparations illimitées · Sofia prioritaire"
                        : subPlan === "business"
                        ? "Équipe 5 comptes · API · SLA 99.9%"
                        : "2 préparations/mois · 5 services"
                      }
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  {(subPlan === "pro" || subPlan === "business") ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-2 text-xs"
                      onClick={handlePortal}
                      disabled={portalLoading}
                    >
                      {portalLoading
                        ? <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        : <ExternalLink className="w-3.5 h-3.5" />
                      }
                      Gérer mon abonnement
                    </Button>
                  ) : (
                    <a href="/pricing">
                      <Button size="sm" className="gap-2 text-xs shadow-md shadow-primary/20">
                        <ArrowUpRight className="w-3.5 h-3.5" />
                        Passer à Pro — dès 9,99 €/mois
                      </Button>
                    </a>
                  )}
                </div>
              </div>
            )}
          </Card>
        </motion.div>

        {/* Appearance */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 }}>
          <Card className="p-5 border border-card-border hover:border-primary/15 transition-all duration-200">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              {theme === "dark" ? <Moon className="w-4 h-4 text-primary" /> : <Sun className="w-4 h-4 text-primary" />}
              Apparence
            </h3>
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-sm font-medium">Mode sombre</Label>
                <p className="text-xs text-muted-foreground mt-0.5">Basculer entre le thème clair et sombre.</p>
              </div>
              <Switch
                checked={theme === "dark"}
                onCheckedChange={(v) => setTheme(v ? "dark" : "light")}
              />
            </div>
          </Card>
        </motion.div>

        {/* Notifications */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <Card className="p-5 border border-card-border hover:border-primary/15 transition-all duration-200">
            <div className="flex items-start justify-between mb-1">
              <h3 className="font-semibold text-sm flex items-center gap-2">
                <Bell className="w-4 h-4 text-primary" /> Notifications
              </h3>
              <span className="text-xs text-muted-foreground/60 font-medium tabular-nums">
                {activeCount}/{notifCategories.length} actives
              </span>
            </div>
            <p className="text-xs text-muted-foreground/60 mb-4">
              Choisissez comment Serenya vous informe de l'avancement de vos démarches.
            </p>
            <div className="space-y-0">
              {notifCategories.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.key}
                    className={cn(
                      "flex items-center justify-between py-3.5 gap-4",
                      idx < notifCategories.length - 1 && "border-b border-border/50"
                    )}
                  >
                    <div className="flex items-start gap-3 flex-1 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-muted/50 flex items-center justify-center flex-shrink-0 mt-0.5">
                        <Icon className={cn("w-3.5 h-3.5", item.iconColor)} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <Label className="text-sm font-medium cursor-pointer">{item.label}</Label>
                          {item.badge && (
                            <Badge variant="outline" className={cn("text-xs h-4 px-1.5", item.badgeColor)}>
                              {item.badge}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{item.desc}</p>
                      </div>
                    </div>
                    <Switch
                      checked={prefs[item.key]}
                      onCheckedChange={setPref(item.key)}
                      className="flex-shrink-0"
                    />
                  </div>
                );
              })}
            </div>

            {/* Calm footer message */}
            <div className="mt-4 pt-3 border-t border-border/50">
              <p className="text-xs text-muted-foreground/50 leading-relaxed">
                Vous pouvez modifier ces préférences à tout moment. Aucune donnée n'est partagée avec des tiers.
              </p>
            </div>
          </Card>
        </motion.div>

        {/* Security */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.15 }}>
          <Card className="p-5 border border-card-border hover:border-primary/15 transition-all duration-200">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4 text-primary" /> Sécurité
            </h3>
            <div className="space-y-3">
              {[
                { label: "Chiffrement des données", sub: "AES-256 bit actif", status: "Actif", color: "text-green-500" },
                { label: "Conformité RGPD", sub: "Données hébergées en Europe", status: "Conforme", color: "text-green-500" },
                { label: "Authentification sécurisée", sub: "Powered by Clerk", status: "Actif", color: "text-green-500" },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between border-b border-border/50 pb-3 last:border-0 last:pb-0">
                  <div>
                    <p className="text-sm font-medium">{item.label}</p>
                    <p className="text-xs text-muted-foreground">{item.sub}</p>
                  </div>
                  <span className={`text-xs font-medium ${item.color}`}>{item.status}</span>
                </div>
              ))}
            </div>
          </Card>
        </motion.div>

        {/* Data Export */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.175 }}>
          <Card className="p-5 border border-card-border hover:border-primary/15 transition-all duration-200">
            <h3 className="font-semibold text-sm mb-4 flex items-center gap-2">
              <Download className="w-4 h-4 text-primary" /> Vos données
            </h3>
            <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <p className="text-sm font-medium">Exporter mes données</p>
                <p className="text-xs text-muted-foreground mt-0.5">Téléchargez toutes vos démarches au format CSV (Excel) ou JSON (RGPD Art. 20).</p>
              </div>
              <div className="flex gap-2 flex-shrink-0">
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  disabled={isExporting}
                  onClick={() => handleExport("csv")}
                >
                  {isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <FileSpreadsheet className="w-3.5 h-3.5" />}
                  CSV
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2"
                  disabled={isExporting}
                  onClick={() => handleExport("json")}
                >
                  {isExporting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                  JSON
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Danger zone */}
        <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card className="p-5 border border-destructive/20 bg-destructive/[0.02]">
            <h3 className="font-semibold text-sm mb-4 text-destructive flex items-center gap-2">
              <Shield className="w-4 h-4" /> Zone de danger
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium">Se déconnecter</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Mettre fin à votre session actuelle.</p>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="gap-2 text-destructive border-destructive/30 hover:bg-destructive/5"
                  onClick={() => signOut()}
                >
                  <LogOut className="w-3.5 h-3.5" /> Déconnexion
                </Button>
              </div>
              <div className="border-t border-destructive/10 pt-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-destructive">Supprimer mon compte</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Suppression définitive de toutes vos données (RGPD Art. 17). Cette action est irréversible.</p>
                  </div>
                  <DeleteAccountDialog />
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>
    </AppLayout>
  );
}
