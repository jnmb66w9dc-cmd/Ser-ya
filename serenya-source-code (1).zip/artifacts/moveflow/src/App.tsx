import { lazy, Suspense, useEffect, useRef } from "react";
import { ClerkProvider, SignIn, SignUp, Show, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { frFR } from "@clerk/localizations";
import { Switch, Route, useLocation, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import CookieBanner from "@/components/CookieBanner";
import { ThemeProvider } from "next-themes";
import { Toaster } from "@/components/ui/toaster";
import ErrorBoundary from "@/components/ErrorBoundary";
import TopLoadingBar from "@/components/TopLoadingBar";
import SerenyaAuthPage from "@/components/SerenyaAuthPage";

/* Lazy-loaded pages for code-splitting */
const LandingPage = lazy(() => import("@/pages/landing"));
const DashboardPage = lazy(() => import("@/pages/dashboard"));
const ServicesPage = lazy(() => import("@/pages/services"));
const AddressesPage = lazy(() => import("@/pages/addresses"));
const AutomationsPage = lazy(() => import("@/pages/automations"));
const DocumentsPage = lazy(() => import("@/pages/documents"));
const TasksPage = lazy(() => import("@/pages/tasks"));
const SettingsPage = lazy(() => import("@/pages/settings"));
const NotFound = lazy(() => import("@/pages/not-found"));
const SharePage = lazy(() => import("@/pages/share"));
const PricingPage = lazy(() => import("@/pages/pricing"));
const PrivacyPage = lazy(() => import("@/pages/privacy"));
const TermsPage = lazy(() => import("@/pages/terms"));
const ContactPage = lazy(() => import("@/pages/contact"));
const MentionsLegalesPage = lazy(() => import("@/pages/mentions-legales"));
const OnboardingWizard = lazy(() => import("@/components/OnboardingWizard"));
const ChatWidget = lazy(() => import("@/components/ChatWidget"));

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { staleTime: 30_000, retry: 1 },
  },
});

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: "hsl(221 83% 53%)",
    colorForeground: "hsl(222 47% 8%)",
    colorMutedForeground: "hsl(220 9% 46%)",
    colorDanger: "hsl(0 84% 60%)",
    colorBackground: "hsl(0 0% 100%)",
    colorInput: "hsl(220 13% 88%)",
    colorInputForeground: "hsl(222 47% 8%)",
    colorNeutral: "hsl(220 13% 91%)",
    fontFamily: "Inter, sans-serif",
    borderRadius: "0.625rem",
  },
  elements: {
    rootBox: "w-full",
    cardBox: "w-full",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "hidden",
    headerSubtitle: "hidden",
    logoBox: "hidden",
    logoImage: "hidden",
    socialButtonsBlockButtonText: "text-foreground text-sm font-medium",
    formFieldLabel: "text-foreground text-sm font-medium",
    footerActionLink: "text-primary hover:text-primary/80 font-medium",
    footerActionText: "text-muted-foreground text-sm",
    dividerText: "text-muted-foreground text-xs",
    identityPreviewEditButton: "text-primary",
    formFieldSuccessText: "text-green-600",
    alertText: "text-sm",
    socialButtonsBlockButton: "border border-border hover:bg-muted transition-colors h-11",
    formButtonPrimary: "bg-primary hover:bg-primary/90 text-white h-11",
    formFieldInput: "border-input bg-background text-foreground h-11",
    footerAction: "border-t border-border pt-4 mt-2",
    dividerLine: "bg-border",
    alert: "border border-border",
    otpCodeFieldInput: "border-input h-11",
    formFieldRow: "gap-2",
    main: "gap-4 px-6 py-5",
    header: "hidden",
  },
};

function SignInPage() {
  return (
    <SerenyaAuthPage mode="sign-in">
      <SignIn
        routing="path"
        path={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        appearance={clerkAppearance}
      />
    </SerenyaAuthPage>
  );
}

function SignUpPage() {
  return (
    <SerenyaAuthPage mode="sign-up">
      <SignUp
        routing="path"
        path={`${basePath}/sign-up`}
        signInUrl={`${basePath}/sign-in`}
        appearance={clerkAppearance}
      />
    </SerenyaAuthPage>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function AppRoutes() {
  const [, setLocation] = useLocation();

  if (!clerkPubKey) {
    return (
      <div className="flex h-screen items-center justify-center text-muted-foreground text-sm">
        Configuration Clerk manquante.
      </div>
    );
  }

  return (
    <ClerkProvider
      publishableKey={clerkPubKey}
      proxyUrl={clerkProxyUrl}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={frFR}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <QueryClientProvider client={queryClient}>
        <ClerkQueryClientCacheInvalidator />
        <Suspense fallback={
          <div className="flex h-screen w-screen items-center justify-center bg-background">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
          </div>
        }>
          <Switch>
            <Route path="/" component={LandingPage} />
            <Route path="/landing" component={LandingPage} />
            <Route path="/demo" component={lazy(() => import("@/pages/demo"))} />
            <Route path="/sign-in/*?" component={SignInPage} />
            <Route path="/sign-up/*?" component={SignUpPage} />
            <Route path="/dashboard" component={DashboardPage} />
            <Route path="/services" component={ServicesPage} />
            <Route path="/addresses" component={AddressesPage} />
            <Route path="/automations" component={AutomationsPage} />
            <Route path="/documents" component={DocumentsPage} />
            <Route path="/tasks" component={TasksPage} />
            <Route path="/settings" component={SettingsPage} />
            <Route path="/pricing" component={PricingPage} />
            <Route path="/confidentialite" component={PrivacyPage} />
            <Route path="/cgu" component={TermsPage} />
            <Route path="/contact" component={ContactPage} />
            <Route path="/mentions-legales" component={MentionsLegalesPage} />
            <Route path="/partage/:token" component={SharePage} />
            <Route component={NotFound} />
          </Switch>
        </Suspense>
        <TopLoadingBar />
        <Toaster />
        <OnboardingWizard />
        <ChatWidget />
      </QueryClientProvider>
    </ClerkProvider>
  );
}

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider attribute="class" defaultTheme="dark" enableSystem>
        <WouterRouter base={basePath}>
          <AppRoutes />
        </WouterRouter>
        <CookieBanner />
      </ThemeProvider>
    </ErrorBoundary>
  );
}
