// ─────────────────────────────────────────────────────────────────────────────
// Service Knowledge Base — Real preparation steps for French address changes
// Zero AI cost: rule-based, generated from real administrative procedures
// ─────────────────────────────────────────────────────────────────────────────

export interface ServiceKnowledge {
  serviceName: string;
  category: string;
  steps: { type: "info" | "action" | "success" | "warning"; message: string }[];
  documentsNeeded: string[];
  estimatedTime: string;
  difficulty: "facile" | "moyen" | "difficile";
  url: string;
  tips: string[];
}

const KNOWLEDGE: Record<string, ServiceKnowledge> = {
  Amazon: {
    serviceName: "Amazon",
    category: "e-commerce",
    steps: [
      { type: "info", message: "Connectez-vous a votre compte Amazon.fr" },
      { type: "action", message: "Allez dans 'Vos adresses' depuis le menu Compte" },
      { type: "action", message: "Cliquez 'Ajouter une adresse' et saisissez votre nouvelle adresse" },
      { type: "success", message: "Definissez-la comme adresse par defaut pour les livraisons et facturations" },
      { type: "warning", message: "Pensez a mettre a jour aussi votre adresse sur Amazon Prime Video si differente" },
    ],
    documentsNeeded: ["Aucun document requis"],
    estimatedTime: "2-3 jours",
    difficulty: "facile",
    url: "https://www.amazon.fr/a/addresses",
    tips: ["Les commandes en cours resteront a l'ancienne adresse — annulez-les si besoin"],
  },
  EDF: {
    serviceName: "EDF",
    category: "energie",
    steps: [
      { type: "info", message: "Accedez a votre espace client EDF (particulier.edf.fr)" },
      { type: "action", message: "Dans 'Mon profil', cliquez sur 'Modifier mon adresse'" },
      { type: "info", message: "Pour un demenagement, vous devez resilier l'ancien contrat et en ouvrir un nouveau" },
      { type: "action", message: "Demandez l'ouverture du compteur a la nouvelle adresse (cout ~18,46€ TTC)" },
      { type: "success", message: "Votre contrat sera transfere sous 5 jours ouvres" },
    ],
    documentsNeeded: ["Justificatif de domicile de moins de 3 mois", "Identite (CNI/passeport)", "Point de comptage (PCE) si gaz"],
    estimatedTime: "5-10 jours",
    difficulty: "moyen",
    url: "https://particulier.edf.fr",
    tips: ["Prevoyez 2 semaines avant le demenagement pour EDF", "Notez votre numero de contrat (11 chiffres)"],
  },
  Orange: {
    serviceName: "Orange",
    category: "telecom",
    steps: [
      { type: "info", message: "Connectez-vous sur l'espace client Orange (moncompte.orange.fr)" },
      { type: "action", message: "Dans 'Ma ligne', selectionnez 'Modifier mon adresse'" },
      { type: "info", message: "Pour un demenagement, demandez le transfert de votre ligne fixe" },
      { type: "action", message: "Fixez un rendez-vous avec un technicien pour le branchement fibre/ADSL" },
      { type: "success", message: "La nouvelle ligne sera active le jour du rendez-vous" },
    ],
    documentsNeeded: ["Justificatif de domicile", "Identite", "RIB (pour prelevement)"],
    estimatedTime: "7-14 jours",
    difficulty: "moyen",
    url: "https://moncompte.orange.fr",
    tips: ["Deplacez votre box au moins 3 semaines a l'avance", "Verifiez la fibre disponible a la nouvelle adresse sur orange.fr"],
  },
  "PayPal": {
    serviceName: "PayPal",
    category: "finance",
    steps: [
      { type: "info", message: "Connectez-vous a paypal.com avec vos identifiants" },
      { type: "action", message: "Allez dans 'Parametres' > 'Adresses'" },
      { type: "action", message: "Ajoutez la nouvelle adresse puis supprimez l'ancienne" },
      { type: "success", message: "Verifiez que l'adresse de facturation est bien mise a jour" },
    ],
    documentsNeeded: ["Aucun document requis"],
    estimatedTime: "1 jour",
    difficulty: "facile",
    url: "https://www.paypal.com",
    tips: ["Verifiez aussi votre adresse bancaire liee si vous changez de banque"],
  },
  Free: {
    serviceName: "Free",
    category: "telecom",
    steps: [
      { type: "info", message: "Connectez-vous sur l'espace abonne Free (mobile.free.fr)" },
      { type: "action", message: "Dans 'Mon Compte' > 'Modifier mes coordonnees'" },
      { type: "info", message: "Pour un demenagement, demandez le transfert de ligne fixe/box" },
      { type: "action", message: "Planifiez un rendez-vous pour le demenagement de la box" },
      { type: "success", message: "Le transfert est gratuit et garanti sous 30 jours" },
    ],
    documentsNeeded: ["Justificatif de domicile", "Identite"],
    estimatedTime: "7-21 jours",
    difficulty: "moyen",
    url: "https://mobile.free.fr",
    tips: ["Le demenagement Freebox est gratuit", "Si pas de fibre, vous serez bascule en ADSL automatiquement"],
  },
  "BNP Paribas": {
    serviceName: "BNP Paribas",
    category: "banque",
    steps: [
      { type: "info", message: "Connectez-vous a l'espace client BNP Paribas (mabanque.bnpparibas)" },
      { type: "action", message: "'Mon profil' > 'Modifier mon adresse'" },
      { type: "info", message: "Vous devez signer electroniquement la modification" },
      { type: "warning", message: "Pour un changement de domicile a l'etranger, contactez votre conseiller" },
      { type: "success", message: "La modification est effective sous 48h" },
    ],
    documentsNeeded: ["Justificatif de domicile de moins de 3 mois"],
    estimatedTime: "2-5 jours",
    difficulty: "facile",
    url: "https://mabanque.bnpparibas",
    tips: ["Pensez a mettre a jour votre adresse dans l'appli Wallet si vous l'utilisez"],
  },
  AXA: {
    serviceName: "AXA",
    category: "assurance",
    steps: [
      { type: "info", message: "Connectez-vous a axa.fr avec votre compte" },
      { type: "action", message: "'Mes contrats' > 'Modifier mes coordonnees'" },
      { type: "info", message: "L'adresse est partagee entre auto, habitation et sante" },
      { type: "success", message: "Votre conseiller AXA sera notifie automatiquement" },
    ],
    documentsNeeded: ["Justificatif de domicile"],
    estimatedTime: "3-5 jours",
    difficulty: "facile",
    url: "https://www.axa.fr",
    tips: ["Verifiez que votre contrat habitation couvre bien la nouvelle adresse"],
  },
  "Societe Generale": {
    serviceName: "Societe Generale",
    category: "banque",
    steps: [
      { type: "info", message: "Ouvrez l'application SG ou connectez-vous sur particuliers.societegenerale.fr" },
      { type: "action", message: "'Mes coordonnees' > 'Modifier mon adresse'" },
      { type: "info", message: "Validez avec votre code securite (SMS ou appli SG Authenticator)" },
      { type: "success", message: "Mise a jour confirme sous 24h" },
    ],
    documentsNeeded: ["Justificatif de domicile"],
    estimatedTime: "1-3 jours",
    difficulty: "facile",
    url: "https://particuliers.societegenerale.fr",
    tips: ["En cas de demenagement a l'etranger, contactez directement votre agence"],
  },
  MAIF: {
    serviceName: "MAIF",
    category: "assurance",
    steps: [
      { type: "info", message: "Connectez-vous a l'espace adherent MAIF (maif.fr)" },
      { type: "action", message: "'Mon espace' > 'Mes coordonnees' > 'Adresse'" },
      { type: "info", message: "Mettez a jour l'adresse pour tous vos contrats (auto, habitation, sante)" },
      { type: "success", message: "Un conseiller MAIF vous contactera pour confirmer" },
    ],
    documentsNeeded: ["Justificatif de domicile"],
    estimatedTime: "3-7 jours",
    difficulty: "facile",
    url: "https://www.maif.fr",
    tips: ["Si vous demenagez, pensez a verifier votre niveau de couverture habitation"],
  },
  "La Poste": {
    serviceName: "La Poste",
    category: "administration",
    steps: [
      { type: "info", message: "Creez un compte sur laposte.fr si ce n'est pas deja fait" },
      { type: "action", message: "'Mon espace' > 'Changement d'adresse'" },
      { type: "info", message: "Activez la reexpedition du courrier (Redirection France — 1€/mois)" },
      { type: "action", message: "Saisissez votre nouvelle adresse et dates de debut/fin de redirection" },
      { type: "success", message: "Le courrier sera reexpedie pendant 6 ou 12 mois selon l'option choisie" },
    ],
    documentsNeeded: ["Justificatif de domicile de moins de 3 mois", "Identite", "Attestation d'hebergement si locataire"],
    estimatedTime: "5-10 jours",
    difficulty: "moyen",
    url: "https://www.laposte.fr/mon-espace/changement-d-adresse",
    tips: ["Commandez la redirection au moins 5 jours avant le demenagement", "Pensez a informer aussi les expediteurs reguliers (famille, employeur)"],
  },
  Netflix: {
    serviceName: "Netflix",
    category: "abonnement",
    steps: [
      { type: "info", message: "Connectez-vous a netflix.com et allez dans 'Compte'" },
      { type: "action", message: "'Details de facturation' > 'Modifier le mode de paiement'" },
      { type: "action", message: "Mettez a jour l'adresse de facturation" },
      { type: "success", message: "Aucun impact sur votre historique ni vos listes" },
    ],
    documentsNeeded: ["Aucun document requis"],
    estimatedTime: "1 jour",
    difficulty: "facile",
    url: "https://www.netflix.com",
    tips: ["Si vous demenagez dans un pays different, verifiez le catalogue disponible"],
  },
  Spotify: {
    serviceName: "Spotify",
    category: "abonnement",
    steps: [
      { type: "info", message: "Connectez-vous a spotify.com/account" },
      { type: "action", message: "'Modifier le profil' > 'Pays ou region'" },
      { type: "info", message: "Spotify utilise l'adresse pour determiner votre pays et le prix de l'abonnement" },
      { type: "success", message: "Mettez a jour si vous changez de pays, sinon facultatif" },
    ],
    documentsNeeded: ["Aucun document requis"],
    estimatedTime: "1 jour",
    difficulty: "facile",
    url: "https://www.spotify.com/account",
    tips: ["Le changement de pays peut modifier le prix de l'abonnement"],
  },
  SNCF: {
    serviceName: "SNCF",
    category: "transport",
    steps: [
      { type: "info", message: "Connectez-vous a votre compte SNCF Connect (sncf-connect.com)" },
      { type: "action", message: "'Mon compte' > 'Mes informations' > 'Adresse'" },
      { type: "success", message: "Mettez a jour l'adresse pour la livraison des cartes et abonnements" },
    ],
    documentsNeeded: ["Aucun document requis"],
    estimatedTime: "1-2 jours",
    difficulty: "facile",
    url: "https://www.sncf-connect.com",
    tips: ["Pensez a mettre a jour aussi votre adresse sur votre carte de reduction"],
  },
  Engie: {
    serviceName: "Engie",
    category: "energie",
    steps: [
      { type: "info", message: "Connectez-vous a votre espace client Engie (engie.fr)" },
      { type: "action", message: "'Mon contrat' > 'Modifier mes coordonnees'" },
      { type: "info", message: "Pour un demenagement, vous devez resilier et souscrire un nouveau contrat" },
      { type: "action", message: "Demandez l'ouverture du compteur gaz a la nouvelle adresse" },
      { type: "success", message: "Un technicien GRDF intervient sous 5 jours ouvres" },
    ],
    documentsNeeded: ["Identite", "Justificatif de domicile", "Numero PCE (Point de Comptage Energie) si connu"],
    estimatedTime: "5-10 jours",
    difficulty: "moyen",
    url: "https://particuliers.engie.fr",
    tips: ["Notez le releve du compteur a l'ancienne adresse le jour du depart", "Prevoyez 2 semaines d'avance"],
  },
  "Credit Agricole": {
    serviceName: "Credit Agricole",
    category: "banque",
    steps: [
      { type: "info", message: "Ouvrez l'appli Ma Banque ou connectez-vous sur le site regional" },
      { type: "action", message: "'Mon profil' > 'Coordonnees' > 'Modifier mon adresse'" },
      { type: "info", message: "Validez avec votre code confidentiel ou empreinte digitale" },
      { type: "success", message: "Mise a jour effective sous 24-48h" },
    ],
    documentsNeeded: ["Justificatif de domicile de moins de 3 mois"],
    estimatedTime: "2-5 jours",
    difficulty: "facile",
    url: "https://www.credit-agricole.fr",
    tips: ["Chaque region a son propre site web (ex: credit-agricole.fr/ca-paris)"],
  },
  "Caisse d'Epargne": {
    serviceName: "Caisse d'Epargne",
    category: "banque",
    steps: [
      { type: "info", message: "Connectez-vous sur le site de la Caisse d'Epargne" },
      { type: "action", message: "'Espace Client' > 'Mes coordonnees' > 'Modifier'" },
      { type: "info", message: "Vous devrez signer electroniquement la modification" },
      { type: "success", message: "La modification est prise en compte sous 48h" },
    ],
    documentsNeeded: ["Justificatif de domicile"],
    estimatedTime: "2-5 jours",
    difficulty: "facile",
    url: "https://www.caisse-epargne.fr",
    tips: ["En cas de difficulte, contactez votre conseiller par l'appli Mes Messages"],
  },
  LCL: {
    serviceName: "LCL",
    category: "banque",
    steps: [
      { type: "info", message: "Connectez-vous a l'espace client LCL (lcl.fr)" },
      { type: "action", message: "'Mon profil' > 'Modifier mon adresse postale'" },
      { type: "info", message: "Validez avec le code recu par SMS" },
      { type: "success", message: "Adresse mise a jour immediatement pour tous vos contrats" },
    ],
    documentsNeeded: ["Justificatif de domicile"],
    estimatedTime: "1-3 jours",
    difficulty: "facile",
    url: "https://www.lcl.fr",
    tips: ["Si vous changez de region, votre agence de rattachement reste la meme"],
  },
  SFR: {
    serviceName: "SFR",
    category: "telecom",
    steps: [
      { type: "info", message: "Connectez-vous a l'espace client SFR (espace-client.sfr.fr)" },
      { type: "action", message: "'Mon offre' > 'Modifier mon adresse'" },
      { type: "info", message: "Pour un demenagement, demandez le transfert de ligne/box" },
      { type: "action", message: "Planifiez une intervention technique pour le branchement" },
      { type: "success", message: "Le transfert est facture 59€ (box) ou gratuit (mobile)" },
    ],
    documentsNeeded: ["Justificatif de domicile", "Identite"],
    estimatedTime: "7-14 jours",
    difficulty: "moyen",
    url: "https://espace-client.sfr.fr",
    tips: ["Le demenagement box SFR coute 59€ (facture en 3 fois)", "Verifiez la fibre a la nouvelle adresse"],
  },
  "Bouygues Telecom": {
    serviceName: "Bouygues Telecom",
    category: "telecom",
    steps: [
      { type: "info", message: "Connectez-vous a votre espace client Bouygues (bouyguestelecom.fr)" },
      { type: "action", message: "'Ma ligne' > 'Demenager ma ligne'" },
      { type: "info", message: "Remplissez le formulaire de demande de transfert" },
      { type: "action", message: "Planifiez un rendez-vous avec un technicien" },
      { type: "success", message: "Le transfert est gratuit si vous restez en France metropolitaine" },
    ],
    documentsNeeded: ["Justificatif de domicile", "Identite"],
    estimatedTime: "7-14 jours",
    difficulty: "moyen",
    url: "https://www.bouyguestelecom.fr",
    tips: ["Le demenagement est gratuit pour les lignes fixes", "Pensez a mettre a jour aussi les lignes mobiles associees"],
  },
  "Impots": {
    serviceName: "Impots",
    category: "administration",
    steps: [
      { type: "info", message: "Connectez-vous a impots.gouv.fr avec FranceConnect ou vos identifiants" },
      { type: "action", message: "'Mon profil' > 'Modifier mon adresse'" },
      { type: "info", message: "Cette adresse est utilisee pour votre domicile fiscal et l'envoi des avis d'imposition" },
      { type: "warning", message: "Si vous demenagez le 31 decembre, vous serez impose selon votre ancienne commune" },
      { type: "success", message: "La modification est prise en compte pour l'annee fiscale suivante" },
    ],
    documentsNeeded: ["Identite", "Justificatif de domicile de moins de 3 mois (optionnel)"],
    estimatedTime: "1-3 jours",
    difficulty: "facile",
    url: "https://www.impots.gouv.fr/accueil",
    tips: ["Declarez votre changement d'adresse AVANT le 31 decembre pour l'annee suivante", "Pensez a mettre a jour aussi l'adresse de vos ayants droit"],
  },
  CAF: {
    serviceName: "CAF",
    category: "administration",
    steps: [
      { type: "info", message: "Connectez-vous a caf.fr avec votre numero d'allocataire" },
      { type: "action", message: "'Mon Compte' > 'Mes coordonnees' > 'Modifier mon adresse'" },
      { type: "info", message: "L'adresse est essentielle pour le calcul des APL et autres aides" },
      { type: "warning", message: "Si vous emmenagez dans un nouveau logement, declarez aussi le changement de loyer" },
      { type: "success", message: "La CAF mettra a jour vos droits sous 48h" },
    ],
    documentsNeeded: ["Identite", "Attestation de loyer ou titre de propriete", "RIB"],
    estimatedTime: "3-7 jours",
    difficulty: "moyen",
    url: "https://www.caf.fr",
    tips: ["Declarez le changement de situation dans les 3 mois pour eviter un trop-percu", "Preparez votre nouvel attestation de loyer"],
  },
  Cpam: {
    serviceName: "Cpam",
    category: "administration",
    steps: [
      { type: "info", message: "Connectez-vous a ameli.fr avec votre numero de securite sociale" },
      { type: "action", message: "'Mon profil' > 'Mes coordonnees' > 'Modifier mon adresse'" },
      { type: "info", message: "Cette adresse est utilisee pour l'envoi de la Carte Vitale et des remboursements" },
      { type: "success", message: "La modification est effective sous 5 jours ouvres" },
    ],
    documentsNeeded: ["Identite", "Justificatif de domicile de moins de 3 mois"],
    estimatedTime: "5-10 jours",
    difficulty: "moyen",
    url: "https://www.ameli.fr",
    tips: ["Si vous changez de departement, votre CPAM de rattachement changera automatiquement", "Commandez une nouvelle Carte Vitale si l'ancienne est endommagee"],
  },
  "Pole Emploi": {
    serviceName: "Pole Emploi",
    category: "administration",
    steps: [
      { type: "info", message: "Connectez-vous a pole-emploi.fr avec vos identifiants" },
      { type: "action", message: "'Mon espace' > 'Mes coordonnees' > 'Modifier mon adresse'" },
      { type: "info", message: "Cette adresse est utilisee pour l'envoi des courriers et des convocations" },
      { type: "warning", message: "Si vous demenagez a l'etranger, contactez votre conseiller" },
      { type: "success", message: "La mise a jour est immediate" },
    ],
    documentsNeeded: ["Identite", "Justificatif de domicile"],
    estimatedTime: "1-3 jours",
    difficulty: "facile",
    url: "https://www.pole-emploi.fr",
    tips: ["Pensez a mettre a jour aussi l'adresse dans votre espace personnel Pole emploi"],
  },
  "Banque Postale": {
    serviceName: "Banque Postale",
    category: "banque",
    steps: [
      { type: "info", message: "Connectez-vous a l'espace client Banque Postale (labanquepostale.fr)" },
      { type: "action", message: "'Mon profil' > 'Modifier mon adresse'" },
      { type: "info", message: "Validez avec votre code confidentiel" },
      { type: "success", message: "Mise a jour confirmee sous 48h" },
    ],
    documentsNeeded: ["Justificatif de domicile"],
    estimatedTime: "2-5 jours",
    difficulty: "facile",
    url: "https://www.labanquepostale.fr",
    tips: ["Si vous changez de ville, vous pouvez changer d'agence de rattachement sur demande"],
  },
};

// Default fallback for unknown services
const DEFAULT_KNOWLEDGE: ServiceKnowledge = {
  serviceName: "Service",
  category: "divers",
  steps: [
    { type: "info", message: "Connectez-vous a l'espace client du service" },
    { type: "action", message: "Recherchez 'Modifier mon adresse' ou 'Changement d'adresse' dans les parametres" },
    { type: "info", message: "Preparez un justificatif de domicile recent (moins de 3 mois)" },
    { type: "success", message: "Confirmez la modification et verifiez la confirmation par e-mail" },
  ],
  documentsNeeded: ["Justificatif de domicile de moins de 3 mois", "Piece d'identite"],
  estimatedTime: "3-7 jours",
  difficulty: "moyen",
  url: "",
  tips: ["Prevoyez 2 semaines pour traiter la demande", "Gardez une copie de la confirmation"],
};

export function getServiceKnowledge(name: string): ServiceKnowledge {
  return KNOWLEDGE[name] ?? DEFAULT_KNOWLEDGE;
}

export function buildAutomationPlan(
  services: { id: number; name: string; category: string }[],
  address: { street: string; complement?: string | null; postalCode: string; city: string; country: string }
) {
  const plan = services.map((s) => {
    const k = getServiceKnowledge(s.name);
    return {
      serviceId: s.id,
      serviceName: s.name,
      category: s.category,
      steps: k.steps,
      documentsNeeded: k.documentsNeeded,
      estimatedTime: k.estimatedTime,
      difficulty: k.difficulty,
      url: k.url,
    };
  });

  const allDocs = [...new Set(plan.flatMap((p) => p.documentsNeeded))];
  const totalServices = plan.length;

  // Estimate total time based on difficulty distribution
  let estMin = 0;
  let estMax = 0;
  plan.forEach((p) => {
    const match = p.estimatedTime.match(/(\d+)(?:-(\d+))?/);
    if (match) {
      estMin += parseInt(match[1], 10);
      estMax += parseInt(match[2] || match[1], 10);
    }
  });

  // Build tips from service-specific tips
  const allTips = [...new Set(services.map((s) => getServiceKnowledge(s.name).tips).flat())];

  // Always add universal tips
  const universalTips = [
    "Pensez a la reexpedition du courrier via La Poste pour ne rien manquer",
    "Certains organismes demandent un justificatif de domicile de moins de 3 mois",
    "Faites un tableau de suivi pour ne pas oublier un service",
  ];

  return {
    plan,
    summary: {
      totalServices,
      totalDocuments: allDocs.length,
      estimatedTotalTime: `${estMin}-${estMax} jours`,
      tips: [...allTips.slice(0, 3), ...universalTips].slice(0, 4),
    },
  };
}
