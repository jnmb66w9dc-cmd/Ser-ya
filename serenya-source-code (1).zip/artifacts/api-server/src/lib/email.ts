import { logger } from "./logger";

/**
 * Email service using Resend for transactional emails.
 * Falls back to logging when RESEND_API_KEY is not configured.
 */

const RESEND_API_KEY = process.env.RESEND_API_KEY;
const FROM_EMAIL = process.env.FROM_EMAIL ?? "Serenya <noreply@serenya.app>";
const ADMIN_EMAIL = process.env.ADMIN_EMAIL; // Your admin email for user alerts

interface SendEmailOptions {
  to: string | string[];
  subject: string;
  html: string;
  text?: string;
}

export async function sendEmail({ to, subject, html, text }: SendEmailOptions): Promise<{ ok: boolean; error?: string }> {
  if (!RESEND_API_KEY) {
    logger.info({ to, subject }, "Email skipped — RESEND_API_KEY not configured");
    return { ok: true };
  }

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: FROM_EMAIL,
        to: Array.isArray(to) ? to : [to],
        subject,
        html,
        text: text ?? html.replace(/<[^>]*>/g, "").replace(/\s+/g, " ").trim(),
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      logger.error({ status: res.status, body, to, subject }, "Resend email failed");
      return { ok: false, error: `Resend error ${res.status}: ${body}` };
    }

    logger.info({ to, subject }, "Email sent via Resend");
    return { ok: true };
  } catch (err) {
    logger.error({ err, to, subject }, "Email send exception");
    return { ok: false, error: "Network error" };
  }
}

/**
 * Notify admin when a user creates their first automation or signs up.
 */
export async function notifyAdminNewUser(userEmail: string, userName?: string): Promise<void> {
  if (!ADMIN_EMAIL) return;

  const html = `
    <h2>Nouvel utilisateur Serenya</h2>
    <p><strong>Email:</strong> ${userEmail}</p>
    <p><strong>Nom:</strong> ${userName ?? "Non renseigné"}</p>
    <p><strong>Date:</strong> ${new Date().toLocaleString("fr-FR")}</p>
    <hr>
    <p style="color:#666;font-size:12px;">Notification automatique de Serenya</p>
  `;

  await sendEmail({
    to: ADMIN_EMAIL,
    subject: `📧 Nouvel utilisateur — ${userEmail}`,
    html,
  });
}

/**
 * Notify admin of new automation created by user.
 */
export async function notifyAdminAutomation(userEmail: string, automationId: number, addressLabel: string, serviceCount: number): Promise<void> {
  if (!ADMIN_EMAIL) return;

  const html = `
    <h2>Nouvelle automation lancée</h2>
    <p><strong>Utilisateur:</strong> ${userEmail}</p>
    <p><strong>Adresse:</strong> ${addressLabel}</p>
    <p><strong>Services:</strong> ${serviceCount}</p>
    <p><strong>ID:</strong> ${automationId}</p>
    <p><strong>Date:</strong> ${new Date().toLocaleString("fr-FR")}</p>
    <hr>
    <p style="color:#666;font-size:12px;">Notification automatique de Serenya</p>
  `;

  await sendEmail({
    to: ADMIN_EMAIL,
    subject: `⚡ Nouvelle automation — ${addressLabel} (${serviceCount} services)`,
    html,
  });
}

/**
 * Send tracking status update email to user.
 */
export async function sendTrackingUpdate(userEmail: string, serviceName: string, trackingStatus: string, description: string): Promise<void> {
  const statusLabels: Record<string, string> = {
    prepared: "Préparé",
    submitted: "Soumis",
    acknowledged: "Reçu",
    processing: "En cours",
    completed: "Terminé",
    failed: "Action requise",
  };

  const label = statusLabels[trackingStatus] ?? trackingStatus;

  const html = `
    <div style="max-width:500px;margin:0 auto;font-family:sans-serif;">
      <h2 style="color:#6366f1;">Serenya — Suivi de votre changement d'adresse</h2>
      <p>Bonjour,</p>
      <p>Votre demande de changement d'adresse pour <strong>${serviceName}</strong> a changé de statut :</p>
      <div style="padding:16px;background:#f8fafc;border-radius:8px;margin:16px 0;">
        <p style="margin:0;font-size:18px;font-weight:bold;color:#6366f1;">${label}</p>
        <p style="margin:8px 0 0;color:#64748b;font-size:14px;">${description}</p>
      </div>
      <p>Connectez-vous à votre <a href="${process.env.APP_URL ?? "#"}/dashboard" style="color:#6366f1;">tableau de bord Serenya</a> pour suivre l'avancement en temps réel.</p>
      <hr style="border:none;border-top:1px solid #e2e8f0;margin:24px 0;">
      <p style="color:#94a3b8;font-size:12px;">Vous gardez le contrôle · Aucune modification sans votre accord</p>
    </div>
  `;

  await sendEmail({
    to: userEmail,
    subject: `Serenya — ${serviceName} : ${label}`,
    html,
  });
}
