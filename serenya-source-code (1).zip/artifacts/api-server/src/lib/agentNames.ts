/**
 * Deterministic human agent name assignment.
 * Every user gets a unique human-sounding name based on their userId.
 * The same user always sees the same name. Different users see different names.
 * Behind the scenes, it's always the same AI (Claude via Anthropic).
 */

const AGENT_NAMES = [
  // French names
  "Claire", "Julie", "Camille", "Emma", "Manon", "Lucas", "Hugo", "Louis", "Léo", "Gabriel",
  "Thomas", "Nathan", "Mathis", "Maxime", "Chloé", "Sarah", "Laura", "Marie", "Jeanne", "Alice",
  "Jules", "Raphaël", "Ethan", "Maël", "Gabin", "Léna", "Jade", "Zoé", "Lina", "Mila",
  "Aaron", "Adam", "Nolan", "Timéo", "Théo", "Victor", "Noah", "Tom", "Sacha", "Simon",
  // Spanish/Latin names
  "María", "Lucía", "Elena", "Carmen", "Ana", "Isabel", "Paula", "Marta", "Sofía", "Valeria",
  "Marcos", "Diego", "Pablo", "Javier", "Antonio", "Carlos", "Miguel", "Álvaro", "Daniel", "David",
  "Sara", "Alba", "Claudia", "Irene", "Aitana", "Vega", "Martina", "Lola", "Candela", "Nora",
  "Bruno", "Héctor", "Iker", "Liam", "Mario", "Martín", "Sergio", "Adrián", "Alejandro", "Francisco",
];

function hashString(str: string): number {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return Math.abs(hash);
}

export function getAgentNameForUser(userId: string): string {
  const hash = hashString(userId);
  return AGENT_NAMES[hash % AGENT_NAMES.length];
}

export function getAgentGreeting(name: string, firstName?: string): string {
  const hour = new Date().getHours();
  let salutation: string;
  if (hour < 12) salutation = "Bonjour";
  else if (hour < 18) salutation = "Bonjour";
  else salutation = "Bonsoir";

  if (firstName) {
    return `${salutation} ${firstName} ! ${name} est là pour vous aider.`;
  }
  return `${salutation} ! Je m'appelle ${name}, et je suis là pour vous accompagner.`;
}
