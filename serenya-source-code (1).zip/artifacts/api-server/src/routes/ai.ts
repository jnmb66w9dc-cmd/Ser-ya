import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, automationsTable, automationTasksTable, userServicesTable, servicesTable, addressesTable } from "@workspace/db";
import { eq, desc, and, inArray } from "drizzle-orm";
import { buildAutomationPlan } from "../lib/serviceKnowledge";
import { getAgentNameForUser, getAgentGreeting } from "../lib/agentNames";

/* ═══════════════════════════════════════════════════════════════════════════════ */
// In-memory cache for automation plans (TTL 5 min) — zero AI cost for repeated calls
const planCache = new Map<string, { plan: any; ts: number }>();
const PLAN_CACHE_TTL = 5 * 60 * 1000; // 5 minutes
const SIM_RATE_LIMIT = new Map<string, number>(); // userId → last sim timestamp
const SIM_COOLDOWN = 60 * 1000; // 1 minute between simulations

function getCacheKey(userId: string, addressId: number, serviceIds: number[]): string {
  return `${userId}-${addressId}-${serviceIds.slice().sort().join(",")}`;
}

function cleanCache() {
  const now = Date.now();
  for (const [key, entry] of planCache) {
    if (now - entry.ts > PLAN_CACHE_TTL) planCache.delete(key);
  }
}

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Non autorisé" });
  next();
}

// ── GET /api/ai/user-context ────────────────────────────────────────────────────
// Returns aggregated user context (no LLM call — raw data only)
router.get("/user-context", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);

  const [automations, connectedServices] = await Promise.all([
    db.select().from(automationsTable).where(eq(automationsTable.userId, userId!)).orderBy(desc(automationsTable.createdAt)).limit(10),
    db.select({
      id: userServicesTable.id,
      serviceName: servicesTable.name,
      serviceCategory: servicesTable.category,
    })
      .from(userServicesTable)
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(eq(userServicesTable.userId, userId!)),
  ]);

  const total = automations.length;
  const completed = automations.filter(a => a.status === "completed").length;
  const failed = automations.filter(a => a.status === "failed" || a.status === "partial").length;
  const running = automations.filter(a => a.status === "running" || a.status === "queued").length;
  const successRate = total > 0 ? Math.round((completed / total) * 100) : null;

  const lastAuto = automations[0] ?? null;
  const daysSinceLast = lastAuto
    ? Math.floor((Date.now() - new Date(lastAuto.createdAt).getTime()) / 86400000)
    : null;

  return res.json({
    connectedServices: connectedServices.map(s => ({ name: s.serviceName, category: s.serviceCategory })),
    totalServices: connectedServices.length,
    totalAutomations: total,
    completedAutomations: completed,
    failedAutomations: failed,
    runningAutomations: running,
    successRate,
    daysSinceLastAutomation: daysSinceLast,
    lastAutomationStatus: lastAuto?.status ?? null,
  });
});

// ── POST /api/ai/greeting ────────────────────────────────────────────────────
// Generates a short proactive greeting from Sofia based on user context
// Zero AI cost: rule-based generation
router.post("/greeting", requireAuth, async (req, res) => {
  const { firstName, context } = req.body as {
    firstName?: string;
    context: {
      totalServices: number;
      totalAutomations: number;
      failedAutomations: number;
      successRate: number | null;
      daysSinceLastAutomation: number | null;
      lastAutomationStatus: string | null;
      connectedServices: { name: string; category: string }[];
    };
  };

  if (!context) return res.status(400).json({ error: "Contexte requis" });

  const firstName_ = firstName?.trim() || "la";
  const name = firstName_ !== "la" ? firstName_ : null;
  const hour = new Date().getHours();
  const salutation = hour >= 18 || hour < 5 ? "Bonsoir" : "Bonjour";

  const { userId } = getAuth(req);
  const agentName = getAgentNameForUser(userId!);

  // Rule-based greeting generation with personalized agent name
  let greeting: string;
  if (context.totalServices === 0 && context.totalAutomations === 0) {
    greeting = `${salutation}${name ? " " + name : ""} ! ${agentName} est là pour vous aider. Commençons par connecter vos services — c'est le premier pas vers un déménagement sans stress.`;
  } else if (context.failedAutomations > 0) {
    greeting = `${salutation}${name ? " " + name : ""} ! J'ai remarqué que ${context.failedAutomations} préparation${context.failedAutomations > 1 ? "s ont" : " a"} besoin de votre attention. Jetons un œil ensemble.`;
  } else if (context.daysSinceLastAutomation !== null && context.daysSinceLastAutomation > 30) {
    greeting = `${salutation}${name ? " " + name : ""} ! Ça fait un moment que nous ne nous sommes pas vu${name ? "e" : ""}. Prêt${name ? "" : "e"} à mettre à jour une nouvelle adresse ?`;
  } else if (context.successRate !== null && context.successRate >= 90) {
    greeting = `${salutation}${name ? " " + name : ""} ! Tout roule — ${context.successRate}% de réussite sur vos préparations. Continuons sur cette lancée !`;
  } else {
    greeting = `${salutation}${name ? " " + name : ""} ! Prêt${name ? "" : "e"} à centraliser vos changements d'adresse ? Je suis là pour vous guider.`;
  }

  return res.json({ greeting });
});

// ── GET /api/ai/agent ────────────────────────────────────────────────────────
// Returns the user's assigned human agent name
router.get("/agent", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const agentName = getAgentNameForUser(userId!);
  return res.json({ name: agentName });
});

// ── POST /api/ai/insights ────────────────────────────────────────────────────
// Generates 2-3 personalized AI recommendations
// Zero AI cost: rule-based generation
router.post("/insights", requireAuth, async (req, res) => {
  const { context } = req.body as {
    context: {
      totalServices: number;
      totalAutomations: number;
      failedAutomations: number;
      successRate: number | null;
      daysSinceLastAutomation: number | null;
      connectedServices: { name: string; category: string }[];
    };
  };

  if (!context) return res.status(400).json({ error: "Contexte requis" });

  const ALL_SERVICES = ["CPAM", "CAF", "La Poste", "Orange", "EDF", "AXA", "BNP Paribas", "Société Générale", "Amazon", "SFR", "Free", "Netflix", "PayPal", "MAIF"];
  const connectedNames = context.connectedServices.map(c => c.name);
  const notConnected = ALL_SERVICES.filter(s => !connectedNames.includes(s));

  // Rule-based recommendations
  const recommendations: any[] = [];

  // Priority 1: connect popular missing services
  if (notConnected.length > 0) {
    const nextService = notConnected[0];
    let icon = "🏛️";
    let title = `Connecter ${nextService}`;
    let desc = `${nextService} fait partie des services essentiels pour un changement d'adresse. Ajoutez-le maintenant.`;
    if (nextService === "La Poste") { icon = "📬"; desc = "Activez la réexpédition du courrier pour ne rien manquer pendant votre déménagement."; }
    if (nextService === "CPAM") { icon = "🏥"; desc = "2 millions de Français oublient de mettre à jour leur adresse CPAM à chaque déménagement."; }
    if (nextService === "Orange" || nextService === "EDF") { icon = "⚡"; }
    if (nextService === "Amazon" || nextService === "PayPal") { icon = "🛍️"; }
    recommendations.push({
      id: "rec_connect",
      icon,
      title,
      description: desc,
      action: "services",
      actionLabel: "Ajouter",
    });
  }

  // Priority 2: failed automations
  if (context.failedAutomations > 0) {
    recommendations.push({
      id: "rec_failed",
      icon: "⚠️",
      title: "Automations en échec",
      description: `${context.failedAutomations} automation${context.failedAutomations > 1 ? "s" : ""} n${context.failedAutomations > 1 ? "'ont" : "'a"} pas abouti. Consultez les détails pour résoudre le problème.`,
      action: "automations",
      actionLabel: "Voir les détails",
    });
  }

  // Priority 3: no recent automation
  if (context.totalAutomations === 0 && context.totalServices > 0) {
    recommendations.push({
      id: "rec_start",
      icon: "🚀",
      title: "Lancer une automation",
      description: "Vous avez déjà connecté des services. Lancez votre première automation de changement d'adresse.",
      action: "automations",
      actionLabel: "Lancer",
    });
  } else if (context.daysSinceLastAutomation !== null && context.daysSinceLastAutomation > 60 && context.totalServices > 0) {
    recommendations.push({
      id: "rec_reminder",
      icon: "📅",
      title: "Rappel d'automation",
      description: "Votre dernière automation date de ${context.daysSinceLastAutomation} jours. Une nouvelle adresse à mettre à jour ?",
      action: "automations",
      actionLabel: "Nouvelle automation",
    });
  }

  // Priority 4: high success rate tip
  if (context.successRate !== null && context.successRate >= 90) {
    recommendations.push({
      id: "rec_pro",
      icon: "⭐",
      title: "Vous êtes un pro",
      description: `${context.successRate}% de réussite ! Partagez Serenya avec vos proches pour les aider à déménager sereinement.`,
      action: "dashboard",
      actionLabel: "Partager",
    });
  }

  // Ensure minimum 2 recommendations
  if (recommendations.length < 2) {
    recommendations.push({
      id: "rec_docs",
      icon: "📋",
      title: "Documents à préparer",
      description: "Préparez vos justificatifs de domicile et pièces d'identité avant de lancer une automation.",
      action: "dashboard",
      actionLabel: "En savoir plus",
    });
  }

  return res.json(recommendations.slice(0, 3));
});

// ── POST /api/ai/automation-plan ────────────────────────────────────────────────────
// Generates a structured preparation plan for each selected service using the built-in
// knowledge base (zero AI cost — real administrative procedures for French services)
router.post("/automation-plan", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { addressId, serviceIds } = req.body as { addressId?: number; serviceIds?: number[] };

  if (!addressId || !Array.isArray(serviceIds) || serviceIds.length === 0) {
    return res.status(400).json({ error: "Adresse et services requis" });
  }

  // Rate-limit: max 1 plan per minute per user
  const lastSim = SIM_RATE_LIMIT.get(userId!);
  if (lastSim && Date.now() - lastSim < SIM_COOLDOWN) {
    const waitSec = Math.ceil((SIM_COOLDOWN - (Date.now() - lastSim)) / 1000);
    return res.status(429).json({ error: `Veuillez attendre ${waitSec}s avant de relancer une préparation.` });
  }
  SIM_RATE_LIMIT.set(userId!, Date.now());

  // Cache check
  const cacheKey = getCacheKey(userId!, addressId, serviceIds);
  const cached = planCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < PLAN_CACHE_TTL) {
    return res.json(cached.plan);
  }
  cleanCache();

  try {
    const [address] = await db.select().from(addressesTable).where(and(eq(addressesTable.id, addressId), eq(addressesTable.userId, userId!)));
    if (!address) return res.status(404).json({ error: "Adresse introuvable" });

    const services = await db
      .select({ id: servicesTable.id, name: servicesTable.name, category: servicesTable.category })
      .from(userServicesTable)
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(and(eq(userServicesTable.userId, userId!), inArray(servicesTable.id, serviceIds)));

    const plan = buildAutomationPlan(services, address);

    // Cache the plan
    planCache.set(cacheKey, { plan, ts: Date.now() });

    return res.json(plan);
  } catch (err: any) {
    req.log?.error?.({ err }, "automation-plan failed");
    return res.status(500).json({ error: "Impossible de générer le plan. Réessayez." });
  }
});

export default router;
