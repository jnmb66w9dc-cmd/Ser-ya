import { Router } from "express";
import { db, addressesTable } from "@workspace/db";
import { eq, and, sql } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import { logger } from "../lib/logger";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Non autorisé" });
  next();
}

function parseId(raw: string): number | null {
  const id = parseInt(raw, 10);
  return isNaN(id) ? null : id;
}

/* ── Address validation via api-adresse.data.gouv.fr ── */
interface AdresseFeature {
  properties: { score: number; label: string };
}
interface AdresseResponse {
  features?: AdresseFeature[];
}

async function validateFrenchAddress(street: string, postalCode: string, city: string): Promise<{ valid: boolean; suggestion?: string; details?: Record<string, unknown> }> {
  try {
    const query = encodeURIComponent(`${street} ${postalCode} ${city}`);
    const response = await fetch(
      `https://api-adresse.data.gouv.fr/search/?q=${query}&limit=1`,
      { headers: { "Accept": "application/json" } }
    );
    if (!response.ok) return { valid: true }; // fallback: don't block on API failure
    const data = await response.json() as AdresseResponse;
    if (!data.features || data.features.length === 0) {
      return { valid: false, suggestion: "Aucune adresse correspondante trouvée. Vérifiez rue, code postal et ville." };
    }
    const feature = data.features[0];
    const score = feature.properties?.score ?? 0;
    if (score < 0.5) {
      return {
        valid: false,
        suggestion: `Adresse peu précise (confiance ${Math.round(score * 100)}%). Vérifiez : ${feature.properties?.label ?? ""}`,
        details: feature.properties as Record<string, unknown>,
      };
    }
    return { valid: true, details: feature.properties as Record<string, unknown> };
  } catch (err) {
    logger.warn({ err }, "Address validation API failed, allowing address");
    return { valid: true }; // graceful degradation
  }
}

// GET /api/addresses
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const addresses = await db
      .select()
      .from(addressesTable)
      .where(eq(addressesTable.userId, userId!))
      .orderBy(addressesTable.createdAt);
    return res.json(addresses);
  } catch (err) {
    logger.error({ err, userId }, "Failed to load addresses");
    return res.status(500).json({ error: "Impossible de charger vos adresses. Réessayez dans quelques instants." });
  }
});

// POST /api/addresses
router.post("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { label, street, complement, city, postalCode, country, isDefault } = req.body;

  // Basic validation
  if (!street || !street.trim()) {
    return res.status(400).json({ error: "La rue est requise", field: "street" });
  }
  if (!postalCode || !postalCode.trim()) {
    return res.status(400).json({ error: "Le code postal est requis", field: "postalCode" });
  }
  if (!city || !city.trim()) {
    return res.status(400).json({ error: "La ville est requise", field: "city" });
  }
  if (!label || !label.trim()) {
    return res.status(400).json({ error: "Le libellé est requis", field: "label" });
  }

  // French postal code format
  const cp = postalCode.trim();
  if ((country ?? "France") === "France" && !/^\d{5}$/.test(cp)) {
    return res.status(400).json({ error: "Le code postal doit contenir 5 chiffres", field: "postalCode" });
  }

  // Address validation (French gov API)
  const countryNorm = (country ?? "France").trim();
  if (countryNorm === "France" || countryNorm === "France métropolitaine") {
    const validation = await validateFrenchAddress(street.trim(), cp, city.trim());
    if (!validation.valid) {
      return res.status(400).json({
        error: validation.suggestion,
        field: "address",
        code: "ADDRESS_INVALID",
        suggestion: validation.details?.label ?? undefined,
      });
    }
  }

  try {
    if (isDefault) {
      await db
        .update(addressesTable)
        .set({ isDefault: false })
        .where(eq(addressesTable.userId, userId!));
    }

    const [address] = await db
      .insert(addressesTable)
      .values({
        userId: userId!,
        label: label.trim(),
        street: street.trim(),
        complement: complement?.trim() ?? null,
        city: city.trim(),
        postalCode: cp,
        country: countryNorm,
        isDefault: isDefault ?? false,
      })
      .returning();

    return res.status(201).json(address);
  } catch (err) {
    logger.error({ err, userId }, "Failed to create address");
    return res.status(500).json({ error: "Impossible de créer l'adresse. Vérifiez vos informations et réessayez." });
  }
});

// GET /api/addresses/:id
router.get("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseId(req.params.id);
  if (id === null) return res.status(400).json({ error: "ID invalide" });

  try {
    const [address] = await db
      .select()
      .from(addressesTable)
      .where(and(eq(addressesTable.id, id), eq(addressesTable.userId, userId!)));
    if (!address) return res.status(404).json({ error: "Introuvable" });
    return res.json(address);
  } catch (_err) {
    return res.status(500).json({ error: "Erreur serveur" });
  }
});

// PATCH /api/addresses/:id
router.patch("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseId(req.params.id);
  if (id === null) return res.status(400).json({ error: "ID invalide" });

  const { label, street, complement, city, postalCode, country, isDefault } = req.body;

  // Validation
  if (street !== undefined && !street.trim()) {
    return res.status(400).json({ error: "La rue ne peut pas être vide", field: "street" });
  }
  if (postalCode !== undefined) {
    const cp = postalCode.trim();
    const countryNorm = (country ?? "France").trim();
    if ((countryNorm === "France" || countryNorm === "France métropolitaine") && !/^\d{5}$/.test(cp)) {
      return res.status(400).json({ error: "Le code postal doit contenir 5 chiffres", field: "postalCode" });
    }
  }
  if (city !== undefined && !city.trim()) {
    return res.status(400).json({ error: "La ville ne peut pas être vide", field: "city" });
  }
  if (label !== undefined && !label.trim()) {
    return res.status(400).json({ error: "Le libellé ne peut pas être vide", field: "label" });
  }

  try {
    if (isDefault) {
      await db
        .update(addressesTable)
        .set({ isDefault: false })
        .where(eq(addressesTable.userId, userId!));
    }

    const [address] = await db
      .update(addressesTable)
      .set({
        label: label?.trim() ?? undefined,
        street: street?.trim() ?? undefined,
        complement: complement?.trim() ?? undefined,
        city: city?.trim() ?? undefined,
        postalCode: postalCode?.trim() ?? undefined,
        country: country?.trim() ?? undefined,
        isDefault,
        updatedAt: new Date(),
      })
      .where(and(eq(addressesTable.id, id), eq(addressesTable.userId, userId!)))
      .returning();

    if (!address) return res.status(404).json({ error: "Adresse introuvable" });
    return res.json(address);
  } catch (err) {
    logger.error({ err, userId, addressId: id }, "Failed to update address");
    return res.status(500).json({ error: "Impossible de mettre à jour l'adresse. Réessayez dans quelques instants." });
  }
});

// DELETE /api/addresses/:id
router.delete("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseId(req.params.id);
  if (id === null) return res.status(400).json({ error: "ID invalide" });

  try {
    await db
      .delete(addressesTable)
      .where(and(eq(addressesTable.id, id), eq(addressesTable.userId, userId!)));
    return res.status(204).send();
  } catch (err) {
    logger.error({ err, userId, addressId: id }, "Failed to delete address");
    return res.status(500).json({ error: "Impossible de supprimer l'adresse. Elle est peut-être utilisée par une automation en cours." });
  }
});

// POST /api/addresses/:id/set-default
router.post("/:id/set-default", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseId(req.params.id);
  if (id === null) return res.status(400).json({ error: "ID invalide" });

  try {
    await db
      .update(addressesTable)
      .set({ isDefault: false })
      .where(eq(addressesTable.userId, userId!));

    const [address] = await db
      .update(addressesTable)
      .set({ isDefault: true, updatedAt: new Date() })
      .where(and(eq(addressesTable.id, id), eq(addressesTable.userId, userId!)))
      .returning();

    if (!address) return res.status(404).json({ error: "Adresse introuvable" });
    return res.json(address);
  } catch (err) {
    logger.error({ err, userId, addressId: id }, "Failed to set default address");
    return res.status(500).json({ error: "Impossible de définir l'adresse par défaut. Réessayez dans quelques instants." });
  }
});

export default router;
