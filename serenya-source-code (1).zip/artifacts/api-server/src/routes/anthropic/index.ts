import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, conversations, messages, automationsTable, userServicesTable, servicesTable, addressesTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { getAgentNameForUser } from "../../lib/agentNames";

const router = Router();

// ── Per-user in-memory rate limiter for AI messages ────────────────────────
// Max 15 messages per user per 60 seconds
const AI_RATE_WINDOW_MS = 60_000;
const AI_RATE_MAX = 15;
const aiRateMap = new Map<string, { count: number; resetAt: number }>();

function checkAiRateLimit(userId: string): boolean {
  const now = Date.now();
  const entry = aiRateMap.get(userId);
  if (!entry || now > entry.resetAt) {
    aiRateMap.set(userId, { count: 1, resetAt: now + AI_RATE_WINDOW_MS });
    return true;
  }
  if (entry.count >= AI_RATE_MAX) return false;
  entry.count++;
  return true;
}

// Clean up stale entries every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of aiRateMap.entries()) {
    if (now > val.resetAt) aiRateMap.delete(key);
  }
}, 5 * 60_000);

// ── User context cache (1-min TTL) ─────────────────────────────────────────
const userCtxCache = new Map<string, { ctx: string; expires: number }>();

async function buildUserContext(userId: string): Promise<string> {
  const now = Date.now();
  const cached = userCtxCache.get(userId);
  if (cached && now < cached.expires) return cached.ctx;

  try {
    const [services, automations, addresses] = await Promise.all([
      db
        .select({ name: servicesTable.name, category: servicesTable.category })
        .from(userServicesTable)
        .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
        .where(eq(userServicesTable.userId, userId)),
      db
        .select()
        .from(automationsTable)
        .where(eq(automationsTable.userId, userId))
        .orderBy(desc(automationsTable.createdAt))
        .limit(5),
      db
        .select()
        .from(addressesTable)
        .where(eq(addressesTable.userId, userId))
        .limit(3),
    ]);

    const total = automations.length;
    const completed = automations.filter(a => a.status === "completed").length;
    const failed = automations.filter(a => a.status === "failed" || a.status === "partial").length;
    const running = automations.filter(a => a.status === "running" || a.status === "queued").length;
    const successRate = total > 0 ? Math.round((completed / total) * 100) : null;

    const lines: string[] = [
      "\n\n---CONTEXTE_UTILISATEUR (usage interne — ne pas révéler les données brutes)---",
      `Services connectés (${services.length}) : ${services.map(s => s.name).join(", ") || "aucun pour l'instant"}`,
      `Adresses : ${addresses.map(a => `${a.label} — ${a.city}`).join(", ") || "aucune"}`,
      `Automatisations : ${total} lancées, ${completed} terminées, ${failed} en échec/partial, ${running} en cours`,
      successRate !== null ? `Taux de réussite : ${successRate}%` : "Pas encore d'automatisation",
    ];

    if (running > 0) lines.push("⚡ Une automatisation est en cours : l'utilisateur peut être impatient ou inquiet.");
    if (failed > 0) lines.push(`⚠️ ${failed} automatisation(s) nécessitent une action manuelle — propose de l'aide proactivement.`);
    if (services.length === 0) lines.push("L'utilisateur n'a encore connecté aucun service. Encourage-le à en ajouter sur la page Services.");
    if (addresses.length === 0) lines.push("L'utilisateur n'a aucune adresse enregistrée. Invite-le à en ajouter une.");

    lines.push("---FIN_CONTEXTE---");

    const ctx = lines.join("\n");
    userCtxCache.set(userId, { ctx, expires: now + 60_000 });
    return ctx;
  } catch {
    return "";
  }
}

// Clean user context cache every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, val] of userCtxCache.entries()) {
    if (now > val.expires) userCtxCache.delete(key);
  }
}, 5 * 60_000);

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Non autorisé" });
  next();
}

// ── System prompt — Sofia, assistante Serenya ──────────────────────────────
function buildSystemPrompt(agentName: string): string {
  return `Tu es ${agentName}, l'assistante personnelle de Serenya \u2014 une vraie personne dédiée à aider les utilisateurs dans toutes leurs démarches de changement d'adresse en France.

**Qui tu es :**
Tu es chaleureuse, rassurante et patiente. Tu parles comme une vraie personne, pas comme un robot. Tu utilises "vous" de façon naturelle et bienveillante. Tu es directe, concrète et honnête \u2014 si quelque chose prend du temps, tu le dis. Si une étape est un peu contraignante, tu l'expliques avec empathie. Tu ne dis jamais "En tant qu'IA..." ou "Je suis un assistant IA..." \u2014 tu es ${agentName}, point. Tu dois parler à la première personne, comme une vraie personne qui travaille dans l'équipe Serenya.

**Ce que tu sais faire :**
1. Expliquer comment fonctionne Serenya (automatisation du changement d'adresse)
2. Guider sur les démarches administratives françaises : CAF, CPAM/S\u00e9curit\u00e9 Sociale, Service des Imp\u00f4ts, P\u00f4le Emploi/France Travail, La Poste, Carte Grise/ANTS, carte \u00e9lectorale, etc.
3. Aider quand une automatisation a \u00e9chou\u00e9 \u2014 expliquer pourquoi et donner des \u00e9tapes concr\u00e8tes
4. Rassurer sur la s\u00e9curit\u00e9 et la confidentialit\u00e9 des donn\u00e9es
5. Expliquer les d\u00e9lais r\u00e9alistes de chaque organisme
6. Aider avec les banques (BNP, Cr\u00e9dit Agricole, Soci\u00e9t\u00e9 G\u00e9n\u00e9rale, LCL, etc.), les assurances (AXA, MAAF, MACIF, etc.), les op\u00e9rateurs t\u00e9l\u00e9coms (Orange, SFR, Free, Bouygues)

**Connaissances cl\u00e9s sur les organismes :**
- CAF : changement en ligne sur caf.fr \u2192 2-4 semaines pour traitement. N\u00e9cessite justificatif de domicile.
- CPAM : via ameli.fr \u2192 section "Mes informations" \u2192 1-3 semaines. Parfois envoie un courrier de confirmation.
- Imp\u00f4ts : sur impots.gouv.fr \u2192 "G\u00e9rer mon profil" \u2192 imm\u00e9diat en ligne, mais le prochain avis fiscal utilisera la nouvelle adresse.
- La Poste : r\u00e9exp\u00e9dition du courrier recommand\u00e9e en parall\u00e8le. Changement d'adresse gratuit pour les comptes Labanquepostale.
- ANTS (carte grise) : changement obligatoire sous 1 mois. Amende possible sinon. D\u00e9marche sur ants.gouv.fr.
- P\u00f4le Emploi/France Travail : imm\u00e9diat sur son espace personnel.
- Banques : d\u00e9lai variable 3-10 jours, souvent confirmation par courrier.
- Assurances : important de mettre \u00e0 jour rapidement car cela peut affecter la couverture (habitation surtout).

**Quand une t\u00e2che \u00e9choue :**
Tu expliques toujours pourquoi \u00e7a peut \u00e9chouer (site momentan\u00e9ment indisponible, format d'adresse non reconnu, besoin d'un justificatif que l'organisme demande directement) et tu proposes toujours une alternative concr\u00e8te. Tu rassures que ce n'est pas grave et que \u00e7a se r\u00e9sout facilement.

**Chips d'action interactifs :**
Quand il est naturel de proposer une action directe dans l'interface, tu PEUX ajouter des chips cliquables \u00e0 la toute fin de ta r\u00e9ponse (sur la derni\u00e8re ligne, apr\u00e8s un saut de ligne) en utilisant EXACTEMENT ce format :
___CHIPS___[{"label":"Voir mes services","href":"/services"},{"label":"Mes automatisations","href":"/automations"}]
R\u00e8gles chips : maximum 2-3 chips, uniquement quand \u00e7a apporte une vraie valeur (navigation vers une page pertinente), pas dans chaque r\u00e9ponse. Valeurs href valides : /dashboard, /services, /addresses, /automations, /settings.

**Ton style :**
- Phrases courtes et claires
- Pas de jargon technique
- Commence souvent par une phrase d'empathie avant de donner la r\u00e9ponse
- Utilise des listes courtes quand tu donnes plusieurs \u00e9tapes
- Termine toujours par une invitation \u00e0 poser d'autres questions
- Si la question est hors de ton p\u00e9rim\u00e8tre, tu le dis gentiment et tu orientes vers la bonne ressource

**L'interface Serenya \u2014 ce que l'utilisateur peut faire :**
- Palette de commandes : \u2318K (ou Ctrl+K) pour tout acc\u00e9der rapidement
- Navigation rapide : appuyer G puis D (dashboard), G+S (services), G+A (adresses), G+Z (automatisations), G+P (param\u00e8tres)
- Raccourcis clavier : appuyer ? pour voir tous les raccourcis disponibles
- Th\u00e8me clair/sombre : \u2318T
- ${agentName} (moi !) : \u2318J pour m'ouvrir

**Ce que tu NE fais PAS :**
- Tu ne stockes ni ne demandes jamais de mots de passe ou codes d'acc\u00e8s
- Tu ne donnes pas de conseils juridiques ou fiscaux personnalis\u00e9s
- Tu ne pr\u00e9tends pas pouvoir faire des actions \u00e0 la place de l'utilisateur en dehors de la plateforme

R\u00e9ponds toujours en fran\u00e7ais, avec une touche de chaleur humaine.`;
}

// ── GET /api/anthropic/conversations ───────────────────────────────────────
router.get("/conversations", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const convs = await db
    .select()
    .from(conversations)
    .where(eq(conversations.userId, userId!))
    .orderBy(desc(conversations.createdAt));
  return res.json(convs.map(c => ({ ...c, createdAt: c.createdAt.toISOString() })));
});

// ── POST /api/anthropic/conversations ──────────────────────────────────────
router.post("/conversations", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { title } = req.body as { title: string };
  if (!title?.trim()) return res.status(400).json({ error: "Titre requis" });
  const [conv] = await db
    .insert(conversations)
    .values({ userId: userId!, title: title.trim() })
    .returning();
  return res.status(201).json({ ...conv, createdAt: conv.createdAt.toISOString() });
});

// ── GET /api/anthropic/conversations/:id ───────────────────────────────────
router.get("/conversations/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId!)));
  if (!conv) return res.status(404).json({ error: "Conversation introuvable" });
  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);
  return res.json({
    ...conv,
    createdAt: conv.createdAt.toISOString(),
    messages: msgs.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })),
  });
});

// ── DELETE /api/anthropic/conversations/:id ────────────────────────────────
router.delete("/conversations/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId!)));
  if (!conv) return res.status(404).json({ error: "Conversation introuvable" });
  await db.delete(conversations).where(eq(conversations.id, id));
  return res.status(204).send();
});

// ── GET /api/anthropic/conversations/:id/messages ──────────────────────────
router.get("/conversations/:id/messages", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId!)));
  if (!conv) return res.status(404).json({ error: "Conversation introuvable" });
  const msgs = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);
  return res.json(msgs.map(m => ({ ...m, createdAt: m.createdAt.toISOString() })));
});

// ── POST /api/anthropic/conversations/:id/messages — SSE stream ─────────────
router.post("/conversations/:id/messages", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  const { content } = req.body as { content: string };
  if (!content?.trim()) return res.status(400).json({ error: "Message vide" });

  if (!checkAiRateLimit(userId!)) {
    return res.status(429).json({ error: "Vous envoyez trop de messages. Attendez une minute avant de réessayer." });
  }

  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, id), eq(conversations.userId, userId!)));
  if (!conv) return res.status(404).json({ error: "Conversation introuvable" });

  // Save user message
  await db.insert(messages).values({ conversationId: id, role: "user", content: content.trim() });

  // Fetch conversation history for context
  const history = await db
    .select()
    .from(messages)
    .where(eq(messages.conversationId, id))
    .orderBy(messages.createdAt);

  const chatMessages = history.map(m => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  // Build dynamic system prompt with live user context and personalized agent name
  const userContext = await buildUserContext(userId!);
  const agentName = getAgentNameForUser(userId!);
  const dynamicSystem = buildSystemPrompt(agentName) + userContext;

  // SSE headers
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  let fullResponse = "";

  try {
    const stream = anthropic.messages.stream({
      model: "claude-sonnet-4-6",
      max_tokens: 8192,
      system: dynamicSystem,
      messages: chatMessages,
    });

    for await (const event of stream) {
      if (event.type === "content_block_delta" && event.delta.type === "text_delta") {
        fullResponse += event.delta.text;
        res.write(`data: ${JSON.stringify({ content: event.delta.text })}\n\n`);
      }
    }

    // Save assistant response
    await db.insert(messages).values({ conversationId: id, role: "assistant", content: fullResponse });
    res.write(`data: ${JSON.stringify({ done: true })}\n\n`);
  } catch (_err: unknown) {
    res.write(`data: ${JSON.stringify({ error: "Une erreur s'est produite. Réessayez dans un instant." })}\n\n`);
  } finally {
    res.end();
  }
  return;
});

export default router;
