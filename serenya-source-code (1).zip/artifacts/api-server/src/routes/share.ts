import { Router } from "express";
import { db, shareLinksTable, automationsTable, automationTasksTable, userServicesTable, servicesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import { randomBytes } from "crypto";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

function generateToken(): string {
  return randomBytes(16).toString("hex");
}

function buildShareUrl(req: any, token: string): string {
  const host = req.get("host") ?? "";
  const proto = (req.get("x-forwarded-proto") as string) ?? "https";
  const basePath = (process.env["BASE_PATH"] ?? "").replace(/\/$/, "");
  return `${proto}://${host}${basePath}/partage/${token}`;
}

// ── PUBLIC — no auth ───────────────────────────────────────────────
// GET /api/share/public/:token
router.get("/public/:token", async (req, res) => {
  const { token } = req.params;

  const [link] = await db
    .select()
    .from(shareLinksTable)
    .where(and(eq(shareLinksTable.token, token), eq(shareLinksTable.isActive, true)));

  if (!link) return res.status(404).json({ error: "Lien introuvable ou désactivé." });

  const [automation] = await db
    .select()
    .from(automationsTable)
    .where(eq(automationsTable.id, link.automationId));

  if (!automation) return res.status(404).json({ error: "Automatisation introuvable." });

  const tasks = await db
    .select({
      serviceName: servicesTable.name,
      logoUrl: servicesTable.logoUrl,
      status: automationTasksTable.status,
      completedAt: automationTasksTable.completedAt,
    })
    .from(automationTasksTable)
    .innerJoin(userServicesTable, eq(automationTasksTable.userServiceId, userServicesTable.id))
    .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
    .where(eq(automationTasksTable.automationId, automation.id));

  return res.json({
    token,
    firstName: link.firstName ?? null,
    status: automation.status,
    progressPercent: automation.progressPercent,
    totalServices: automation.totalServices,
    completedServices: automation.completedServices,
    failedServices: automation.failedServices,
    tasks: tasks.map((t) => ({
      serviceName: t.serviceName,
      logoUrl: t.logoUrl ?? null,
      status: t.status,
      completedAt: t.completedAt ? t.completedAt.toISOString() : null,
    })),
    createdAt: automation.createdAt.toISOString(),
    completedAt: automation.completedAt ? automation.completedAt.toISOString() : null,
  });
});

// ── AUTH REQUIRED ──────────────────────────────────────────────────

// GET /api/share — list user share links
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const links = await db
    .select()
    .from(shareLinksTable)
    .where(eq(shareLinksTable.userId, userId!));

  return res.json(
    links.map((l) => ({
      ...l,
      createdAt: l.createdAt.toISOString(),
      shareUrl: buildShareUrl(req, l.token),
    }))
  );
});

// POST /api/share — create share link
router.post("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { automationId, firstName } = req.body as { automationId: number; firstName?: string };

  const [automation] = await db
    .select()
    .from(automationsTable)
    .where(and(eq(automationsTable.id, automationId), eq(automationsTable.userId, userId!)));

  if (!automation) return res.status(404).json({ error: "Automatisation introuvable." });

  const [existing] = await db
    .select()
    .from(shareLinksTable)
    .where(and(eq(shareLinksTable.automationId, automationId), eq(shareLinksTable.isActive, true)));

  if (existing) {
    return res.status(201).json({
      ...existing,
      createdAt: existing.createdAt.toISOString(),
      shareUrl: buildShareUrl(req, existing.token),
    });
  }

  const token = generateToken();
  const [link] = await db
    .insert(shareLinksTable)
    .values({ userId: userId!, automationId, token, firstName: firstName ?? null, isActive: true })
    .returning();

  return res.status(201).json({
    ...link,
    createdAt: link.createdAt.toISOString(),
    shareUrl: buildShareUrl(req, link.token),
  });
});

// DELETE /api/share/:id — deactivate
router.delete("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  await db
    .update(shareLinksTable)
    .set({ isActive: false })
    .where(and(eq(shareLinksTable.id, id), eq(shareLinksTable.userId, userId!)));
  return res.status(204).send();
});

// POST /api/share/:id/regenerate — new token
router.post("/:id/regenerate", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  const token = generateToken();
  const [link] = await db
    .update(shareLinksTable)
    .set({ token, isActive: true })
    .where(and(eq(shareLinksTable.id, id), eq(shareLinksTable.userId, userId!)))
    .returning();
  if (!link) return res.status(404).json({ error: "Lien introuvable." });
  return res.json({
    ...link,
    createdAt: link.createdAt.toISOString(),
    shareUrl: buildShareUrl(req, link.token),
  });
});

export default router;
