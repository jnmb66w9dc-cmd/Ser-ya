import { Router } from "express";
import { db, userServicesTable, servicesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getAuth } from "@clerk/express";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// GET /api/user-services
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const rows = await db
    .select({
      id: userServicesTable.id,
      userId: userServicesTable.userId,
      serviceId: userServicesTable.serviceId,
      serviceName: servicesTable.name,
      serviceCategory: servicesTable.category,
      logoUrl: servicesTable.logoUrl,
      status: userServicesTable.status,
      connectedAt: userServicesTable.connectedAt,
      lastUpdatedAt: userServicesTable.lastUpdatedAt,
    })
    .from(userServicesTable)
    .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
    .where(eq(userServicesTable.userId, userId!));
  return res.json(rows);
});

// POST /api/user-services
router.post("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { serviceId } = req.body;
  const [userService] = await db
    .insert(userServicesTable)
    .values({ userId: userId!, serviceId, status: "connected" })
    .returning();

  const [service] = await db.select().from(servicesTable).where(eq(servicesTable.id, serviceId));
  return res.status(201).json({
    ...userService,
    serviceName: service?.name ?? "",
    serviceCategory: service?.category ?? "",
    logoUrl: service?.logoUrl ?? null,
  });
});

// DELETE /api/user-services/:id
router.delete("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id);
  await db
    .delete(userServicesTable)
    .where(and(eq(userServicesTable.id, id), eq(userServicesTable.userId, userId!)));
  return res.status(204).send();
});

export default router;
