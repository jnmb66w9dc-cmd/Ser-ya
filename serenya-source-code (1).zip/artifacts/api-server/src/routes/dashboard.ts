import { Router } from "express";
import { db, addressesTable, userServicesTable, automationsTable, notificationsTable } from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";
import { getAuth } from "@clerk/express";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Non autorisé" });
  next();
}

// GET /api/dashboard/summary
router.get("/summary", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const [addresses, userServices, automations, notifications] = await Promise.all([
      db.select().from(addressesTable).where(eq(addressesTable.userId, userId!)),
      db.select().from(userServicesTable).where(eq(userServicesTable.userId, userId!)),
      db.select().from(automationsTable).where(eq(automationsTable.userId, userId!)),
      db.select().from(notificationsTable).where(
        and(eq(notificationsTable.userId, userId!), eq(notificationsTable.isRead, false))
      ),
    ]);

    const totalAutomations = automations.length;
    const completedAutomations = automations.filter((a) => a.status === "completed");
    const successRate = totalAutomations > 0
      ? Math.round((completedAutomations.length / totalAutomations) * 100)
      : 0;

    const activeAutomations = automations.filter((a) =>
      ["queued", "running"].includes(a.status)
    ).length;

    const pendingTasks = automations.reduce(
      (acc, a) => acc + Math.max(0, a.totalServices - a.completedServices - a.failedServices),
      0
    );

    return res.json({
      totalAddresses: addresses.length,
      connectedServices: userServices.length,
      automationsRun: totalAutomations,
      successRate,
      pendingTasks,
      activeAutomations,
      unreadNotifications: notifications.length,
    });
  } catch (_err) {
    return res.status(500).json({ error: "Erreur lors du chargement du tableau de bord" });
  }
});

// GET /api/dashboard/activity
router.get("/activity", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const automations = await db
      .select()
      .from(automationsTable)
      .where(eq(automationsTable.userId, userId!))
      .orderBy(desc(automationsTable.createdAt))
      .limit(10);

    const activity = automations.map((a) => ({
      id: a.id,
      type:
        a.status === "completed" ? "automation_completed" :
        a.status === "failed"    ? "automation_failed" :
        a.status === "partial"   ? "automation_completed" :
        "task_updated",
      message:
        a.status === "completed"
          ? `Adresse mise à jour sur ${a.completedServices} service(s)`
          : a.status === "failed"
          ? `Échec de la mise à jour — ${a.failedServices} service(s) en erreur`
          : a.status === "partial"
          ? `Mise à jour partielle — ${a.completedServices}/${a.totalServices} service(s)`
          : `Automatisation en cours…`,
      serviceName: null,
      createdAt: (a.completedAt ?? a.createdAt).toISOString(),
    }));

    return res.json(activity);
  } catch (_err) {
    return res.status(500).json({ error: "Erreur lors du chargement de l'activité" });
  }
});

export default router;
