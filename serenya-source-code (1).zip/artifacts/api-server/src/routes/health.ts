import { Router, type IRouter } from "express";
import { HealthCheckResponse } from "@workspace/api-zod";
import { db } from "@workspace/db";
import { sql } from "drizzle-orm";

const router: IRouter = Router();
const startedAt = new Date();

router.get("/healthz", async (_req, res) => {
  let dbStatus: "ok" | "error" = "ok";
  try {
    await db.execute(sql`SELECT 1`);
  } catch {
    dbStatus = "error";
  }

  const uptimeSeconds = Math.floor((Date.now() - startedAt.getTime()) / 1000);

  const data = HealthCheckResponse.parse({ status: dbStatus === "ok" ? "ok" : "error" });
  return res.status(dbStatus === "ok" ? 200 : 503).json({
    ...data,
    db: dbStatus,
    uptime: uptimeSeconds,
    version: process.env.npm_package_version ?? "1.0.0",
    env: process.env.NODE_ENV ?? "development",
    timestamp: new Date().toISOString(),
  });
});

export default router;
