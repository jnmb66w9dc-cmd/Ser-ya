import { Router } from "express";
import { getAuth } from "@clerk/express";
import { getUncachableStripeClient } from "../stripeClient";
import { stripeStorage } from "../stripeStorage";
import { db, pool } from "@workspace/db";
import { sql } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// Ensure user row exists with Stripe customer
async function ensureStripeCustomer(userId: string, email: string): Promise<string> {
  const client = await pool.connect();
  try {
    const existing = await client.query(
      "SELECT stripe_customer_id FROM public.serenya_users WHERE id = $1",
      [userId]
    );

    if (existing.rows.length > 0 && existing.rows[0].stripe_customer_id) {
      return existing.rows[0].stripe_customer_id;
    }

    const stripe = await getUncachableStripeClient();
    const customer = await stripe.customers.create({
      email,
      metadata: { userId },
    });

    await client.query(
      `INSERT INTO public.serenya_users (id, email, stripe_customer_id)
       VALUES ($1, $2, $3)
       ON CONFLICT (id) DO UPDATE SET stripe_customer_id = $3`,
      [userId, email, customer.id]
    );

    // Notify admin of new user signup (fire-and-forget)
    const { notifyAdminNewUser } = await import("../lib/email");
    notifyAdminNewUser(email, undefined).catch(() => {});

    return customer.id;
  } finally {
    client.release();
  }
}

// GET /api/stripe/plans — list available plans
router.get("/plans", async (_req, res) => {
  try {
    const products = await stripeStorage.getActiveProducts();
    const plans = await Promise.all(
      products.map(async (p) => {
        const prices = await stripeStorage.getPricesForProduct(p.id);
        return { ...p, prices };
      })
    );
    return res.json(plans);
  } catch (err: any) {
    return res.status(503).json({ error: "Service de paiement indisponible." });
  }
});

// GET /api/stripe/subscription — get current user subscription
router.get("/subscription", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const client = await pool.connect();
    let stripeCustomerId: string | null = null;
    try {
      const row = await client.query(
        "SELECT stripe_customer_id FROM public.serenya_users WHERE id = $1",
        [userId]
      );
      stripeCustomerId = row.rows[0]?.stripe_customer_id ?? null;
    } finally {
      client.release();
    }

    if (!stripeCustomerId) return res.json({ plan: "free", subscription: null });

    const subscription = await stripeStorage.getCustomerSubscription(stripeCustomerId);
    if (!subscription) return res.json({ plan: "free", subscription: null });

    return res.json({ plan: "pro", subscription });
  } catch {
    return res.json({ plan: "free", subscription: null });
  }
});

// POST /api/stripe/checkout — create Stripe Checkout session
router.post("/checkout", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { priceId } = req.body as { priceId: string };

  if (!priceId) return res.status(400).json({ error: "priceId requis." });

  try {
    const stripe = await getUncachableStripeClient();
    const auth = getAuth(req);
    const email = (auth as any).sessionClaims?.email ?? "";

    const customerId = await ensureStripeCustomer(userId!, email as string);

    const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;

    const session = await stripe.checkout.sessions.create({
      customer: customerId,
      payment_method_types: ["card"],
      mode: "subscription",
      line_items: [{ price: priceId, quantity: 1 }],
      success_url: `${baseUrl}/settings?checkout=success`,
      cancel_url: `${baseUrl}/settings?checkout=cancelled`,
      metadata: { userId: userId! },
    });

    return res.json({ url: session.url });
  } catch (err: any) {
    return res.status(503).json({ error: "Impossible de créer la session de paiement." });
  }
});

// POST /api/stripe/portal — open billing portal
router.post("/portal", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const client = await pool.connect();
    let stripeCustomerId: string | null = null;
    try {
      const row = await client.query(
        "SELECT stripe_customer_id FROM public.serenya_users WHERE id = $1",
        [userId]
      );
      stripeCustomerId = row.rows[0]?.stripe_customer_id ?? null;
    } finally {
      client.release();
    }

    if (!stripeCustomerId) return res.status(400).json({ error: "Aucun abonnement actif." });

    const stripe = await getUncachableStripeClient();
    const baseUrl = `https://${process.env.REPLIT_DOMAINS?.split(",")[0]}`;
    const session = await stripe.billingPortal.sessions.create({
      customer: stripeCustomerId,
      return_url: `${baseUrl}/settings`,
    });

    return res.json({ url: session.url });
  } catch {
    return res.status(503).json({ error: "Portail de facturation indisponible." });
  }
});

export default router;
