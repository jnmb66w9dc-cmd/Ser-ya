import { Router } from "express";
import { db, notificationsTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { getAuth } from "@clerk/express";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// GET /api/notifications
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const notifications = await db
    .select()
    .from(notificationsTable)
    .where(eq(notificationsTable.userId, userId!))
    .orderBy(notificationsTable.createdAt);
  return res.json(notifications.reverse());
});

// POST /api/notifications/:id/read
router.post("/:id/read", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id);
  const [notification] = await db
    .update(notificationsTable)
    .set({ isRead: true })
    .where(and(eq(notificationsTable.id, id), eq(notificationsTable.userId, userId!)))
    .returning();
  if (!notification) return res.status(404).json({ error: "Not found" });
  return res.json(notification);
});

// POST /api/notifications/read-all
router.post("/read-all", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const result = await db
    .update(notificationsTable)
    .set({ isRead: true })
    .where(eq(notificationsTable.userId, userId!))
    .returning();
  return res.json({ updated: result.length });
});

export default router;
