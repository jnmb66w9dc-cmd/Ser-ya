import { Router } from "express";
import { db, servicesTable } from "@workspace/db";

const router = Router();

// GET /api/services
router.get("/", async (_req, res) => {
  const services = await db.select().from(servicesTable).orderBy(servicesTable.name);
  return res.json(services);
});

export default router;
