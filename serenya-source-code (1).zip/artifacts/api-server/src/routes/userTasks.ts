import { Router } from "express";
import { getAuth } from "@clerk/express";
import { db, userTasksTable } from "@workspace/db";
import { eq, and, desc, inArray } from "drizzle-orm";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Non autorisé" });
  next();
}

// GET /api/user-tasks — list user's tasks
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const rows = await db
      .select()
      .from(userTasksTable)
      .where(eq(userTasksTable.userId, userId!))
      .orderBy(desc(userTasksTable.createdAt));
    return res.json(rows);
  } catch {
    return res.status(500).json({ error: "Impossible de charger les tâches" });
  }
});

// POST /api/user-tasks — create a task
router.post("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { title, description, category, priority, orgName, automationId } = req.body;
  if (!title?.trim()) return res.status(400).json({ error: "Titre requis" });

  try {
    const [task] = await db.insert(userTasksTable).values({
      userId: userId!,
      title: title.trim(),
      description: description?.trim() || null,
      category: category || "document",
      priority: priority || "medium",
      orgName: orgName?.trim() || null,
      automationId: automationId ?? null,
    }).returning();
    return res.status(201).json(task);
  } catch {
    return res.status(500).json({ error: "Impossible de créer la tâche" });
  }
});

// PATCH /api/user-tasks/:id/status — update status
router.patch("/:id/status", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  const { status } = req.body as { status?: string };
  if (!status || !["pending", "in_progress", "completed", "skipped"].includes(status)) {
    return res.status(400).json({ error: "Statut invalide" });
  }

  try {
    const [task] = await db
      .select()
      .from(userTasksTable)
      .where(and(eq(userTasksTable.id, id), eq(userTasksTable.userId, userId!)))
      .limit(1);
    if (!task) return res.status(404).json({ error: "Tâche introuvable" });

    const updates: any = { status };
    if (status === "completed") updates.completedAt = new Date();
    else updates.completedAt = null;

    const [updated] = await db.update(userTasksTable).set(updates).where(eq(userTasksTable.id, id)).returning();
    return res.json(updated);
  } catch {
    return res.status(500).json({ error: "Impossible de mettre à jour" });
  }
});

// DELETE /api/user-tasks/:id
router.delete("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  try {
    const [task] = await db
      .select()
      .from(userTasksTable)
      .where(and(eq(userTasksTable.id, id), eq(userTasksTable.userId, userId!)))
      .limit(1);
    if (!task) return res.status(404).json({ error: "Tâche introuvable" });

    await db.delete(userTasksTable).where(eq(userTasksTable.id, id));
    return res.status(204).send();
  } catch {
    return res.status(500).json({ error: "Impossible de supprimer" });
  }
});

export default router;
