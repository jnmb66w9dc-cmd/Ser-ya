import { Router } from "express";
import { db, pool } from "@workspace/db";
import { getAuth } from "@clerk/express";
import { logger } from "../lib/logger";

const router = Router();

// POST /api/feedback — collect beta feedback
router.post("/", async (req, res) => {
  const { userId } = getAuth(req);
  const { type, rating, text } = req.body as {
    type?: string;
    rating?: number;
    text?: string;
  };

  if (!text?.trim() && !rating) {
    return res.status(400).json({ error: "Feedback text or rating required" });
  }

  try {
    const client = await pool.connect();
    try {
      await client.query(
        `INSERT INTO public.serenya_feedback (user_id, type, rating, text, created_at)
         VALUES ($1, $2, $3, $4, NOW())`,
        [userId ?? null, type ?? "suggestion", rating ?? null, text ?? ""]
      );
    } finally {
      client.release();
    }

    logger.info({ userId, type, rating }, "Feedback received");
    return res.json({ success: true });
  } catch (err: any) {
    logger.error({ err: err.message }, "Failed to store feedback");
    return res.status(500).json({ error: "Impossible d'enregistrer le retour" });
  }
});

// GET /api/feedback/stats — admin only (no auth check for now — add admin middleware in prod)
router.get("/stats", async (_req, res) => {
  try {
    const client = await pool.connect();
    let stats;
    try {
      const result = await client.query(`
        SELECT
          COUNT(*) as total,
          AVG(rating) as avg_rating,
          COUNT(*) FILTER (WHERE type = 'suggestion') as suggestions,
          COUNT(*) FILTER (WHERE type = 'bug') as bugs,
          COUNT(*) FILTER (WHERE type = 'praise') as praise
        FROM public.serenya_feedback
        WHERE created_at > NOW() - INTERVAL '30 days'
      `);
      stats = result.rows[0];
    } finally {
      client.release();
    }
    return res.json(stats);
  } catch (err: any) {
    return res.status(500).json({ error: "Stats unavailable" });
  }
});

export default router;
