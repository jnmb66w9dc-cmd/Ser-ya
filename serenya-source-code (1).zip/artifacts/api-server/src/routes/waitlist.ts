import { Router } from "express";
import { db, waitlistTable, automationsTable } from "@workspace/db";
import { eq, count, sql } from "drizzle-orm";

const router = Router();

// GET /api/waitlist/stats — public stats for landing page
router.get("/stats", async (_req, res) => {
  try {
    const [wlCount] = await db.select({ value: count() }).from(waitlistTable);
    const [autoCount] = await db.select({ value: count() }).from(automationsTable);
    const [completedCount] = await db
      .select({ value: count() })
      .from(automationsTable)
      .where(eq(automationsTable.status, "completed"));
    const total = autoCount?.value ?? 0;
    const completed = completedCount?.value ?? 0;
    const successRate = total > 0 ? Math.round((completed / total) * 100) : 0;

    return res.json({
      waitlistCount: wlCount?.value ?? 0,
      automationCount: total,
      successRate,
    });
  } catch {
    return res.json({ waitlistCount: 0, automationCount: 0, successRate: 0 });
  }
});

// POST /api/waitlist — join the waitlist
router.post("/", async (req, res) => {
  const { email, source, utmCampaign } = req.body as { email?: string; source?: string; utmCampaign?: string };

  if (!email?.trim() || !email.includes("@")) {
    return res.status(400).json({ error: "Adresse email invalide" });
  }

  try {
    const trimmed = email.trim().toLowerCase();
    const [existing] = await db.select().from(waitlistTable).where(eq(waitlistTable.email, trimmed)).limit(1);
    if (existing) {
      return res.status(200).json({ ok: true, alreadyRegistered: true });
    }

    await db.insert(waitlistTable).values({
      email: trimmed,
      source: source?.trim() || "landing",
      utmCampaign: utmCampaign?.trim() || null,
    });

    return res.status(201).json({ ok: true });
  } catch (err: any) {
    return res.status(500).json({ error: "Impossible d'enregistrer. Réessayez plus tard." });
  }
});

export default router;
