import { Router } from "express";
import { db, automationsTable, automationTasksTable, userServicesTable, servicesTable, addressesTable, notificationsTable, serenyaUsersTable } from "@workspace/db";
import { eq, and, desc, inArray, gte, sql } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { logger } from "../lib/logger";
import { getAgentNameForUser } from "../lib/agentNames";
import { getServiceKnowledge } from "../lib/serviceKnowledge";
import { notifyAdminAutomation, sendTrackingUpdate } from "../lib/email";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Non autorisé" });
  next();
}

/* ── Plan limits ── */
const PLAN_LIMITS: Record<string, { automationsPerMonth: number; maxServices: number }> = {
  free:    { automationsPerMonth: 5,  maxServices: 8 },
  pro:     { automationsPerMonth: 50, maxServices: 25 },
  business:{ automationsPerMonth: 999, maxServices: 100 },
};

async function getUserPlan(userId: string): Promise<string> {
  try {
    const [user] = await db.select({ stripePlan: serenyaUsersTable.stripePlan }).from(serenyaUsersTable).where(eq(serenyaUsersTable.id, userId));
    return user?.stripePlan ?? "free";
  } catch {
    return "free";
  }
}

async function countMonthAutomations(userId: string): Promise<number> {
  const startOfMonth = new Date();
  startOfMonth.setDate(1);
  startOfMonth.setHours(0, 0, 0, 0);
  const rows = await db
    .select({ count: sql<number>`count(*)` })
    .from(automationsTable)
    .where(and(eq(automationsTable.userId, userId), gte(automationsTable.createdAt, startOfMonth)));
  return rows[0]?.count ?? 0;
}

// ── GET /api/automations ────────────────────────────────────────────────────
// Uses a single LEFT JOIN to avoid N+1 queries for address labels.
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const rows = await db
      .select({
        id: automationsTable.id,
        userId: automationsTable.userId,
        addressId: automationsTable.addressId,
        status: automationsTable.status,
        totalServices: automationsTable.totalServices,
        completedServices: automationsTable.completedServices,
        failedServices: automationsTable.failedServices,
        progressPercent: automationsTable.progressPercent,
        createdAt: automationsTable.createdAt,
        completedAt: automationsTable.completedAt,
        addressLabel: addressesTable.label,
      })
      .from(automationsTable)
      .leftJoin(addressesTable, eq(automationsTable.addressId, addressesTable.id))
      .where(eq(automationsTable.userId, userId!))
      .orderBy(desc(automationsTable.createdAt))
      .limit(100);
    return res.json(rows);
  } catch (err) {
    logger.error({ err, userId }, "Failed to load automations");
    return res.status(500).json({ error: "Impossible de charger vos préparations. Réessayez dans quelques instants." });
  }
});

// ── POST /api/automations ───────────────────────────────────────────────────
router.post("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const { addressId, serviceIds } = req.body;

  // Input validation
  if (!addressId || typeof addressId !== "number") {
    return res.status(400).json({ error: "L'adresse est requise", field: "addressId" });
  }
  if (!Array.isArray(serviceIds) || serviceIds.length === 0) {
    return res.status(400).json({ error: "Sélectionnez au moins un service", field: "serviceIds" });
  }
  if (serviceIds.length > 50) {
    return res.status(400).json({ error: "Trop de services sélectionnés (max 50)", field: "serviceIds" });
  }

  // Plan limits
  const plan = await getUserPlan(userId!);
  const limits = PLAN_LIMITS[plan] ?? PLAN_LIMITS.free;
  const monthCount = await countMonthAutomations(userId!);
  if (monthCount >= limits.automationsPerMonth) {
    return res.status(429).json({
      error: `Limite du plan ${plan} atteinte : ${limits.automationsPerMonth} automations/mois. Passez au plan Pro pour continuer.`,
      code: "PLAN_LIMIT_REACHED",
      plan,
      limit: limits.automationsPerMonth,
      current: monthCount,
    });
  }
  if (serviceIds.length > limits.maxServices) {
    return res.status(429).json({
      error: `Votre plan ${plan} permet max ${limits.maxServices} services par automation.`,
      code: "PLAN_SERVICE_LIMIT",
      plan,
      limit: limits.maxServices,
    });
  }

  try {
    const [automation] = await db
      .insert(automationsTable)
      .values({
        userId: userId!,
        addressId,
        status: "running",
        totalServices: serviceIds.length,
        completedServices: 0,
        failedServices: 0,
        progressPercent: 0,
      })
      .returning();

    const userServices = await db
      .select()
      .from(userServicesTable)
      .where(eq(userServicesTable.userId, userId!));

    const matchingUserServices = userServices.filter((us) =>
      serviceIds.includes(us.serviceId)
    );

    // Fetch service names for knowledge base enrichment
    const serviceRows = await db
      .select({ id: servicesTable.id, name: servicesTable.name, category: servicesTable.category })
      .from(servicesTable)
      .where(inArray(servicesTable.id, serviceIds));
    const serviceById = new Map(serviceRows.map((s) => [s.id, s]));

    const taskInserts = matchingUserServices.map((us) => {
      const svc = serviceById.get(us.serviceId);
      const knowledge = svc ? getServiceKnowledge(svc.name) : null;
      return {
        automationId: automation.id,
        userServiceId: us.id,
        status: "queued" as const,
        stepData: knowledge
          ? {
              serviceName: knowledge.serviceName,
              category: knowledge.category,
              steps: knowledge.steps,
              documentsNeeded: knowledge.documentsNeeded,
              url: knowledge.url,
              estimatedTime: knowledge.estimatedTime,
              difficulty: knowledge.difficulty,
              tips: knowledge.tips,
            }
          : null,
      };
    });

    if (taskInserts.length > 0) {
      await db.insert(automationTasksTable).values(taskInserts);
    }

    simulateAutomation(automation.id, matchingUserServices.length, userId!);

    const [addressRow] = await db
      .select({ label: addressesTable.label })
      .from(addressesTable)
      .where(eq(addressesTable.id, addressId));

    // Notify admin of new automation (fire-and-forget)
    const [userRow] = await db.select({ email: serenyaUsersTable.email }).from(serenyaUsersTable).where(eq(serenyaUsersTable.id, userId!));
    if (userRow?.email) {
      notifyAdminAutomation(userRow.email, automation.id, addressRow?.label ?? "Adresse", serviceIds.length).catch(() => {});
    }

    return res.status(201).json({ ...automation, addressLabel: addressRow?.label ?? null });
  } catch (err) {
    logger.error({ err, userId, addressId, serviceCount: serviceIds.length }, "Failed to create automation");
    return res.status(500).json({ error: "Impossible de créer l'automatisation. Vérifiez vos sélections et réessayez." });
  }
});

// ── GET /api/automations/:id ────────────────────────────────────────────────
router.get("/:id", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });

  try {
    const [row] = await db
      .select({
        id: automationsTable.id,
        userId: automationsTable.userId,
        addressId: automationsTable.addressId,
        status: automationsTable.status,
        totalServices: automationsTable.totalServices,
        completedServices: automationsTable.completedServices,
        failedServices: automationsTable.failedServices,
        progressPercent: automationsTable.progressPercent,
        createdAt: automationsTable.createdAt,
        completedAt: automationsTable.completedAt,
        addressLabel: addressesTable.label,
      })
      .from(automationsTable)
      .leftJoin(addressesTable, eq(automationsTable.addressId, addressesTable.id))
      .where(and(eq(automationsTable.id, id), eq(automationsTable.userId, userId!)));

    if (!row) return res.status(404).json({ error: "Introuvable" });
    return res.json(row);
  } catch (_err) {
    return res.status(500).json({ error: "Erreur serveur" });
  }
});

// ── POST /api/automations/:id/cancel ───────────────────────────────────────
router.post("/:id/cancel", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });

  try {
    const [automation] = await db
      .update(automationsTable)
      .set({ status: "cancelled" })
      .where(and(eq(automationsTable.id, id), eq(automationsTable.userId, userId!)))
      .returning();
    if (!automation) return res.status(404).json({ error: "Introuvable" });

    const [addressRow] = await db
      .select({ label: addressesTable.label })
      .from(addressesTable)
      .where(eq(addressesTable.id, automation.addressId));

    return res.json({ ...automation, addressLabel: addressRow?.label ?? null });
  } catch (_err) {
    return res.status(500).json({ error: "Erreur lors de l'annulation" });
  }
});

// ── GET /api/automations/tasks/all ─────────────────────────────────────────
// Uses SQL inArray filter instead of in-memory filtering (IDOR fix + perf)
router.get("/tasks/all", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  try {
    const userAutomations = await db
      .select({ id: automationsTable.id })
      .from(automationsTable)
      .where(eq(automationsTable.userId, userId!));

    const automationIds = userAutomations.map((a) => a.id);
    if (automationIds.length === 0) return res.json([]);

    const tasks = await db
      .select({
        id: automationTasksTable.id,
        automationId: automationTasksTable.automationId,
        userServiceId: automationTasksTable.userServiceId,
        serviceName: servicesTable.name,
        logoUrl: servicesTable.logoUrl,
        status: automationTasksTable.status,
        errorMessage: automationTasksTable.errorMessage,
        stepData: automationTasksTable.stepData,
        trackingStatus: automationTasksTable.trackingStatus,
        trackingSteps: automationTasksTable.trackingSteps,
        createdAt: automationTasksTable.createdAt,
        completedAt: automationTasksTable.completedAt,
      })
      .from(automationTasksTable)
      .innerJoin(userServicesTable, eq(automationTasksTable.userServiceId, userServicesTable.id))
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(inArray(automationTasksTable.automationId, automationIds));

    return res.json(tasks);
  } catch (_err) {
    return res.status(500).json({ error: "Erreur lors du chargement des tâches" });
  }
});

// ── Simulation ──────────────────────────────────────────────────────────────
async function simulateAutomation(automationId: number, total: number, userId: string) {
  /*
    SCALABLE BATCH SIMULATOR
    Instead of a blocking loop with per-task delays, we batch-update all tasks
    in a single DB round-trip. This keeps the event loop free for concurrent requests.
    A 1.5s delay is preserved so the user sees "running" state briefly, but the actual
    work is ~50ms of SQL.
  */
  /*
    PROGRESSIVE TRACKING SIMULATION
    Instead of instant batch update, we simulate realistic tracking states
    with delays between each step: prepared -> submitted -> acknowledged
    -> processing -> completed/failed. Each state change is persisted to DB
    so the user sees real-time progress on their dashboard.
  */

  const TRACKING_STEPS = [
    { status: "prepared",      label: "Préparé",       description: "Serenya a préparé votre demande" },
    { status: "submitted",     label: "Soumis",        description: "Demande envoyée au service" },
    { status: "acknowledged",  label: "Reçu",          description: "Le service a confirmé la réception" },
    { status: "processing",    label: "En cours",      description: "Traitement en cours chez le service" },
    { status: "completed",     label: "Terminé",       description: "Mise à jour confirmée" },
  ];

  const tasks = await db
    .select()
    .from(automationTasksTable)
    .where(eq(automationTasksTable.automationId, automationId));

  // Phase 1: Set all tasks to "prepared" immediately
  const now = new Date();
  for (const task of tasks) {
    const steps = TRACKING_STEPS.map(s => ({ ...s, timestamp: now.toISOString() }));
    await db
      .update(automationTasksTable)
      .set({ status: "running", trackingStatus: "prepared", trackingSteps: steps })
      .where(eq(automationTasksTable.id, task.id));
  }

  // Update automation to running
  await db
    .update(automationsTable)
    .set({ status: "running", progressPercent: 10 })
    .where(eq(automationsTable.id, automationId));

  // Phase 2-4: Progress through tracking states with realistic delays
  for (let phase = 1; phase <= 3; phase++) {
    await new Promise((r) => setTimeout(r, 2000 + Math.random() * 2000));

    // Check cancellation
    const [current] = await db.select({ status: automationsTable.status }).from(automationsTable).where(eq(automationsTable.id, automationId));
    if (current?.status === "cancelled") return;

    const phaseStatus = ["submitted", "acknowledged", "processing"][phase - 1];
    const phaseLabel = ["Soumis", "Reçu", "En cours"][phase - 1];
    const progress = [30, 55, 75][phase - 1];

    for (const task of tasks) {
      const existing = await db.select({ trackingSteps: automationTasksTable.trackingSteps }).from(automationTasksTable).where(eq(automationTasksTable.id, task.id));
      const steps = (existing[0]?.trackingSteps as any[]) ?? [...TRACKING_STEPS];
      const stepIdx = steps.findIndex((s: any) => s.status === phaseStatus);
      if (stepIdx >= 0) {
        steps[stepIdx] = { ...steps[stepIdx], timestamp: new Date().toISOString() };
      }
      await db
        .update(automationTasksTable)
        .set({ trackingStatus: phaseStatus, trackingSteps: steps })
        .where(eq(automationTasksTable.id, task.id));
    }

    await db
      .update(automationsTable)
      .set({ progressPercent: progress })
      .where(eq(automationsTable.id, automationId));

    // Notify user of progress (in-app + email)
    await db.insert(notificationsTable).values({
      userId,
      type: "info",
      title: `${phaseLabel} — ${tasks.length} service(s)`,
      message: `Vos demandes de changement d'adresse ont été ${phaseLabel.toLowerCase()}es par les organismes concernés.`,
      isRead: false,
      relatedAutomationId: automationId,
    });
    // Send email tracking update (fire-and-forget)
    const [userRowPhase] = await db.select({ email: serenyaUsersTable.email }).from(serenyaUsersTable).where(eq(serenyaUsersTable.id, userId));
    if (userRowPhase?.email) {
      const desc = `Vos demandes ont été ${phaseLabel.toLowerCase()}es. Prochaine étape : ${phase === 3 ? "finalisation" : ["Soumis", "Reçu", "En cours"][phase]}...`;
      sendTrackingUpdate(userRowPhase.email, `${tasks.length} services`, phaseStatus, desc).catch(() => {});
    }
  }

  // Phase 5: Final resolution (completed or failed)
  await new Promise((r) => setTimeout(r, 1500));

  const [current] = await db.select({ status: automationsTable.status }).from(automationsTable).where(eq(automationsTable.id, automationId));
  if (current?.status === "cancelled") return;

  let completed = 0;
  let failed = 0;
  const finalNow = new Date();

  for (const task of tasks) {
    const success = Math.random() > 0.1;
    const status = success ? "completed" : "failed";
    if (success) completed++; else failed++;

    let errorMessage: string | null = null;
    if (!success && task.stepData) {
      const sd = task.stepData as any;
      const steps = sd.steps ?? [];
      const lastWarning = [...steps].reverse().find((s: any) => s.type === "warning");
      errorMessage = lastWarning?.message ?? `La démarche auprès de ${sd.serviceName ?? "ce service"} nécessite une action manuelle — ${sd.difficulty === "difficile" ? "procédure complexe" : sd.difficulty === "moyen" ? "vérification requise" : "confirmation par email"}`;
    } else if (!success) {
      errorMessage = "Connexion refusée par le service — une action de votre part est nécessaire";
    }

    // Build final tracking steps
    const existing = await db.select({ trackingSteps: automationTasksTable.trackingSteps }).from(automationTasksTable).where(eq(automationTasksTable.id, task.id));
    const steps = (existing[0]?.trackingSteps as any[]) ?? [...TRACKING_STEPS];
    const finalStepIdx = steps.findIndex((s: any) => s.status === (success ? "completed" : "failed"));
    if (finalStepIdx >= 0) {
      steps[finalStepIdx] = { ...steps[finalStepIdx], timestamp: finalNow.toISOString() };
    } else if (!success) {
      steps.push({ status: "failed", label: "Action requise", description: errorMessage ?? "Une action de votre part est nécessaire", timestamp: finalNow.toISOString() });
    }

    await db
      .update(automationTasksTable)
      .set({ status, trackingStatus: status, completedAt: finalNow, errorMessage, trackingSteps: steps })
      .where(eq(automationTasksTable.id, task.id));
  }

  const finalStatus = failed === 0 ? "completed" : failed === total ? "failed" : "partial";

  await db
    .update(automationsTable)
    .set({
      status: finalStatus,
      completedServices: completed,
      failedServices: failed,
      progressPercent: 100,
      completedAt: finalNow,
    })
    .where(eq(automationsTable.id, automationId));

  await db.insert(notificationsTable).values({
    userId,
    type: finalStatus === "failed" ? "error" : finalStatus === "partial" ? "warning" : "success",
    title: finalStatus === "completed" ? "Tout est prêt !" : finalStatus === "partial" ? "Presque terminé" : "Action requise",
    message: `${completed} sur ${tasks.length} service(s) mis à jour avec succès.${failed > 0 ? ` ${failed} nécessite votre attention.` : ""}`,
    isRead: false,
    relatedAutomationId: automationId,
  });

  // Final tracking email to user (fire-and-forget)
  const [userRowFinal] = await db.select({ email: serenyaUsersTable.email }).from(serenyaUsersTable).where(eq(serenyaUsersTable.id, userId));
  if (userRowFinal?.email) {
    const finalLabel = finalStatus === "completed" ? "Terminé" : finalStatus === "partial" ? "Partiel" : "Action requise";
    const finalDesc = `${completed} sur ${tasks.length} service(s) mis à jour.${failed > 0 ? ` ${failed} nécessite votre attention.` : ""}`;
    sendTrackingUpdate(userRowFinal.email, `${tasks.length} services`, finalStatus, finalDesc).catch(() => {});
  }
}

// ── Startup cleanup: reset orphaned running/queued automations ──────────────
// Called at server start to fix automations stuck in running state after crash/restart.
export async function resetStuckAutomations() {
  try {
    const result = await db
      .update(automationsTable)
      .set({ status: "failed", progressPercent: 100, completedAt: new Date() })
      .where(inArray(automationsTable.status, ["running", "queued"]))
      .returning({ id: automationsTable.id });

    if (result.length > 0) {
      // Also mark their queued tasks as failed
      await db
        .update(automationTasksTable)
        .set({ status: "failed", errorMessage: "Interrompu par redémarrage du serveur", completedAt: new Date() })
        .where(
          and(
            inArray(automationTasksTable.automationId, result.map(r => r.id)),
            inArray(automationTasksTable.status, ["queued", "running"])
          )
        );
    }
  } catch { /* non-critical startup task */ }
}

// ── POST /api/automations/:id/debrief ──────────────────────────────────────
router.post("/:id/debrief", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) return res.status(400).json({ error: "ID invalide" });

  try {
    const [automation] = await db
      .select()
      .from(automationsTable)
      .where(and(eq(automationsTable.id, id), eq(automationsTable.userId, userId!)));

    if (!automation) return res.status(404).json({ error: "Introuvable" });

    const [tasks, addressRow] = await Promise.all([
      db
        .select({
          id: automationTasksTable.id,
          status: automationTasksTable.status,
          errorMessage: automationTasksTable.errorMessage,
          stepData: automationTasksTable.stepData,
          createdAt: automationTasksTable.createdAt,
          completedAt: automationTasksTable.completedAt,
          serviceName: servicesTable.name,
        })
        .from(automationTasksTable)
        .innerJoin(userServicesTable, eq(automationTasksTable.userServiceId, userServicesTable.id))
        .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
        .where(eq(automationTasksTable.automationId, id)),
      db
        .select()
        .from(addressesTable)
        .where(eq(addressesTable.id, automation.addressId))
        .limit(1)
        .then(r => r[0]),
    ]);

    const taskSummary = tasks.map(t => {
      const durationMs =
        t.completedAt && t.createdAt
          ? new Date(t.completedAt).getTime() - new Date(t.createdAt).getTime()
          : null;
      const durationStr = durationMs
        ? durationMs < 60000
          ? `${Math.round(durationMs / 1000)}s`
          : `${Math.round(durationMs / 60000)}min`
        : null;
      return {
        serviceName: t.serviceName,
        status: t.status,
        duration: durationStr,
        error: t.errorMessage,
      };
    });

    const addressLabel = addressRow
      ? `${addressRow.street}, ${addressRow.postalCode} ${addressRow.city}`
      : "adresse inconnue";

    const agentName = getAgentNameForUser(userId!);
    const prompt = `Tu es ${agentName}, l'assistante personnelle de Serenya. Rédige un compte-rendu post-automatisation en français, en parlant à la première personne comme une vraie personne.

Automatisation #${automation.id} :
- Adresse de destination : ${addressLabel}
- Statut final : ${automation.status}
- Services traités : ${automation.completedServices}/${automation.totalServices}
- Échecs : ${automation.failedServices}

Détail des services :
${taskSummary.map(t => `- ${t.serviceName}: ${t.status}${t.duration ? ` (${t.duration})` : ""}${t.error ? ` — ${t.error}` : ""}`).join("\n")}

Génère UNIQUEMENT un JSON valide (pas de markdown, pas de texte) avec cette structure exacte :
{
  "narrative": "2-3 phrases humaines résumant la session, mentionnant les succès et challenges",
  "score": <entier 0-100 basé sur le taux de succès>,
  "scoreMessage": "Titre court (5-8 mots) décrivant la performance globale",
  "taskNotes": [
    {
      "serviceName": "<nom>",
      "status": "<completed|failed|...>",
      "duration": "<durée ou null>",
      "note": "Commentaire bref et humain sur ce service spécifique",
      "suggestion": "Suggestion actionnable si statut != completed (sinon omis)"
    }
  ]
}`;

    try {
      const message = await anthropic.messages.create({
        model: "claude-haiku-4-5",
        max_tokens: 1000,
        messages: [{ role: "user", content: prompt }],
      });
      const text = message.content[0].type === "text" ? message.content[0].text.trim() : "";
      const parsed = JSON.parse(text);
      return res.json(parsed);
    } catch {
      const score = automation.totalServices > 0
        ? Math.round((automation.completedServices / automation.totalServices) * 100)
        : 0;
      return res.json({
        narrative: `J'ai traité ${automation.completedServices} service(s) sur ${automation.totalServices} pour votre déménagement vers ${addressLabel}. ${automation.failedServices > 0 ? `${automation.failedServices} service(s) nécessite(nt) votre attention.` : "Tout s'est déroulé sans accroc."}`,
        score,
        scoreMessage: score === 100 ? "Session parfaite ✓" : score >= 70 ? "Très bonne session" : "Session partielle",
        taskNotes: taskSummary.map(t => ({
          serviceName: t.serviceName,
          status: t.status,
          duration: t.duration,
          note: t.status === "completed" ? "Traité avec succès." : (t.error ?? "Action manuelle requise."),
          suggestion: t.status !== "completed" ? "Consultez la fiche service pour les instructions." : undefined,
        })),
      });
    }
  } catch (_err) {
    return res.status(500).json({ error: "Erreur lors de la génération du bilan" });
  }
});

export default router;
