import { Router } from "express";
import { db, addressesTable, automationsTable, automationTasksTable, userServicesTable, servicesTable, notificationsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { getAuth } from "@clerk/express";
import { logger } from "../lib/logger";

const router = Router();

function escapeCsv(val: unknown): string {
  const str = String(val ?? "");
  if (str.includes(",") || str.includes('"') || str.includes("\n") || str.includes("\r")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function toCsvRow(cols: unknown[]): string {
  return cols.map(escapeCsv).join(",") + "\n";
}

function formatDate(iso: string | Date | null): string {
  if (!iso) return "";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  return d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

function formatStatus(status: string): string {
  const map: Record<string, string> = {
    completed: "Terminé",
    running: "En cours",
    failed: "Échec",
    pending: "En attente",
    cancelled: "Annulé",
  };
  return map[status] ?? status;
}

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// GET /api/user/export — RGPD data export
router.get("/export", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);

  const [addresses, automations, notifications, userServices] = await Promise.all([
    db.select().from(addressesTable).where(eq(addressesTable.userId, userId!)),
    db.select().from(automationsTable).where(eq(automationsTable.userId, userId!)),
    db.select().from(notificationsTable).where(eq(notificationsTable.userId, userId!)),
    db
      .select({
        id: userServicesTable.id,
        serviceId: userServicesTable.serviceId,
        serviceName: servicesTable.name,
        connectedAt: userServicesTable.connectedAt,
        status: userServicesTable.status,
      })
      .from(userServicesTable)
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(eq(userServicesTable.userId, userId!)),
  ]);

  // Fetch tasks for user's automations
  const automationIds = automations.map((a) => a.id);
  let tasks: any[] = [];
  if (automationIds.length > 0) {
    tasks = await db
      .select({
        id: automationTasksTable.id,
        automationId: automationTasksTable.automationId,
        serviceName: servicesTable.name,
        status: automationTasksTable.status,
        createdAt: automationTasksTable.createdAt,
        completedAt: automationTasksTable.completedAt,
      })
      .from(automationTasksTable)
      .innerJoin(userServicesTable, eq(automationTasksTable.userServiceId, userServicesTable.id))
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(eq(userServicesTable.userId, userId!));
  }

  const exportData = {
    exportedAt: new Date().toISOString(),
    userId,
    addresses: addresses.map((a) => ({ ...a, createdAt: a.createdAt.toISOString(), updatedAt: a.updatedAt?.toISOString() ?? null })),
    connectedServices: userServices.map((s) => ({ ...s, connectedAt: s.connectedAt?.toISOString() ?? null })),
    automations: automations.map((a) => ({
      ...a,
      createdAt: a.createdAt.toISOString(),
      completedAt: a.completedAt?.toISOString() ?? null,
      tasks: tasks.filter((t) => t.automationId === a.id).map((t) => ({
        ...t,
        createdAt: t.createdAt.toISOString(),
        completedAt: t.completedAt?.toISOString() ?? null,
      })),
    })),
    notifications: notifications.map((n) => ({ ...n, createdAt: n.createdAt.toISOString() })),
  };

  res.setHeader("Content-Type", "application/json");
  res.setHeader("Content-Disposition", `attachment; filename="serenya-export-${new Date().toISOString().split("T")[0]}.json"`);
  return res.json(exportData);
});

// GET /api/user/export-csv — professional CSV export (automations + tasks)
router.get("/export-csv", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);

  const [addresses, automations, userServices] = await Promise.all([
    db.select().from(addressesTable).where(eq(addressesTable.userId, userId!)).orderBy(desc(addressesTable.createdAt)),
    db.select().from(automationsTable).where(eq(automationsTable.userId, userId!)).orderBy(desc(automationsTable.createdAt)),
    db
      .select({
        id: userServicesTable.id,
        serviceId: userServicesTable.serviceId,
        serviceName: servicesTable.name,
        connectedAt: userServicesTable.connectedAt,
        status: userServicesTable.status,
      })
      .from(userServicesTable)
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(eq(userServicesTable.userId, userId!))
      .orderBy(desc(userServicesTable.connectedAt)),
  ]);

  const automationIds = automations.map((a) => a.id);
  let tasks: any[] = [];
  if (automationIds.length > 0) {
    tasks = await db
      .select({
        id: automationTasksTable.id,
        automationId: automationTasksTable.automationId,
        serviceName: servicesTable.name,
        status: automationTasksTable.status,
        createdAt: automationTasksTable.createdAt,
        completedAt: automationTasksTable.completedAt,
      })
      .from(automationTasksTable)
      .innerJoin(userServicesTable, eq(automationTasksTable.userServiceId, userServicesTable.id))
      .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id))
      .where(eq(userServicesTable.userId, userId!));
  }

  // Build CSV content
  let csv = "\uFEFF"; // UTF-8 BOM for Excel
  csv += toCsvRow(["Récapitulatif des démarches Serenya"]) + "\n";
  csv += toCsvRow(["Exporté le", formatDate(new Date().toISOString())]) + "\n";
  csv += "\n";

  // 1. Automations summary
  csv += toCsvRow(["AUTOMATISATIONS"]) + "\n";
  csv += toCsvRow(["ID", "Adresse", "Organismes", "Statut global", "Date de création", "Date de fin", "Succès", "Détail des tâches"]);
  for (const a of automations) {
    const addrLabel = addresses.find((ad) => ad.id === a.addressId)?.label ?? "Adresse inconnue";
    const aTasks = tasks.filter((t) => t.automationId === a.id);
    const completedCount = aTasks.filter((t) => t.status === "completed").length;
    const successRate = aTasks.length > 0 ? Math.round((completedCount / aTasks.length) * 100) + "%" : "N/A";
    const taskDetails = aTasks.map((t) => `${t.serviceName} (${formatStatus(t.status)})`).join(" ; ");
    csv += toCsvRow([
      a.id,
      addrLabel,
      aTasks.length,
      formatStatus(a.status),
      formatDate(a.createdAt.toISOString()),
      formatDate(a.completedAt?.toISOString() ?? null),
      successRate,
      taskDetails,
    ]);
  }
  csv += "\n";

  // 2. Connected services
  csv += toCsvRow(["ORGANISMES CONNECTÉS"]) + "\n";
  csv += toCsvRow(["Organisme", "Statut", "Connecté le"]);
  for (const s of userServices) {
    csv += toCsvRow([s.serviceName, formatStatus(s.status), formatDate(s.connectedAt?.toISOString() ?? null)]);
  }
  csv += "\n";

  // 3. Addresses
  csv += toCsvRow(["ADRESSES ENREGISTRÉES"]) + "\n";
  csv += toCsvRow(["Libellé", "Rue", "Complément", "Code postal", "Ville", "Pays", "Par défaut", "Créée le"]);
  for (const a of addresses) {
    csv += toCsvRow([
      a.label,
      a.street,
      a.complement ?? "",
      a.postalCode,
      a.city,
      a.country,
      a.isDefault ? "Oui" : "Non",
      formatDate(a.createdAt.toISOString()),
    ]);
  }

  const filename = `serenya-export-${new Date().toISOString().split("T")[0]}.csv`;
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
  return res.send(csv);
});

// DELETE /api/user — RGPD Art. 17: droit à l'effacement
router.delete("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });

  try {
    // Delete in dependency order: tasks → automations → userServices → notifications → addresses
    const automationIds = await db
      .select({ id: automationsTable.id })
      .from(automationsTable)
      .where(eq(automationsTable.userId, userId));

    for (const a of automationIds) {
      await db.delete(automationTasksTable).where(eq(automationTasksTable.automationId, a.id));
    }

    await db.delete(automationsTable).where(eq(automationsTable.userId, userId));
    await db.delete(userServicesTable).where(eq(userServicesTable.userId, userId));
    await db.delete(notificationsTable).where(eq(notificationsTable.userId, userId));
    await db.delete(addressesTable).where(eq(addressesTable.userId, userId));

    return res.json({ success: true, message: "All user data deleted (RGPD Art. 17)" });
  } catch (err) {
    logger.error({ err }, "[DELETE /api/user] error");
    return res.status(500).json({ error: "Failed to delete account" });
  }
});

export default router;
