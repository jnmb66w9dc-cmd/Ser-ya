import { Router } from "express";
import { logger } from "../lib/logger";

const router = Router();

// POST /api/analytics/events — lightweight batch event ingestion
router.post("/events", async (req, res) => {
  const { events } = req.body as { events?: Array<{ event: string; props?: Record<string, unknown>; ts: number }> };

  if (!Array.isArray(events) || events.length === 0) {
    return res.status(400).json({ error: "No events" });
  }

  // Store in logs (production: send to PostHog / Mixpanel / etc.)
  for (const e of events) {
    logger.info({ event: e.event, props: e.props, ts: e.ts }, "Analytics event");
  }

  return res.json({ received: events.length });
});

export default router;
