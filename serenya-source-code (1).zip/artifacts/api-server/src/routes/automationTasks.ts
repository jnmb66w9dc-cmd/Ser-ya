import { Router } from "express";
import { db, automationsTable, automationTasksTable, userServicesTable, servicesTable, notificationsTable } from "@workspace/db";
import { eq, and, inArray } from "drizzle-orm";
import { getAuth } from "@clerk/express";

const router = Router();

function requireAuth(req: any, res: any, next: any) {
  const { userId } = getAuth(req);
  if (!userId) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// GET /api/automation-tasks
router.get("/", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);

  const userAutomations = await db
    .select({ id: automationsTable.id })
    .from(automationsTable)
    .where(eq(automationsTable.userId, userId!));
  const automationIds = userAutomations.map((a) => a.id);

  if (automationIds.length === 0) return res.json([]);

  const tasks = await db
    .select({
      id: automationTasksTable.id,
      automationId: automationTasksTable.automationId,
      userServiceId: automationTasksTable.userServiceId,
      serviceName: servicesTable.name,
      logoUrl: servicesTable.logoUrl,
      status: automationTasksTable.status,
      errorMessage: automationTasksTable.errorMessage,
      createdAt: automationTasksTable.createdAt,
      completedAt: automationTasksTable.completedAt,
    })
    .from(automationTasksTable)
    .innerJoin(userServicesTable, eq(automationTasksTable.userServiceId, userServicesTable.id))
    .innerJoin(servicesTable, eq(userServicesTable.serviceId, servicesTable.id));

  return res.json(tasks.filter((t) => automationIds.includes(t.automationId)));
});

// POST /api/automation-tasks/:id/retry — re-run a failed task
router.post("/:id/retry", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  const taskId = parseInt(req.params.id, 10);

  // Verify ownership via the automation
  const [task] = await db
    .select({ id: automationTasksTable.id, automationId: automationTasksTable.automationId, status: automationTasksTable.status })
    .from(automationTasksTable)
    .where(eq(automationTasksTable.id, taskId));

  if (!task) return res.status(404).json({ error: "Tâche introuvable." });

  const [automation] = await db
    .select()
    .from(automationsTable)
    .where(and(eq(automationsTable.id, task.automationId), eq(automationsTable.userId, userId!)));

  if (!automation) return res.status(403).json({ error: "Non autorisé." });
  if (task.status !== "failed") return res.status(400).json({ error: "Seules les tâches échouées peuvent être relancées." });

  // Reset task to queued
  await db
    .update(automationTasksTable)
    .set({ status: "queued", errorMessage: null, completedAt: null })
    .where(eq(automationTasksTable.id, taskId));

  // Update automation status back to running if it was partial/failed
  if (["partial", "failed"].includes(automation.status)) {
    await db
      .update(automationsTable)
      .set({ status: "running" })
      .where(eq(automationsTable.id, automation.id));
  }

  // Return the updated task immediately
  return res.json({ ok: true, taskId });
});

export default router;
