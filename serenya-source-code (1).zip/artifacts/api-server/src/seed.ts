import { db, servicesTable } from "@workspace/db";
import { count } from "drizzle-orm";
import { logger } from "./lib/logger";

const SEED_SERVICES = [
  { name: "Amazon", category: "e-commerce", description: "Mettez à jour votre adresse de livraison et de facturation Amazon en quelques clics.", isPopular: true },
  { name: "EDF", category: "energie", description: "Changement d'adresse pour votre contrat d'électricité — sans coupure.", isPopular: true },
  { name: "Orange", category: "telecom", description: "Transférez votre ligne et mettez à jour votre adresse de facturation.", isPopular: true },
  { name: "PayPal", category: "finance", description: "Mettez à jour votre adresse postale et bancaire PayPal.", isPopular: false },
  { name: "Free", category: "telecom", description: "Fibre, mobile et facturation — tout suivi à votre nouvelle adresse.", isPopular: true },
  { name: "BNP Paribas", category: "banque", description: "Déclarez votre changement d'adresse auprès de votre conseiller.", isPopular: true },
  { name: "AXA", category: "assurance", description: "Assurance habitation et auto — adresse mise à jour instantanément.", isPopular: false },
  { name: "Société Générale", category: "banque", description: "Mettez à jour vos coordonnées bancaires en toute sécurité.", isPopular: true },
  { name: "MAIF", category: "assurance", description: "Mutuelle et assurance — votre nouvelle adresse enregistrée.", isPopular: false },
  { name: "La Poste", category: "administration", description: "Redirection du courrier et mise à jour de votre domiciliation.", isPopular: true },
  { name: "Netflix", category: "abonnement", description: "Adresse de facturation et géolocalisation des contenus.", isPopular: false },
  { name: "Spotify", category: "abonnement", description: "Mise à jour de l'adresse liée à votre abonnement Premium.", isPopular: false },
  { name: "SNCF", category: "transport", description: "Carte de réduction et adresse de livraison des billets.", isPopular: false },
  { name: "Engie", category: "energie", description: "Changement d'adresse pour votre contrat de gaz naturel.", isPopular: false },
  { name: "Crédit Agricole", category: "banque", description: "Déclarez votre nouveau domicile à votre banque régionale.", isPopular: true },
  { name: "Caisse d'Épargne", category: "banque", description: "Mise à jour de vos informations personnelles bancaires.", isPopular: false },
  { name: "LCL", category: "banque", description: "Changement d'adresse pour vos comptes et assurances LCL.", isPopular: false },
  { name: "SFR", category: "telecom", description: "Box et mobile — suivi à votre nouvelle adresse.", isPopular: false },
  { name: "Bouygues Telecom", category: "telecom", description: "Transfert de ligne fibre et mise à jour administrative.", isPopular: false },
  { name: "Impôts", category: "administration", description: "Mise à jour de votre adresse fiscale auprès des services des impôts.", isPopular: true },
  { name: "CAF", category: "administration", description: "Aides au logement et prestations familiales — adresse à jour.", isPopular: true },
  { name: "Cpam", category: "administration", description: "Assurance maladie — déclarez votre changement d'adresse.", isPopular: true },
  { name: "Pôle Emploi", category: "administration", description: "Actualisation et correspondance à votre nouvelle adresse.", isPopular: false },
  { name: "Banque Postale", category: "banque", description: "Compte et assurance — coordonnées mises à jour.", isPopular: false },
];

export async function seedServicesIfEmpty(): Promise<void> {
  try {
    const [{ value: existingCount }] = await db.select({ value: count() }).from(servicesTable);
    if (existingCount > 0) {
      logger.info({ existingCount }, "Services already seeded, skipping");
      return;
    }

    const inserted = await db.insert(servicesTable).values(SEED_SERVICES).returning();
    logger.info({ count: inserted.length }, "Seeded services successfully");
  } catch (err) {
    logger.error({ err }, "Failed to seed services");
  }
}
