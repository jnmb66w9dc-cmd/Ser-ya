import { pool } from "@workspace/db";

export interface StripeProduct {
  id: string;
  name: string;
  description: string | null;
  active: boolean;
  metadata: Record<string, string>;
}

export interface StripePrice {
  id: string;
  productId: string;
  unitAmount: number;
  currency: string;
  interval: string | null;
  active: boolean;
}

export interface StripeSubscription {
  id: string;
  customerId: string;
  status: string;
  currentPeriodEnd: Date;
  priceId: string;
}

export const stripeStorage = {
  async getActiveProducts(): Promise<StripeProduct[]> {
    const client = await pool.connect();
    try {
      const result = await client.query(`
        SELECT id, name, description, active, metadata
        FROM stripe.products
        WHERE active = true
        ORDER BY name
      `);
      return result.rows.map((r: any) => ({
        id: r.id,
        name: r.name,
        description: r.description,
        active: r.active,
        metadata: r.metadata ?? {},
      }));
    } finally {
      client.release();
    }
  },

  async getPricesForProduct(productId: string): Promise<StripePrice[]> {
    const client = await pool.connect();
    try {
      const result = await client.query(`
        SELECT id, product as product_id, unit_amount, currency,
               recurring->>'interval' as interval, active
        FROM stripe.prices
        WHERE product = $1 AND active = true
        ORDER BY unit_amount ASC
      `, [productId]);
      return result.rows.map((r: any) => ({
        id: r.id,
        productId: r.product_id,
        unitAmount: r.unit_amount,
        currency: r.currency,
        interval: r.interval,
        active: r.active,
      }));
    } finally {
      client.release();
    }
  },

  async getCustomerSubscription(stripeCustomerId: string): Promise<StripeSubscription | null> {
    const client = await pool.connect();
    try {
      const result = await client.query(`
        SELECT s.id, s.customer as customer_id, s.status,
               s.current_period_end, si.price as price_id
        FROM stripe.subscriptions s
        JOIN stripe.subscription_items si ON si.subscription = s.id
        WHERE s.customer = $1
          AND s.status IN ('active', 'trialing')
        ORDER BY s.created DESC
        LIMIT 1
      `, [stripeCustomerId]);
      if (result.rows.length === 0) return null;
      const r = result.rows[0];
      return {
        id: r.id,
        customerId: r.customer_id,
        status: r.status,
        currentPeriodEnd: new Date(r.current_period_end * 1000),
        priceId: r.price_id,
      };
    } finally {
      client.release();
    }
  },
};
