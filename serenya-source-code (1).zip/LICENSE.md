# LICENCE PROPRIETAIRE

**SERENYA** - Assistant administratif de changement d'adresse

Copyright (c) 2026 [Proprietaire Serenya]. Tous droits reserves.

Ce logiciel et sa documentation associee (le "Logiciel") sont proteges par
le droit d'auteur et les lois sur la propriete intellectuelle. Le Logiciel
comprend l'ensemble du code source, des interfaces utilisateur, des bases de
donnees, des algorithmes, de la documentation et des marques associees a
Serenya.

## DROITS ACCORDES

Aucun droit n'est accorde sans autorisation ecrite expresse du proprietaire.
Toute utilisation, reproduction, modification, distribution, ou exploitation
du Logiciel, en tout ou en partie, est strictement interdite sans accord
prealable ecrit.

## RESTRICTIONS

Il est interdit de :
- Copier, distribuer ou transmettre le Logiciel
- Modifier, adapter, traduire ou creer des oeuvres derivees du Logiciel
- Decompiler, desassembler, ou proceder a une ingenierie inverse du Logiciel
- Louer, preter, vendre, sous-licencier ou transferer le Logiciel
- Supprimer ou alterer toute mention de copyright ou de propriete
- Utiliser le nom, la marque, ou l'identite visuelle de Serenya sans autorisation

## PROTECTION DES DONNEES

Le Logiciel traite des donnees personnelles sensibles (adresses, organismes
connectes). Tout acces non autorise aux donnees des utilisateurs constitue
une violation des lois sur la protection des donnees (RGPD, CCPA, etc.)
et sera poursuivi penalement et civilement.

## SANCTIONS

Toute violation de cette licence entrainera des poursuites judiciaires pour
contrefacon, violation de la propriete intellectuelle, et tout autre recours
prevu par la loi. Les dommages-interets pourront inclure les benefices
realises par le contrevenant, les pertes subies par le proprietaire, et
les frais d'avocat.

Pour toute demande de licence ou d'autorisation, contactez :
contact@serenya.replit.app

---

Tous droits reserves. Aucune partie de ce Logiciel ne peut etre reproduite,
stockee dans un systeme de recuperation, ou transmise sous quelque forme ou
par quelque moyen que ce soit sans l'autorisation prealable ecrite du
proprietaire.
