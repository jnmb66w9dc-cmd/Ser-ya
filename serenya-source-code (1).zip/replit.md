# MoveFlow

MoveFlow automates address changes across all your services (banks, insurance, telecoms, e-commerce, government) using AI — update your address once, and MoveFlow handles the rest.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/moveflow run dev` — run the frontend (Vite dev server)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/db run seed` — re-seed services (if needed)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite, Wouter (routing), TanStack Query, Framer Motion, shadcn/ui, Tailwind v4
- Auth: Clerk (`@clerk/react@^6`, `@clerk/express@^2`, proxy via `/api/__clerk`)
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/db/src/schema/` — DB schema (addresses, services, userServices, automations, automationTasks, notifications)
- `lib/api-spec/openapi.yaml` — OpenAPI spec (source of truth for API contracts)
- `lib/api-client-react/src/generated/api.ts` — Generated React Query hooks
- `artifacts/api-server/src/routes/` — Express route handlers
- `artifacts/api-server/src/middlewares/clerkProxyMiddleware.ts` — Clerk proxy for auth
- `artifacts/moveflow/src/pages/` — Frontend pages (landing, dashboard, services, addresses, automations, settings)
- `artifacts/moveflow/src/components/` — Shared components (AppLayout, AppSidebar, NotificationDropdown)
- `artifacts/moveflow/src/index.css` — CSS variables + Tailwind theme

## Architecture decisions

- **Contract-first API**: OpenAPI spec in `lib/api-spec`, codegen via Orval generates typed React Query hooks. Never call `fetch` directly in components.
- **Clerk proxy pattern**: All Clerk requests go through `/api/__clerk` so auth works on custom domains. `proxyUrl` is empty in dev (Clerk uses FAPI directly), auto-set in prod.
- **Simulation engine**: `automations.ts` simulates real address-change automation with delays and a 90% success rate, updating task statuses progressively.
- **Separate user-services router**: `userServicesRouter` mounted at `/api/user-services` (separate from `/api/services`) to avoid route conflicts.
- **Dark sidebar, light content**: Sidebar uses dark navy CSS vars (`--sidebar-*`), main content uses light/dark adaptable vars.

## Product

- **Landing page**: Hero, stats, service grid, features, how-it-works, security section, CTA — full marketing page in French
- **Dashboard**: KPI cards (addresses, services, automations, success rate), activity feed, quick links, launch automation modal
- **Services**: Browse 15+ services by category, connect/disconnect with one click, search/filter
- **Addresses**: CRUD for multiple addresses, set default, form validation
- **Automations**: Launch multi-service automations, real-time progress tracking, expand tasks per automation, cancel running automations
- **Notifications**: Bell icon in header, unread badge, mark-all-read, per-notification read
- **Settings**: Profile (Clerk UserProfile), dark/light toggle, notification preferences, security info

## User preferences

- French UI throughout
- Premium/minimal design style (Stripe/Linear aesthetic)
- Dark mode default

## Gotchas

- `@clerk/react@^6` requires `@clerk/shared@^4.12.2` — same as `@clerk/express@2.x`. Both are added to `minimumReleaseAgeExclude` in `pnpm-workspace.yaml` to ensure compatible versions install.
- Run `pnpm install` after changing `pnpm-workspace.yaml` overrides.
- The automation simulation runs async in the API server process — it modifies DB state over time. Don't restart the server mid-automation.
- Seeding: services are seeded via SQL `INSERT ... ON CONFLICT DO NOTHING` — safe to re-run.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
- See the `clerk-auth` skill for Clerk proxy setup and appearance customization
